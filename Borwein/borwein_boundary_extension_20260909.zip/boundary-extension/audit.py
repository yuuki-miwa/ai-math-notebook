"""Check the new frontier and interval budgets; not a full coverage proof."""
import sys,json,csv,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;OUT=ROOT/'results'
sys.path.insert(0,str(WORK/'proposal-completion'))
import certify_budgets as b

def run():
    b.iv.dps=60
    for name,tau,n in [('extension_certificate.json',[1,3.05],2500),('high_extension_certificate.json',[3,5.5],4000)]:
        cert=json.loads((OUT/name).read_text())
        assert cert['status']=='passed' and cert['tau']==tau and cert['n_min']==n
        assert [r['b'] for r in cert['rows']]==[d for d in range(1437,4140) if d%5]
        assert all(r['cost_upper']>0 and r['penalty_upper']>0 for r in cert['rows'])
    cells=json.loads((b.old.PAPER/'results/profile_certificate.json').read_text())['cells']
    moments=json.loads((WORK/'proposal-completion/results/moment_certificate.json').read_text())['rows']
    old=json.loads((WORK/'proposal-completion/results/bulk_thresholds_adaptive.json').read_text())
    new=json.loads((OUT/'bulk_thresholds_adaptive.json').read_text());rows=[];changed=0
    for cell,moment,prior,record in zip(cells,moments,old,new):
        for a in range(5):
            n=record['first_passing_n'][a];h=str(record['selected_h'][a])
            assert n<=prior['first_passing_n'][a]
            changed+=n<prior['first_passing_n'][a]
            values=b.evaluate(cell,moment,n,a,h);total=sum(values,b.I(0))
            assert bool(total.b<b.I('.98').a)
            for value,key in zip(values,['local_main','intermediate','gaussian_tail']):
                nominal=record['at_first_pass'][a]['components'][key]
                assert abs(float(value.b)-nominal)<1e-10*max(1,nominal)
            decay=b.ac.constants(h)[-1];vlo=b.parse(cell['V_interval']).a
            assert bool((b.I(n)*vlo*min(rate.a for _,rate in decay)).a>b.I('.5').b)
            rows.append({'cell':cell['cell'],'a':a,'n':n,'h':h,'three_arc_sum_upper':str(total.b)})
        if cell['cell']%32==31:print('Audited',cell['cell']+1,'cells',flush=True)
    front=list(csv.DictReader((OUT/'frontier_adaptive.csv').open()))
    priorfront=list(csv.DictReader((WORK/'proposal-completion/results/frontier_adaptive.csv').open()))
    assert len(front)==len(priorfront)==30634
    peak=0
    for item,prior in zip(reversed(front),reversed(priorfront)):
        assert item['n']==prior['n']
        assert int(item['last_uncovered_degree'])<=int(prior['last_uncovered_degree'])
        assert int(item['uncovered_coefficients_lower_half'])<=int(prior['uncovered_coefficients_lower_half'])
        peak=max(peak,int(item['last_uncovered_degree']))
        assert int(item['future_retention_degree'])==peak
    summary=json.loads((OUT/'summary_adaptive.json').read_text())
    assert summary['maximum_uncovered_degree']==peak
    assert summary['remaining_lower_half_coefficients']==sum(int(r['uncovered_coefficients_lower_half']) for r in front)
    result={'status':'passed','scope':'Inherited-assumption kernel checks, 640 three-arc interval budgets, and diagnostic frontier consistency; excludes complete localization and coefficient-mapping certification',
      'changed_thresholds':changed,'three_arc_count':len(rows),'frontier_rows':len(front),'rows':rows,
      'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.json') if p.name!='audit.json'}}
    (OUT/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Audit passed; improved thresholds:',changed,flush=True)
if __name__=='__main__':run()
