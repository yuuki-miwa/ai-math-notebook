"""Extend finite-block/tail-exclusion bounds across the former tau=3 seam."""
import sys,json,math,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(WORK/'proposal-completion'))
import model as previous
import certify_tail as tails
np=previous.np;c=previous.c;iv=previous.iv;I=iv.mpf;old=previous.old;arc=previous.arc
Q=4139;K=718;L=32;A=I(1);B=I('3.05');N0=2500

def generate(filename='extension_certificate.json'):
    eta=I(11313)/1250000;weights=np.array([c.upper_float(iv.exp(-eta*l)/l) for l in range(1,K+1)])
    finite=np.array([c.upper_float((1+iv.exp(-A*l))/2) for l in range(1,L+1)])
    radial=[]
    for l in range(1,L+1):
        x=2*I(l)*B/(5*N0);radial.append(c.upper_float((1+iv.exp(-A*l))*(iv.exp(x)-iv.exp(-x))/16))
    variation=c.upper_float(iv.pi**3/(30*Q)*(1/(1-I(K)/Q)+6/(1-I(5*K)/Q)))
    partial=c.upper_float(4*sum((iv.exp(-eta*l)/l for l in range(L+1,K+1)),I(0)))
    penalty=c.upper_float(2*eta+4*iv.exp(-eta*K)/(eta*K));rows=[]
    for b in range(2*K+1,Q+1):
        if b%5==0:continue
        r=np.arange(1,b//2+1,dtype=np.int64)
        s1,_=c.sin_pi_rational_abs(r,b);_,s4=c.sin_pi_rational_abs(4*r,b);s5,_=c.sin_pi_rational_abs(5*r,b)
        g=c.up(s4/c.down(s1*s5));nums=r[np.gcd(r,b)==1];peak=0.
        for offset in range(0,len(nums),128):
            aa=nums[offset:offset+128];used=[];prefix=np.zeros(len(aa))
            for l in range(1,L+1):
                rem=aa*l%b;s=np.minimum(rem,b-rem);rem=5*aa*l%b;s5=np.minimum(rem,b-rem);used.append(s)
                den=c.down(c.down(s-c.upper_float(I(l)/Q))*c.down(s5-c.upper_float(I(5*l)/Q)))
                assert np.all(den>0)
                extra=c.up(c.up(c.up(radial[l-1]*b)*b)/den)
                prefix=c.up(prefix+c.up(weights[l-1]*c.up(c.up(finite[l-1]*g[s-1])+extra)))
            tail=tails.remaining_tail(g,np.array(used).T,weights)
            peak=max(peak,float(np.max(c.up(prefix+tail))))
        total=math.nextafter(peak+math.nextafter(variation*b,math.inf),math.inf)
        total=math.nextafter(total+partial,math.inf)
        rows.append({'b':b,'cost_upper':total,'penalty_upper':penalty})
        if len(rows)%500==0:print('Extended certificate',len(rows),'denominators',flush=True)
    report={'status':'passed','scope':'Uniform finite-block costs on the recorded tau rectangle and n minimum; inherits outward arithmetic assumptions of certify_tail.py',
      'tau':[float(A.a),float(B.b)],'n_min':N0,'Q':Q,'K':K,'prefix':L,'eta':'11313/1250000','denominators':len(rows),'rows':rows}
    (OUT/filename).write_text(json.dumps(report,indent=2)+'\n')
    return report

def run():
    global A,B,N0
    low_path=OUT/'extension_certificate.json'
    report=json.loads(low_path.read_text()) if low_path.exists() else generate()
    A=I(3);B=I('5.5');N0=4000
    high_path=OUT/'high_extension_certificate.json'
    if high_path.exists():high=json.loads(high_path.read_text())
    else:
        high=generate('high_extension_certificate.json')
    options=[]
    for item in [report,high]:
        cost=np.full(Q,np.inf);penalty=np.zeros(Q)
        for row in item['rows']:cost[row['b']-1]=row['cost_upper'];penalty[row['b']-1]=row['penalty_upper']
        options.append((item,cost,penalty))
    prior_gaps=previous.gaps
    def gaps(n,ta,tb,mode):
        base=prior_gaps(n,ta,tb,mode);ns=np.atleast_1d(n).astype(float)
        for item,cost,penalty in options:
            if ta>=item['tau'][0] and tb<=item['tau'][1]:
                candidate=float(old.radial(tb)[0])-penalty-cost/ns[:,None]
                base=np.maximum(base,np.where((ns>=item['n_min'])[:,None],candidate,-np.inf))
        return base
    arc.prior.gaps=gaps;arc.prior.ratios=previous.ratios
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    baseline=json.loads((WORK/'proposal-completion/results/bulk_thresholds_adaptive.json').read_text())
    hs=[.2,.25,.285,.29,.295,.3,.305,.31,.315,.35,.4];combined=[]
    for cell,prior in zip(cells,baseline):
        ta,tb=old.ends(cell['tau_interval'])
        if not any(ta>=item['tau'][0] and tb<=item['tau'][1] for item,_,_ in options):combined.append(prior);continue
        variants=[arc.prior.thresholds([cell],f'{h}:full')[0] for h in hs]
        row={'cell':cell['cell'],'tau':[ta,tb],'first_passing_n':[],'at_first_pass':[],'selected_h':[]}
        for a in range(5):
            j=min(range(len(hs)),key=lambda j:variants[j]['first_passing_n'][a])
            row['first_passing_n'].append(variants[j]['first_passing_n'][a]);row['at_first_pass'].append(variants[j]['at_first_pass'][a]);row['selected_h'].append(hs[j])
        assert all(new<=old_n for new,old_n in zip(row['first_passing_n'],prior['first_passing_n']))
        combined.append(row)
    (OUT/'bulk_thresholds_adaptive.json').write_text(json.dumps(combined,indent=2)+'\n')
    summary=old.frontier(combined,'adaptive',OUT)
    print(json.dumps({k:v for k,v in summary.items() if k!='samples'}),flush=True)

if __name__=='__main__':run()
