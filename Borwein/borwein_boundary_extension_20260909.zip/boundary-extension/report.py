import json,sys
sys.stdout.reconfigure(encoding='utf-8')
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;OUT=ROOT/'results'
def run():
    old=json.loads((WORK/'proposal-completion/results/summary_adaptive.json').read_text())
    new=json.loads((OUT/'summary_adaptive.json').read_text())
    prior=json.loads((WORK/'feasibility/results/estimates.json').read_text())['current_frontier']
    estimate=json.loads((OUT/'feasibility.json').read_text());now=estimate['current_frontier']
    audit=json.loads((OUT/'audit.json').read_text());assert audit['status']=='passed'
    rows=json.loads((OUT/'bulk_thresholds_adaptive.json').read_text());bulk=max(max(r['first_passing_n']) for r in rows)
    peak=new['maximum_uncovered_degree'];reduction=100*(1-peak/old['maximum_uncovered_degree'])
    text=f'''# 有限ブロック評価の境界拡張 — 2026-09-09

前回の最大未処理次数の山が、評価の適用境界 τ=3 と n=6000 に近かったため、同じ有限ブロック不等式を別の長方形にも一様化した。既存評価を残し、適用できる上界のうち有利なものを選ぶ。

## 結果（被覆は未認証の診断）

| 指標 | 前回 | 今回 |
|---|---:|---:|
| 最大未処理次数 | {old['maximum_uncovered_degree']:,} | {peak:,} |
| その n | {old['n_at_maximum']:,} | {new['n_at_maximum']:,} |
| 未処理係数数（下半分） | {old['remaining_lower_half_coefficients']:,} | {new['remaining_lower_half_coefficients']:,} |
| 整数減算回数のモデル | {prior['integer_subtractions']:,} | {now['integer_subtractions']:,} |
| 時間見積り（3倍余裕込み） | {prior['planning_seconds_3x']/86400:.2f}日 | {now['planning_seconds_3x']/86400:.2f}日 |
| メモリ見積り | {prior['memory_planning_bytes']/1024**3:.2f} GiB | {now['memory_planning_bytes']/1024**3:.2f} GiB |

最大次数は {reduction:.2f}% 減少。bulk候補は {bulk:,}。640個のセル・剰余類の組のうち、{audit['changed_thresholds']}個で通過する n が下がった。

所要時間は既存の短時間実測に基づくRAM内計算モデルで、完走保証ではない。メモリ予算8 GiBを超える場合、このPCで上記時間のまま走るとは主張できない。係数数が減っても、将来必要な係数を保持して更新するコストが残る。

## 到達ラインとの距離

暫定目安は最大300万次で約1週間、95万次で約1日。今回の最大次数は300万次の {peak/3000000:.2f}倍。時間・メモリを合わせた7日ゲートは **{estimate['performance_gate_7d']}**、24時間ゲートは **{estimate['performance_gate_24h']}**。

したがって、今回も到達ラインを達成したとは扱わない。最大次数の山は n={new['n_at_maximum']} に移った。最後の τ セルでは a=3 の通過 n=9362、支配分母 b=5 が残っている。次の候補はこの共鳴評価の改善、または整数計算器のメモリ削減である。

## 変更と検証

- 新規適用領域 τ∈[1,3.05], n≥2500 と τ∈[3,5.5], n≥4000。それぞれ2163分母について先頭32周波数と使用済み距離を除いた尾部を上から評価。
- 既存の全候補を保持。全セルで通過閾値、全nで未処理次数・係数数が悪化していないことを確認。
- 選択した640点の3円弧予算を60桁区間で再計算し、単調減衰条件も確認。30,634行の被覆CSVと将来保持次数を照合。
- 完全な局在化・係数位置への写像の認証は未完了。全域の作業稿閾値 n≥31147、全行の厳密整数検算 n≤512 は変更なし。

式の根拠は [DERIVATION.md](DERIVATION.md)。局所上界の証明書と診断値は `results/` に分けて保存している。

## 再実行

既存パッケージと同じ Python、NumPy、mpmath 環境で、プロジェクトのルートから：

```text
python boundary-extension/run.py
python feasibility/estimate.py --frontier boundary-extension/results/frontier_adaptive.csv --output boundary-extension/results/feasibility.json
python boundary-extension/audit.py
python boundary-extension/report.py
python boundary-extension/package.py
```

`run.py` は2つの局所証明書JSONがあれば再利用する。上界計算から再実行する場合はその2ファイルを別名で退避する。旧結果は各ラウンドのフォルダ・ZIPに保存。

AI使用：改善点の探索、式の整理、実装、実行結果の確認、本文の作成に OpenAI Codex を使用。趣味の研究記録であり、外部専門家による査読は受けていない。著者名は付さない。
'''
    (ROOT/'README.md').write_text(text,encoding='utf-8')
    print(text)
if __name__=='__main__':run()
