"""Append this round to the verified previous review bundle."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
assert json.loads((ROOT/'results/audit.json').read_text())['status']=='passed'
with zipfile.ZipFile(WORK/'borwein_feasibility_20260909.zip') as z:
    assert z.testzip() is None
    contents={}
    for row in json.loads(z.read('BUNDLE_MANIFEST.json'))['files']:
        raw=z.read(row['path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        contents[row['path']]=raw
for p in ROOT.rglob('*'):
    r=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in r.parts):contents['boundary-extension/'+r.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 境界拡張・2026-09-09

最新の改善試行は [boundary-extension/README.md](boundary-extension/README.md)。
正確な5nブロック評価の適用領域を拡張し、被覆と同じ実測モデルの時間・メモリ見積りを更新。
被覆全体は未認証の診断。全域作業稿閾値31147・全行整数検算n≤512は変更なし。
従来の原稿、証明書、コード、計測、記録も同梱。AI使用は各記録に明記。著者名なし。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_boundary_extension_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(contents),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
