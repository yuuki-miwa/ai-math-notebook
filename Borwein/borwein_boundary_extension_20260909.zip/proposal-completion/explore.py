import argparse,json,time
from model import *

def run(last_only=False):
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    variants=['structure','moments','full'];scan=[]
    # Resolve the next candidate width at 0.005 spacing on the previously limiting cell.
    for variant in variants:
        for k in range(30,81):
            h=k/200
            if np.max(ratios(cells[-1],[31147],f'{h}:{variant}')[0])>=.98:
                scan.append({'variant':variant,'h':h,'first_passing_n':[31148]*5,'scope':'No all-residue pass by 31147','details':None});continue
            row=arc.prior.thresholds([cells[-1]],f'{h}:{variant}')[0]
            scan.append({'variant':variant,'h':h,'first_passing_n':row['first_passing_n'],'details':row['at_first_pass']})
        best=min((r for r in scan if r['variant']==variant),key=lambda r:max(r['first_passing_n']))
        print('Last-cell',variant,'best h',best['h'],'n',max(best['first_passing_n']),flush=True)
    (OUT/'width_scan.json').write_text(json.dumps(scan,indent=2)+'\n')
    if last_only:return
    center=min((r for r in scan if r['variant']=='full'),key=lambda r:max(r['first_passing_n']))['h']
    hs=sorted(set([.2,.25,.3,.35,.4]+[round(center+j*.005,3) for j in range(-3,4) if .15<=center+j*.005<=.4]))
    allrows=[]
    for h in hs:
        rows=arc.prior.thresholds(cells,f'{h}:full');allrows.append(rows)
        print('Full grid h',h,'bulk',max(max(r['first_passing_n']) for r in rows),flush=True)
    combined=[]
    for i in range(128):
        row={'cell':i,'tau':allrows[0][i]['tau'],'first_passing_n':[],'at_first_pass':[],'selected_h':[]}
        for a in range(5):
            j=min(range(len(hs)),key=lambda j:allrows[j][i]['first_passing_n'][a])
            row['first_passing_n'].append(allrows[j][i]['first_passing_n'][a]);row['at_first_pass'].append(allrows[j][i]['at_first_pass'][a]);row['selected_h'].append(hs[j])
        combined.append(row)
    (OUT/'bulk_thresholds_adaptive.json').write_text(json.dumps(combined,indent=2)+'\n')
    summary=old.frontier(combined,'adaptive',OUT)
    print(json.dumps({k:v for k,v in summary.items() if k!='samples'}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--last-only',action='store_true');run(p.parse_args().last_only)
