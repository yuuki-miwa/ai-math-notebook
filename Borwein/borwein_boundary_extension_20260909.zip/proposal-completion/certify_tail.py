"""Remove used distances for each numerator before rearranging the tail."""
import json,math,time
from common import *
Q=4139;K=718;L=32;N0=6000

def upper_sum_rows(products):
    # For nonnegative binary64 inputs and any binary summation tree of at most
    # K-1 additions, fl(sum)>=exact_sum*(1-(K-1)*u). No subnormals occur here.
    correction=c.upper_float(1/(1-I(K)/2**53))
    return c.up(np.sum(products,axis=1)*correction)

def remaining_tail(g,used,weights):
    order=np.argsort(g)[::-1][:K];top=g[order];inverse=np.full(len(g),K,dtype=int)
    inverse[order]=np.arange(K)
    mask=np.ones((len(used),K),dtype=bool)
    usedrank=inverse[used-1]
    for j in range(L):
        ids=np.flatnonzero(usedrank[:,j]<K);mask[ids,usedrank[ids,j]]=False
    rank=np.cumsum(mask,axis=1)-1
    chosen=mask&(rank<K-L)
    assert np.all(chosen.sum(axis=1)==K-L)
    coeff=weights[L+np.clip(rank,0,K-L-1)]
    products=c.up(coeff*top[None,:]);products=np.where(chosen,products,0.)
    return upper_sum_rows(products)

def run():
    start=time.perf_counter();eta=I(11313)/1250000
    weights=np.array([c.upper_float(iv.exp(-eta*l)/l) for l in range(1,K+1)])
    finite=np.array([c.upper_float((1+iv.exp(-3*l))/2) for l in range(1,L+1)])
    radial=[]
    for l in range(1,L+1):
        x=2*I(l)*I('5.5')/(5*N0)
        radial.append(c.upper_float((1+iv.exp(-3*l))*(iv.exp(x)-iv.exp(-x))/16))
    variation=c.upper_float(iv.pi**3/(30*Q)*(1/(1-I(K)/Q)+6/(1-I(5*K)/Q)))
    partial=c.upper_float(4*sum((iv.exp(-eta*l)/l for l in range(L+1,K+1)),I(0)))
    fullpartial=c.upper_float(4*iv.log(2/eta))
    penalty=c.upper_float(2*eta+4*iv.exp(-eta*K)/(eta*K))
    rows=[];audits=[];numerators=0
    for b in range(2*K+1,Q+1):
        if b%5==0:continue
        r=np.arange(1,b//2+1,dtype=np.int64)
        s1,_=c.sin_pi_rational_abs(r,b);_,s4=c.sin_pi_rational_abs(4*r,b);s5,_=c.sin_pi_rational_abs(5*r,b)
        g=c.up(s4/c.down(s1*s5));nums=r[np.gcd(r,b)==1]
        maximum=0.;maxplain=0.;winner=0
        for offset in range(0,len(nums),128):
            aa=nums[offset:offset+128];used=[];pre=np.zeros(len(aa));plain=np.zeros(len(aa))
            for l in range(1,L+1):
                rem=aa*l%b;s=np.minimum(rem,b-rem);rem=5*aa*l%b;s5=np.minimum(rem,b-rem);used.append(s)
                den=c.down(c.down(s-c.upper_float(I(l)/Q))*c.down(s5-c.upper_float(I(5*l)/Q)))
                extra=c.up(c.up(c.up(radial[l-1]*b)*b)/den)
                pre=c.up(pre+c.up(weights[l-1]*c.up(c.up(finite[l-1]*g[s-1])+extra)))
                plain=c.up(plain+c.up(weights[l-1]*g[s-1]))
            used=np.array(used).T
            assert np.all(np.diff(np.sort(used,axis=1),axis=1)>0)
            tail=remaining_tail(g,used,weights)
            sums=c.up(pre+tail);pos=np.argmax(sums)
            if sums[pos]>maximum:maximum=float(sums[pos]);winner=int(aa[pos])
            maxplain=max(maxplain,float(np.max(c.up(plain+tail))))
            numerators+=len(aa)
            if b in [1437,2069,3001,4136,4139] and offset==0:
                excluded=set(map(int,used[0]));pool=sorted((float(g[j-1]) for j in range(1,len(g)+1) if j not in excluded),reverse=True)[:K-L]
                exact=sum((I(float(weights[L+j]))*I(v) for j,v in enumerate(pool)),I(0))
                assert bool(I(float(tail[0])).a>=exact.b)
                audits.append({'b':b,'a':int(aa[0]),'tail_upper':float(tail[0]),'independent_interval_tail':str(exact)})
        var=math.nextafter(variation*b,math.inf)
        value=math.nextafter(math.nextafter(maximum+var,math.inf)+partial,math.inf)
        plainvalue=math.nextafter(math.nextafter(maxplain+var,math.inf)+fullpartial,math.inf)
        rows.append({'b':b,'finite_cost_upper':value,'plain_cost_upper':plainvalue,'penalty_upper':penalty,'maximizing_numerator_for_upper_bounds':winner})
        if len(rows)%400==0:print('Tail certificate:',len(rows),'denominators',flush=True)
    report={'status':'passed','Q':Q,'K':K,'prefix':L,'eta':'11313/1250000','finite_tau':[3,5.5],'finite_n_min':N0,
      'scope':'Uniform tail-excluded costs, all coprime numerators; not full coverage',
      'summation_assumption':'IEEE binary64, nonnegative normal products, no fast-math; summation error allowance K*2^-53',
      'denominators':len(rows),'numerators_checked':numerators,'seconds':time.perf_counter()-start,'rows':rows,'independent_tail_checks':audits}
    (OUT/'tail_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Tail complete',len(rows),numerators,report['seconds'],flush=True)

if __name__=='__main__':run()
