"""Real central absolute-moment integral enclosures for complex cumulants."""
import json,time
from common import *

def run():
    start=time.perf_counter();m=200;rows=[]
    for cell in range(128):
        ta=I(11)*cell/256;tb=I(11)*(cell+1)/256;tau=I([ta.a,tb.b])
        totals={key:I(0) for key in ['A3','A4','B4','B5','C6','D8']}
        for j in range(m):
            xa=I(j)/m;xb=I(j+1)/m;y=iv.exp(-tau*I([xa.a,xb.b]))
            power=[y**k for k in range(5)];den=sum(power,I(0));p=[v/den for v in power]
            mean=sum((k*p[k] for k in range(5)),I(0))
            v=sum(((k-l)**2*p[k]*p[l] for k in range(5) for l in range(k)),I(0))
            m3=sum((p[k]*abs(I(k)-mean)**3 for k in range(5)),I(0))
            m4=sum((p[k]*(I(k)-mean)**4 for k in range(5)),I(0))
            for key,value,degree in [('A3',m3,3),('A4',m4,4),('B4',v*v,4),('B5',v*m3,5),('C6',v**3,6),('D8',v**4,8)]:
                totals[key]+=value*(xb**(degree+1)-xa**(degree+1))/(degree+1)
        rows.append({'cell':cell,'tau':str(tau),**{k:str(v) for k,v in totals.items()}})
        if cell%32==31:print('Central moments',cell+1,'cells',flush=True)
    report={'status':'passed','scope':'Real moment integral interval enclosures on 128 tau cells; not full sign proof',
      'precision':70,'x_cells':m,'tau_cells':128,'seconds':time.perf_counter()-start,'rows':rows}
    (OUT/'moment_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Moments complete',report['seconds'],flush=True)

if __name__=='__main__':run()
