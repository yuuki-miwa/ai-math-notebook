import importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
f=load('finite_block_model',WORK/'finite-block/run.py')
c=f.c;np=f.np;iv=f.iv;I=iv.mpf;arc=f.arc;old=f.old
