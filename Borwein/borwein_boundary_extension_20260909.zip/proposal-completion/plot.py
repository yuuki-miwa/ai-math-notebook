import csv,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'coverage-frontier/.plot-deps'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.mplconfig')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
for folder,label in [('localization-tuning','Before proposal: 29.0 million'),('finite-block','Finite blocks + Jensen: 24.5 million'),('proposal-completion','All proposal components tested: 22.9 million')]:
    with (ROOT.parent/folder/'results/frontier_adaptive.csv').open() as f:rows=list(csv.DictReader(f))
    ax.plot([int(r['n']) for r in rows],[int(r['last_uncovered_degree']) for r in rows],label=label,lw=1.7)
ax.set(xlabel='Product index n',ylabel='Largest uncovered degree m',yscale='log',ylim=(1e5,6e7),xlim=(513,31146),title='Coverage after the remaining proposals — diagnostic, not certified')
ax.grid(alpha=.2);ax.legend(fontsize=9)
for ext in ['png','svg']:fig.savefig(ROOT/'results'/f'comparison.{ext}',dpi=160)
