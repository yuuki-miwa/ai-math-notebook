"""Package verified preceding material plus all proposal-completion artifacts."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
audit=json.loads((ROOT/'results/completion_audit.json').read_text(encoding='utf-8'))
assert audit['status']=='passed'
with zipfile.ZipFile(WORK/'borwein_finite_block_20260909.zip') as z:
    assert z.testzip() is None
    previous=json.loads(z.read('BUNDLE_MANIFEST.json'));contents={}
    for row in previous['files']:
        raw=z.read(row['path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        contents[row['path']]=raw
for p in ROOT.rglob('*'):
    r=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in r.parts):contents['proposal-completion/'+r.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 提案5項目の完了記録・2026-09-09

最新結果は [proposal-completion/README.md](proposal-completion/README.md) を参照。
共有された5項目を実装・検証し、要件ごとの監査を記録しました。
最大未処理次数の診断値22,927,674、bulk通過候補9362。
全域の解析作業稿閾値31147、厳密整数検算n≤512は変更していません。
被覆全体は未認証の数値診断です。全予想の証明完了ではありません。

過去ラウンドも同梱。過去の「未実装」等は各文書の作成時点の記録です。
Python、NumPy、mpmath、図にはMatplotlibが必要。依存パッケージは同梱しません。
AI使用は各記録に明記。著者名なし。独立査読・Lean証明の完了は主張しません。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_proposal_completed_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(contents),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'verification':'Every bundled byte hash matched'},indent=2))
