"""Requirement evidence and consistency audit; not a theorem verifier."""
import csv,json,hashlib
from common import *
ac=load('arc_constants_audit',WORK/'arc-improvement/certify_arcs.py')

def run():
    reports={name:json.loads((OUT/name).read_text()) for name in ['tail_certificate.json','square_gap_certificate.json','moment_certificate.json','budget_certificate.json','independent_audit.json']}
    assert all(r['status']=='passed' for r in reports.values())
    assert reports['tail_certificate.json']['denominators']==2163
    assert reports['tail_certificate.json']['numerators_checked']==1909727
    assert len(reports['tail_certificate.json']['independent_tail_checks'])==5
    assert reports['square_gap_certificate.json']['t_cells']==20
    assert reports['square_gap_certificate.json']['adopted_gap_decimal']=='0.01014301'
    assert reports['moment_certificate.json']['tau_cells']==128
    assert reports['budget_certificate.json']['count']==640
    scan=json.loads((OUT/'width_scan.json').read_text())
    for variant in ['structure','moments','full']:
        subset=[r for r in scan if r['variant']==variant]
        assert len(subset)==51 and [r['h'] for r in subset]==[i/200 for i in range(30,81)]
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    selected=json.loads((OUT/'bulk_thresholds_adaptive.json').read_text())
    monotone=0
    for cell,row in zip(cells,selected):
        vlo=ac.parse(cell['V_interval']).a
        for a in range(5):
            decay=ac.constants(str(row['selected_h'][a]))[-1]
            rate=min(r for width,r in decay)
            # Then sqrt(n)*exp(-rate*V*n) decreases for every future n;
            # the remaining EM-amplitude factor also decreases.
            assert bool((I(row['first_passing_n'][a])*vlo*rate).a>I('.5').b)
            monotone+=1
    with (OUT/'frontier_adaptive.csv').open() as f:records=list(csv.DictReader(f))
    assert [int(r['n']) for r in records]==list(range(513,31147))
    summary=json.loads((OUT/'summary_adaptive.json').read_text())
    assert max(int(r['last_uncovered_degree']) for r in records)==summary['maximum_uncovered_degree']
    assert sum(int(r['uncovered_coefficients_lower_half']) for r in records)==summary['remaining_lower_half_coefficients']
    later=-1
    for row in reversed(records):
        later=max(later,int(row['last_uncovered_degree']));assert int(row['future_retention_degree'])==later
    evidence=[
      {'requirement':'1. 使用済み距離除去','status':'implemented_and_interval_checked','evidence':['certify_tail.py','results/tail_certificate.json'],'scope':'All 2163 eligible denominators and all coprime numerators up to reflection'},
      {'requirement':'2. 有限5nブロック保持','status':'retained_and_combined','evidence':['../finite-block/DERIVATION.md','certify_tail.py'],'scope':'Prefix 32, tau in [3,5.5], n>=6000, with excluded tail'},
      {'requirement':'3. hの再探索','status':'executed','evidence':['results/width_scan.json','results/bulk_thresholds_adaptive.json'],'scope':'0.005 grid on last cell for three variants; 11 widths on all 128 cells for final model'},
      {'requirement':'4. 点ごとのS²','status':'implemented_and_interval_checked','evidence':['certify_square.py','results/square_gap_certificate.json'],'scope':'All cross terms; uniform tau [0,5.5] and |t|>=1.2 by strip plus analytic tail'},
      {'requirement':'5. cumulant/middle','status':'implemented_and_checked','evidence':['certify_moments.py','model.py','certify_budgets.py','results/independent_audit.json'],'scope':'Real moments, combined intermediate amplitude, exact-phase Gaussian extension'},
      {'requirement':'6. 記録と再現物','status':'ready_for_packaging','evidence':['README.md','DERIVATION.md','results/summary_adaptive.json','package.py'],'scope':'Full coverage remains diagnostic; package byte verification is performed by package.py'}]
    for item in evidence:
        for name in item['evidence']:assert (ROOT/name).is_file(),name
    out={'status':'passed','objective':'提案を使い切るまで続ける','scope':'Completion audit of the five concrete proposals, not proof of the conjecture',
      'monotone_tail_checks':monotone,'frontier_rows':len(records),'requirements':evidence,
      'limitations':['No full interval certification of localization/mapping','No new exact finite coefficient verification','No independent mathematical peer review or Lean proof'],
      'result_hashes':{name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in reports}}
    (OUT/'completion_audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('Completion evidence checks passed:',monotone,'future-tail checks,',len(records),'frontier rows')

if __name__=='__main__':run()
