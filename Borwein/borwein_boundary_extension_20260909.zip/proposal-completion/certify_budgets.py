"""Independent interval re-evaluation of final three-arc budgets."""
import json,time
from common import *
ac=load('arc_interval_verifier',WORK/'arc-improvement/certify_arcs.py')
parse=ac.parse

def evaluate(cell,moment,n,a,hstr):
    h,beta,c3,c4,decay=ac.constants(hstr);n=I(n);q=iv.cos(2*h)
    tau=parse(cell['tau_interval']);ta=tau.a;tb=tau.b
    V=parse(cell['V_interval']);vlo=V.a;vhi=min(V.b,(I(4)/3).b)
    phase=parse(cell['signed_phase_intervals'][a]);pl=phase.a;ph=phase.b
    w3=parse(cell['W3_interval']).b;w4=parse(cell['W4_interval']).b
    m={k:parse(moment[k]).b for k in ['A3','A4','B4','B5','C6','D8']}
    T3=min((c3*w3).b,(m['A3']/q+3*h*m['B4']/q**2+2*h**3*m['C6']/q**3).b)
    T4=min((c4*w4).b,(m['A4']/q+(4*h*m['B5']+3*m['B4'])/q**2+12*h*h*m['C6']/q**3+6*h**4*m['D8']/q**4).b)
    x=iv.exp(-ta);d=max(I('.75').a,(1-x).a)
    M=iv.exp(I('.8')*h/I('.75')).b
    if bool(ta>0):M=min(M,(1/(1-x)).b)
    a1=I('.8')*M*x/d;a2=M/2*(I('.8')*x/d**2+(I('.8')*x/d)**2)
    H=(ph*(T4/(32*beta**2*vlo**2)+5*T3*T3/(192*beta**3*vlo**3))+4*(T3*a1/(8*beta**2*vlo**2)+a2/(2*beta*vlo)))/iv.sqrt(2*beta)
    Z=iv.sqrt(tb*tb+h*h);D=Z*(I(1)/30+2*x/(25*d))
    E=(Z/30*(ph+4*h*a1)+8*M*Z*x/(25*d))/iv.sqrt(2*beta)
    weight=(1-x)/ta if bool(ta>0) else I(1)
    em=min(I(3400).b,(8*Z**3/I('.75')**3*weight).b)
    U=4*M/iv.sqrt(2*beta)*(em+D*D/2)*iv.exp(D/n+em/n**2)
    main=((H+E)/n+U/n**2)/pl
    Mb=min(I(6).b,(1/(1-x)).b) if bool(ta>0) else I(6)
    psi=4*Mb
    if a>=3 and bool(ta>0):psi=min(psi,(4*x/(1-x)).b)
    total=I(0)
    for j,(width,rate) in enumerate(decay):
        v=h+(I('1.2')-h)*(j+1)/256
        dv=iv.sin(2*iv.pi/5-v).a;dp=max(dv,(1-x).a);zv=iv.sqrt(tb*tb+v*v)
        Dv=zv*(I(1)/30+2*x/(25*dp));emv=8*zv**3/dv**3*weight
        error=min((7200/n).b,(Dv/n+emv/n**2).b)
        total+=width*(psi+4*Mb*(iv.exp(error)-1))*iv.exp(-n*vlo*rate)
    middle=2*iv.sqrt(vhi/(2*iv.pi))*iv.sqrt(n)*total/pl
    power=h*h*vlo*n/2
    gaussian=min(I(1).b,(iv.exp(-power)/iv.sqrt(iv.pi*power)).b)*ph/pl
    return main,middle,gaussian

def run():
    start=time.perf_counter();iv.dps=60
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    moments=json.loads((OUT/'moment_certificate.json').read_text())['rows']
    selected=json.loads((OUT/'bulk_thresholds_adaptive.json').read_text());rows=[];largest=0.
    for cell,moment,record in zip(cells,moments,selected):
        for a in range(5):
            n=record['first_passing_n'][a];h=str(record['selected_h'][a])
            values=evaluate(cell,moment,n,a,h);total=sum(values,I(0))
            assert bool(total.b<I('.98').a),(cell['cell'],a,total)
            for value,key in zip(values,['local_main','intermediate','gaussian_tail']):
                number=record['at_first_pass'][a]['components'][key]
                error=abs(float(value.b)-number);largest=max(largest,error)
                assert error<1e-10*max(1,number),(cell['cell'],a,key,error)
            rows.append({'cell':cell['cell'],'a':a,'n':n,'h':h,'three_arc_sum_upper':str(total.b),
              'main_upper':str(values[0].b),'middle_upper':str(values[1].b),'gaussian_upper':str(values[2].b),
              'minor_budget_lower':str((I('.98')-total).a)})
        if cell['cell']%32==31:print('Final interval budgets',cell['cell']+1,'cells',flush=True)
    result={'status':'passed','scope':'640 new three-arc budgets conditional on inherited profiles and moment certificate; excludes full localization/mapping certification',
      'precision':60,'count':len(rows),'maximum_float_discrepancy':largest,'seconds':time.perf_counter()-start,'rows':rows}
    (OUT/'budget_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Budget complete',largest,result['seconds'],flush=True)

if __name__=='__main__':run()
