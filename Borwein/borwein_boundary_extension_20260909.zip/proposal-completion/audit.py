"""Independent multiprecision samples supplement (do not replace) proofs."""
import json,time
from common import *
from mpmath import mp
mp.dps=65

def R(z):return (2*mp.pi**2/15+mp.polylog(2,mp.exp(-5*z))/5-mp.polylog(2,mp.exp(-z)))/z
def run():
    start=time.perf_counter();zeta=mp.exp(2j*mp.pi/5);rows=[]
    for tau in [mp.mpf('.5'),mp.mpf(3),mp.mpf('5.5')]:
        for tt in [mp.mpf('.3'),mp.mpf('.7'),mp.mpf('1.19')]:
            z=tau-1j*tt;dv=mp.sin(2*mp.pi/5-tt);x=mp.exp(-tau)
            zv=abs(z);Dp=zv*(mp.mpf(1)/30+2*x/(25*max(dv,1-x)))
            E2=8*zv**3/dv**3*(1-x)/tau
            for n in [64,256]:
                finite=[];amps=[];maxrelative=mp.mpf(0)
                for ell in range(1,5):
                    lam=sum((mp.mpf(j)/5-mp.mpf('.5'))*(mp.log(1-zeta**(ell*j)*mp.exp(-z))-mp.log(1-zeta**(ell*j))) for j in range(1,5))
                    D=z/2*sum(((mp.mpf(j)/5)**2-mp.mpf(j)/5+mp.mpf(1)/6)*(zeta**(ell*j)*mp.exp(-z)/(1-zeta**(ell*j)*mp.exp(-z))-zeta**(ell*j)/(1-zeta**(ell*j))) for j in range(1,5))
                    logprod=sum(mp.log(1-zeta**(ell*k)*mp.exp(-z*k/(5*n))) for k in range(1,5*n+1) if k%5)
                    residual=abs(logprod-n*R(z)-lam-D/n)
                    assert abs(D)<=Dp and residual<=E2/n**2
                    maxrelative=max(maxrelative,residual/(E2/n**2));finite.append(mp.exp(logprod-n*R(z)));amps.append(mp.exp(lam))
                Mb=min(6,1/(1-x));bound=min(4*Mb,4*x/(1-x))+4*Mb*mp.expm1(Dp/n+E2/n**2)
                for a in [3,4]:
                    value=abs(sum(zeta**(-a*(j+1))*finite[j] for j in range(4)))
                    assert value<=bound
                rows.append({'tau':str(tau),'t':str(tt),'n':n,'maximum_EM_remainder_over_bound':mp.nstr(maxrelative,25)})
    momentrows=json.loads((OUT/'moment_certificate.json').read_text())['rows'];momentchecks=[]
    for index in [0,64,127]:
        tau=mp.mpf(11)*(2*index+1)/512
        def integrand(x,key):
            powers=[mp.exp(-tau*x*j) for j in range(5)];p=[v/sum(powers) for v in powers]
            mean=sum(j*p[j] for j in range(5));v=sum(p[j]*(j-mean)**2 for j in range(5))
            m3=sum(p[j]*abs(j-mean)**3 for j in range(5));m4=sum(p[j]*(j-mean)**4 for j in range(5))
            return {'A3':x**3*m3,'A4':x**4*m4,'B4':x**4*v*v,'B5':x**5*v*m3,'C6':x**6*v**3,'D8':x**8*v**4}[key]
        for key in ['A3','A4','B4','B5','C6','D8']:
            value=mp.quad(lambda x:integrand(x,key),[0,.25,.5,.75,1]);a,b=momentrows[index][key].strip('[]').split(',')
            assert mp.mpf(a)<value<mp.mpf(b)
            momentchecks.append({'cell':index,'quantity':key,'quadrature':mp.nstr(value,30)})
    for v in ['.1','1','3','8']:
        x=mp.mpf(v);assert mp.erfc(x)<=min(1,mp.exp(-x*x)/(mp.sqrt(mp.pi)*x))
    report={'status':'passed','scope':'Finite independent 65-digit checks, not interval coverage certification',
      'EM_and_combined_middle_cases':rows,'moment_quadrature_checks':momentchecks,'Gaussian_tail_samples':4,'seconds':time.perf_counter()-start}
    (OUT/'independent_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Independent audit passed',len(rows),len(momentchecks),report['seconds'],flush=True)

if __name__=='__main__':run()
