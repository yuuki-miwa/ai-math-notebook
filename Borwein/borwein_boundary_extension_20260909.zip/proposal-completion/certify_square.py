"""Pointwise S+S^2, with all cross terms, on a finite t strip; uniform tail."""
import json,time
from common import *

def run():
    start=time.perf_counter();m=2400;eta=I(113)/40000;upper=I('5.5')
    # W_d lower envelopes valid for every tau in [0,5.5].
    weights=[]
    for i in range(1,m+1):
        y=iv.exp(-eta-upper*i/m);den=sum((y**j for j in range(5)),I(0))**2
        weights.append([min((I(5-d)/25).a,(sum((y**(2*j+d) for j in range(5-d)),I(0))/den).a) for d in range(1,5)])
    rows=[]
    for j in range(20):
        ta=I(1200+j)/1000;tb=I(1201+j)/1000;total=I(0);linear=I(0);squared=I(0)
        for i in range(m):
            xa=I(i)/m;xb=I(i+1)/m;S=I(0)
            for d in range(1,5):
                angle=I([(d*ta*xa).a,(d*tb*xb).b])
                factor=max(I(0).a,(1-iv.cos(angle)).a)
                S+=weights[i][d-1]*factor
            linear+=S/m;squared+=S*S/m
        total=linear+squared
        rows.append({'t':[str(ta.a),str(tb.b)],'linear_lower':str(linear.a),'square_lower':str(squared.a),'sum_lower':str(total.a)})
        print('S^2 strip',j+1,'lower',float(total.a),flush=True)
    # Beyond t=1.22, the existing staircase/sinc lemma gives a uniform floor.
    tail=I(0)
    for d in range(1,5):
        for i in range(m):
            current=weights[i][d-1];following=weights[i+1][d-1] if i+1<m else I(0)
            assert bool(current>=following)
            b=I(i+1)/m;a=min(I(2).a,(I('1.22')*d*b).a)
            tail+=(current-following)*b*(a*a/6-a**4/120)
    # Decimal rational adoption is checked against every interval lower end.
    smallest=min([float(r['sum_lower'].strip('[]').split(',')[0]) for r in rows]+[float(tail.a)])
    adoption=I(str(int(smallest*10**9)/10**9))
    for row in rows:assert bool(adoption.b<I(row['sum_lower'].strip('[]').split(',')[0]).a)
    assert bool(adoption.b<tail.a)
    result={'status':'passed','scope':'Uniform logarithmic gap for tau in [0,5.5], |t|>=1.2 at eta=113/40000',
      'x_cells':m,'t_strip':[1.2,1.22],'t_cells':20,'precision':70,'adopted_gap':str(adoption),'adopted_gap_decimal':str(int(smallest*10**9)/10**9),
      'large_t_linear_lower':str(tail.a),'seconds':time.perf_counter()-start,'rows':rows}
    (OUT/'square_gap_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Square complete',result['adopted_gap_decimal'],result['seconds'],flush=True)

if __name__=='__main__':run()
