"""Combined proposal model. Returned coverage ratios are binary64 diagnostics."""
import json,functools
from common import *
Q=4139;K=718
tail=json.loads((OUT/'tail_certificate.json').read_text())
square=json.loads((OUT/'square_gap_certificate.json').read_text())
moments=json.loads((OUT/'moment_certificate.json').read_text())['rows']
cost=np.full((7,Q),np.inf);pen=np.zeros((7,Q))
prior=json.loads((WORK/'localization-tuning/results/candidate_certificate.json').read_text())
for row in prior['rows']:
    for j,opt in enumerate(row['options']):cost[j,row['b']-1]=opt['cost_upper'];pen[j,row['b']-1]=opt['penalty_upper']
for row in tail['rows']:
    for j,key in [(5,'plain_cost_upper'),(6,'finite_cost_upper')]:cost[j,row['b']-1]=row[key];pen[j,row['b']-1]=row['penalty_upper']
original_gaps=arc.prior.gaps

@functools.lru_cache(maxsize=20000)
def gap_cached(ns,ta,tb):
    n=np.array(ns,dtype=float);base=original_gaps(n,ta,tb,'complete');R=float(old.radial(tb)[0])
    for j in range(6):base=np.maximum(base,R-pen[j]-cost[j]/n[:,None])
    if ta>=3 and tb<=5.5:
        base=np.maximum(base,np.where((n>=6000)[:,None],R-pen[6]-cost[6]/n[:,None],-np.inf))
    gamma=old.grouped_gap(tb)
    improvement=max(gamma+gamma*gamma,float(square['adopted_gap_decimal']))-gamma
    base[:,4]+=improvement
    ls=np.arange(1,K+1,dtype=float);w=np.exp(-old.ETA*ls)/ls
    arg=ls*(tb/n[:,None]+10*np.pi/Q)
    res=2*np.sum(w*(old.kappa(arg)+old.kappa(arg/5)),axis=-1)
    base[:,0]=np.maximum(base[:,0],arc.prior.competition(ta,tb)[0]-2*old.ETA-old.TAIL-res/n)
    return base

def gaps(n,ta,tb,mode):return gap_cached(tuple(np.atleast_1d(n)),ta,tb).copy()
arc.prior.gaps=gaps

def ratios(cell,n,mode):
    hstr,variant=mode.split(':');h=float(hstr);n=np.atleast_1d(n).astype(float)
    _,parts,gg=arc.ratios(cell,n,hstr)
    if variant=='structure':return parts.sum(axis=-1),parts,gg
    ta,tb=old.ends(cell['tau_interval']);vlo,vhi=old.ends(cell['V_interval']);vhi=min(vhi,4/3)
    p=np.array([old.ends(v) for v in cell['signed_phase_intervals']]);pl=p[:,0];ph=p[:,1]
    w3=old.ends(cell['W3_interval'])[1];w4=old.ends(cell['W4_interval'])[1]
    beta,c3,c4=arc.constants(h);q=np.cos(2*h)
    m={k:old.ends(moments[cell['cell']][k])[1] for k in ['A3','A4','B4','B5','C6','D8']}
    T3=min(c3*w3,m['A3']/q+3*h*m['B4']/q**2+2*h**3*m['C6']/q**3)
    T4=min(c4*w4,m['A4']/q+(4*h*m['B5']+3*m['B4'])/q**2+12*h*h*m['C6']/q**3+6*h**4*m['D8']/q**4)
    x=np.exp(-ta);d=max(.75,1-x);M=min(np.exp(.8*h/.75),1/(1-x)) if ta>0 else np.exp(.8*h/.75)
    a1=.8*M*x/d;a2=M/2*(.8*x/d**2+(.8*x/d)**2)
    H=(ph*(T4/(32*beta**2*vlo**2)+5*T3*T3/(192*beta**3*vlo**3))+4*(T3*a1/(8*beta**2*vlo**2)+a2/(2*beta*vlo)))/np.sqrt(2*beta)
    Z=np.sqrt(tb*tb+h*h);D=Z*(1/30+2*x/(25*d))
    E=(Z/30*(ph+4*h*a1)+8*M*Z*x/(25*d))/np.sqrt(2*beta)
    em=min(3400,8*Z**3/.75**3*(-np.expm1(-ta)/ta if ta>0 else 1))
    U=4*M/np.sqrt(2*beta)*(em+D*D/2)*np.exp(D/n+em/n**2)
    parts[:,:,0]=((H+E)/n[:,None]+U[:,None]/n[:,None]**2)/pl
    if variant=='moments':return parts.sum(axis=-1),parts,gg
    edges=np.linspace(h,1.2,257);u=edges[:-1];v=edges[1:];width=v-u
    decay=.5*(np.sin(2*v)/(2*v))**2*u*u
    dv=np.sin(2*np.pi/5-v);dp=np.maximum(dv,1-x);zv=np.sqrt(tb*tb+v*v)
    Dv=zv*(1/30+2*x/(25*dp));emv=8*zv**3/dv**3*(-np.expm1(-ta)/ta if ta>0 else 1)
    error=np.minimum(7200/n[:,None],Dv/n[:,None]+emv/n[:,None]**2)
    Mb=min(6,1/(1-x)) if ta>0 else 6
    weak=min(4*Mb,4*x/(1-x)) if ta>0 else 4*Mb
    psi=np.array([4*Mb]*3+[weak]*2)
    attenuation=width*old.safe_exp(-n[:,None]*vlo*decay)
    for a in range(5):
        integrand=psi[a]+4*Mb*np.expm1(error)
        value=2*np.sqrt(vhi/(2*np.pi))*np.sqrt(n)*np.sum(attenuation*integrand,axis=-1)/pl[a]
        parts[:,a,2]=np.minimum(parts[:,a,2],value)
    power=h*h*vlo*n/2
    gaussian=old.safe_exp(-power)/np.sqrt(np.pi*power)
    parts[:,:,3]=np.minimum(parts[:,:,3],np.minimum(1,gaussian)[:,None]*ph/pl)
    return parts.sum(axis=-1),parts,gg

arc.prior.ratios=ratios
