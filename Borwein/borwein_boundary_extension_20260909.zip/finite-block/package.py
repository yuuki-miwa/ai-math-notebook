"""Append the finite-block round to the verified preceding bundle."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
with zipfile.ZipFile(WORK/'borwein_localization_tuning_20260909.zip') as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('BUNDLE_MANIFEST.json'));contents={}
    for row in manifest['files']:
        raw=z.read(row['path'])
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        contents[row['path']]=raw
for p in ROOT.rglob('*'):
    r=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in r.parts):contents['finite-block/'+r.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 有限ブロック改善統合版・2026-09-09

最新結果は [finite-block/README.md](finite-block/README.md) を参照してください。
有限5nブロックを保持する上界、分母5の二次ギャップ、主円弧幅の追加探索を記録しています。
全体の被覆は未認証の数値診断。解析作業稿の全域閾値31147・厳密整数検算n≤512は変更していません。
今回の有限ブロック上界と円弧予算の区間検算、および過去ラウンドの全パッケージを同梱。
過去の状況説明は各作成時点のものです。最新状況はfinite-blockを優先してください。
Python、NumPy、mpmathが必要。過去の図の再生成にはMatplotlibも必要です。
AI使用は各記録に明記。著者名なし。全予想の証明完了や独立査読完了は主張しません。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_finite_block_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(contents),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
