"""Build the result note from saved diagnostic and certificate files."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'results/summary_adaptive.json').read_text())
rows=json.loads((ROOT/'results/bulk_thresholds_adaptive.json').read_text())
last=max((d['n'] for row in rows for d in row['at_first_pass']))
lim=max(((d['n'],row['cell'],a,row['selected_h'][a],d) for row in rows for a,d in enumerate(row['at_first_pass'])),key=lambda x:x[0])
note=f'''# 有限5nブロックを保持する改善・2026-09-09

**最大未処理次数の診断値は29,022,289から{s['maximum_uncovered_degree']:,}へ低下した。**
ユーザーが共有した外部AIの案を検討し、有限ブロック、幅の追加探索、二次共鳴ギャップを実装した。

| 指標 | 前回 | 今回 |
|---|---:|---:|
| 最大未処理次数 | 29,022,289 | {s['maximum_uncovered_degree']:,} |
| 最大値をとるn | 11,583 | {s['n_at_maximum']:,} |
| 残る下半分係数数 | 131,259,962,111 | {s['remaining_lower_half_coefficients']:,} |
| 更新回数の上界見積り | 1,237,245,683,100 | {s['array_update_slot_upper_estimate']:,} |
| bulk全区間が通る候補n | 11,584 | {last:,} |

更新回数は実時間ではなく、大整数の桁数も反映しない。有限係数を実際に検算した結果ではない。
**解析作業稿の全域閾値31147、厳密整数検算n≤512は今回変更していない。**
bulk候補は端点を含む新しい全域閾値ではない。

## 採用した改善

有限和が正確に(1−z^(5n))H(z)となることを確認し、先頭32周波数でこの構造を保持した。
径方向の上界ではρの冪が相殺し、提案のG/(2ρ²)より強いG/2を使える。
先頭の「+4」は消し、末尾33〜718の分だけ残した。
τ∈[3,5.5],n≥6000を一括して覆う保守的な区間上界でも、分母4136のコストは約2522→1608。
一部の角度サンプルだけで得た数値ではない。

分母5には−log|φ|≥S+S²と、∫S²≥(∫S)²を組み合わせ、Γ→Γ+Γ²の簡略版を採用した。
Γ≈.00992213なら約.00009845の増分。点ごとのS²を積分する提案よりは保守的だが、既存の一様性を保ちやすい。
主円弧幅は.25,.30,.35,.37,.375,.38,.385,.39,.40の9候補を調べた。

最後のbulk制約はτセル{lim[1]}、剰余類{lim[2]}、h={lim[3]}、n={lim[0]}。
その点の最悪分母は{lim[4]['worst_denominator']}。
誤差予算の内訳は[閾値JSON](results/bulk_thresholds_adaptive.json)に保存した。

**今回未実装の部分：** 先頭で使用した距離を末尾プールから除く案、点ごとのS²の階段積分、
新しいcumulant評価。末尾プールは重複を許した保守的な上界のまま。
従って提案をすべて使い切った結果ではない。

## 検証と限界

- [有限ブロック上界](results/finite_block_certificate.json)：2,163分母、τ∈[3,5.5],n≥6000の一様上界。外向き丸めと70桁区間定数。
- [円弧予算](results/arc_certificate.json)：選択点640個を60桁区間演算で再確認。
- [補助検算](results/audit.json)：有限ブロック恒等式と径方向評価135サンプル、二次項の数値例。
- [被覆CSV](results/frontier_adaptive.csv)：通常浮動小数点による未認証の診断。
- [導出](DERIVATION.md)：新旧の評価の適用範囲と残した保守性を記載。

R、Γの被覆用再計算、係数位置の丸めを含む全体の区間認証は未完了。
既存解析稿の独立監査、残る有限領域の厳密整数検算、全予想の証明完了は主張しない。

## 再実行とAI使用

統合ZIPのルートから、Python・NumPy・mpmathを用いて以下を実行する。

```text
python finite-block/run.py
python finite-block/audit.py
python finite-block/report.py
```

過去の各ラウンドのフォルダと入力を同梱した配置が必要。
OpenAI Codexが共有されたAI提案をもとに導出、実装、実行、検算、文書化を行った。
著者名は記載しない。専門家への連絡、独立査読、Lean認証、GitHub公開は行っていない。
'''
(ROOT/'README.md').write_text(note,encoding='utf-8')
print('Wrote finite-block/README.md')
