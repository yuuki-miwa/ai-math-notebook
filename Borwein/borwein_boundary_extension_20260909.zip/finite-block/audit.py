"""Interval arc audit and independent finite-block sanity checks."""
import sys,json,cmath,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'arc-improvement'))
import certify_arcs as ac
ac.e.ROOT=ROOT

def run():
    ac.run();iv=ac.iv;I=iv.mpf
    tests=0
    for n in [3,17,100]:
        for tau in [.1,3,5.5]:
            for l in [1,7,32]:
                for u in [.07,.73,1.21,2.31,3.1]:
                    x=l*tau/(5*n);rho=cmath.exp(-x).real;z=rho*cmath.exp(1j*u)
                    finite=sum(z**j for j in range(1,5*n+1) if j%5)
                    block=(1-z**(5*n))*sum(z**j for j in range(1,5))/(1-z**5)
                    assert abs(finite-block)<1e-10*max(1,abs(finite));tests+=1
                    H=sum(z**j for j in range(1,5))/(1-z**5)
                    G=abs(math.sin(2*u))/(abs(math.sin(u/2)*math.sin(5*u/2)))
                    bound=G/2+math.sinh(2*x)/(2*abs(math.sin(u/2)*math.sin(5*u/2)))
                    assert abs(H)<=bound+1e-10*max(1,bound)
    gamma=I('0.0099221336');improved=gamma+gamma**2
    result={'status':'passed','finite_block_identity_samples':tests,
      'scope':'Identity sanity checks and example quadratic gain; not a new uniform gap certificate',
      'example_gamma':str(gamma),'example_gamma_plus_square':str(improved)}
    (ROOT/'results/audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':run()
