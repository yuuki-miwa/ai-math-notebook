"""Finite 5n blocks on a uniform high-tau rectangle; diagnostic coverage."""
import sys,json,math,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
spec=importlib.util.spec_from_file_location('tuning',WORK/'localization-tuning/run.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
c=t.cert;np=t.np;iv=t.iv;I=iv.mpf;old=t.old;arc=t.arc;Q=4139;K=718;L=32
OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)
N0=6000

def generate():
    eta=I(11313)/1250000
    weights=np.array([c.upper_float(iv.exp(-eta*l)/l) for l in range(1,K+1)])
    f=np.array([c.upper_float((1+iv.exp(-3*l))/2) for l in range(1,L+1)])
    def sinh(x):return (iv.exp(x)-iv.exp(-x))/2
    radial=np.array([c.upper_float((1+iv.exp(-3*l))*sinh(2*I(l)*I('5.5')/(5*N0))/8) for l in range(1,L+1)])
    variation=c.upper_float(iv.pi**3/(30*Q)*(1/(1-I(K)/Q)+6/(1-I(5*K)/Q)))
    partial=c.upper_float(4*sum((iv.exp(-eta*l)/l for l in range(L+1,K+1)),I(0)))
    penalty=c.upper_float(2*eta+4*iv.exp(-eta*K)/(eta*K));rows=[]
    for b in range(2*K+1,Q+1):
        if b%5==0:continue
        r=np.arange(1,b//2+1,dtype=np.int64)
        s1,_=c.sin_pi_rational_abs(r,b);_,s4=c.sin_pi_rational_abs(4*r,b);s5,_=c.sin_pi_rational_abs(5*r,b)
        g=c.up(s4/c.down(s1*s5));top=np.sort(g)[::-1]
        nums=r[np.gcd(r,b)==1];acc=np.zeros(len(nums))
        for l in range(1,L+1):
            rem=nums*l%b;s=np.minimum(rem,b-rem);rem5=5*nums*l%b;s5=np.minimum(rem5,b-rem5)
            # All integer operations are exact; l/Q is rounded outward.
            den=c.down(c.down(s-c.upper_float(I(l)/Q))*c.down(s5-c.upper_float(I(5*l)/Q)))
            assert np.all(den>0)
            extra=c.up(c.up(c.up(radial[l-1]*b)*b)/den)
            val=c.up(c.up(f[l-1]*g[s-1])+extra)
            acc=c.up(acc+c.up(weights[l-1]*val))
        tail=0.
        for val in c.up(weights[L:]*top[:K-L]):tail=math.nextafter(tail+float(val),math.inf)
        cost=math.nextafter(float(np.max(acc))+tail,math.inf)
        cost=math.nextafter(cost+math.nextafter(variation*b,math.inf),math.inf)
        cost=math.nextafter(cost+partial,math.inf)
        rows.append({'b':b,'cost_upper':cost,'penalty_upper':penalty})
    report={'status':'passed','scope':f'Finite-block costs on tau in [3,5.5], integer n>={N0}; not full coverage',
      'Q':Q,'K':K,'prefix':L,'eta':'11313/1250000','n_min':N0,'tau':[3,5.5],'denominators':len(rows),'rows':rows}
    (OUT/'finite_block_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Finite block certified',len(rows),'denominators',flush=True)
    return report

def run():
    block=generate();fcost=np.full(Q,np.inf)
    for r in block['rows']:fcost[r['b']-1]=r['cost_upper']
    fp=block['rows'][0]['penalty_upper']
    previous=json.loads((WORK/'localization-tuning/results/candidate_certificate.json').read_text())
    costs=np.full((5,Q),np.inf);pen=np.zeros((5,Q))
    for row in previous['rows']:
        for j,opt in enumerate(row['options']):costs[j,row['b']-1]=opt['cost_upper'];pen[j,row['b']-1]=opt['penalty_upper']
    orig=arc.prior.gaps
    def gaps(n,ta,tb,mode):
        n=np.atleast_1d(n).astype(float);base=orig(n,ta,tb,mode);R=float(old.radial(tb)[0])
        for j in range(5):base=np.maximum(base,R-pen[j]-costs[j]/n[:,None])
        if ta>=3:
            candidate=R-fp-fcost/n[:,None]
            base=np.maximum(base,np.where((n>=N0)[:,None],candidate,-np.inf))
        # Jensen: integral S^2 >= (integral S)^2 on the unit interval.
        gamma=old.grouped_gap(tb);base[:,4]+=gamma*gamma
        ls=np.arange(1,K+1,dtype=float);w=np.exp(-old.ETA*ls)/ls
        arg=ls*(tb/n[:,None]+10*np.pi/Q)
        resonance=2*np.sum(w*(old.kappa(arg)+old.kappa(arg/5)),axis=-1)
        base[:,0]=np.maximum(base[:,0],arc.prior.competition(ta,tb)[0]-2*old.ETA-old.TAIL-resonance/n)
        return base
    arc.prior.gaps=gaps;arc.prior.ratios=arc.ratios
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    hs=[.25,.3,.35,.37,.375,.38,.385,.39,.4];allrows=[]
    for h in hs:
        rows=arc.prior.thresholds(cells,str(h));allrows.append(rows)
        print('h',h,'bulk',max(max(r['first_passing_n']) for r in rows),flush=True)
    resultrows=[]
    for i in range(128):
        row={'cell':i,'tau':allrows[0][i]['tau'],'first_passing_n':[],'at_first_pass':[],'selected_h':[]}
        for a in range(5):
            j=min(range(len(hs)),key=lambda j:allrows[j][i]['first_passing_n'][a])
            row['first_passing_n'].append(allrows[j][i]['first_passing_n'][a]);row['at_first_pass'].append(allrows[j][i]['at_first_pass'][a]);row['selected_h'].append(hs[j])
        resultrows.append(row)
    (OUT/'bulk_thresholds_adaptive.json').write_text(json.dumps(resultrows,indent=2)+'\n')
    result=old.frontier(resultrows,'adaptive',OUT)
    print(json.dumps({k:v for k,v in result.items() if k!='samples'}),flush=True)

if __name__=='__main__':run()
