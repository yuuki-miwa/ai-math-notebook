"""Denominator-specific and combined-kernel coverage exploration.

Binary64 diagnostics only. The inherited v0.7 profile bounds are unchanged.
"""
import argparse,functools,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'coverage-frontier'))
import diagnose as old
np=old.np
Q=old.Q;K=old.K;K5=old.K5;ETA=old.ETA;ETA5=old.ETA5
B=np.arange(1,Q+1,dtype=float);FIVE=B%5==0
LS=np.arange(1,K+1,dtype=float);WEIGHTS=np.exp(-ETA*LS)/LS

def period(b,k,e):
    ls=np.arange(1,k+1,dtype=float)
    s=np.sum(np.exp(-e*ls)/(ls*np.ceil(ls/2)))
    q=np.exp(-e*b)
    return s+2*(1+np.log(k))*q/(b*(1-q)),np.pi**2/(3*(1-q))

def individual_costs():
    gamma=.5/(1-K/Q)+.5/(1-5*K/Q)
    t,u=period(B,K,ETA)
    correction=1/(Q*(1-K/Q))+5/(Q*(1-5*K/Q))
    non=B/2*(2*t+correction*u)
    non=np.minimum(non,gamma*B*old.L)
    s1=np.sum(WEIGHTS/LS)
    non=np.where(B>2*K,np.minimum(non,B/2*(2*s1+correction*np.pi**2/6)),non)
    t1,u1=period(B,K5,ETA5);t5,u5=period(B/5,K5,ETA5)
    five=B/2*(t1+t5/5+(u1+u5/5)/(Q*(1-K5/Q)))
    five=np.minimum(five,.6/(1-K5/Q)*B*old.L5)
    out=np.where(FIVE,five,non);out[0]=0;out[4]=.5/(1-K5/Q)*5*old.L5
    return out

COST=individual_costs()

@functools.lru_cache(None)
def competition(ta,tb):
    R=float(old.radial(tb)[0]);global_bounds=old.competition(ta,tb,'local')
    # For non-5 b: 4 M(b*tau)/b plus the smoothing increment.
    # Retain both the proven global-in-tau bound and the quadratic radial bound.
    non_upper=np.minimum(4*np.log(2)/B,4*(.2+2*np.pi*old.calL(B*ETA/2))/B)
    # b=1 has its own short/long-angle estimate; b>=2 can reuse gap .1.
    non_gap=np.maximum(R-non_upper,np.where(B==1,global_bounds[0],global_bounds[1]))
    if ta>0:
        li=np.array([old.li(float(b*ta)) for b in B])
        radial_upper=li**2/((np.pi**2/6)*B**2*ta)+4/B*old.calL(ETA/ta)
        non_gap=np.maximum(non_gap,R-radial_upper)
    j=B/5
    argument=j*ta
    rj=old.radial(np.minimum(argument,20))[0]
    rj=np.where(argument>20,old.C/np.maximum(argument,1),rj)
    five_gap=np.maximum(R/2,R-np.minimum(5*np.log(5)/B,rj/j))
    gap=np.where(FIVE,five_gap,non_gap)
    gap[0]=global_bounds[0]
    gap[4]=old.grouped_gap(tb)
    return gap

@functools.lru_cache(None)
def kernel_costs():
    values=np.full(Q,np.inf);records=[]
    for b in range(2,Q+1):
        if b%5==0:continue
        r=np.arange(1,b//2+1,dtype=float);theta=np.pi*r/b
        G=np.abs(np.sin(4*theta))/(np.sin(theta)*np.abs(np.sin(5*theta)))
        multiplicity=1 if b>2*K else 2*((K+b-1)//b)
        pooled=np.sort(np.repeat(G,multiplicity))[::-1]
        top=np.zeros(K);top[:min(K,len(pooled))]=pooled[:K]
        nominal=np.dot(WEIGHTS,top)
        variation=np.pi**3*b*multiplicity/(30*Q)*(1/(1-K/Q)+6/(1-5*K/Q))
        cost=nominal+variation+4*old.L
        values[b-1]=cost
        resonance=4*np.sum(WEIGHTS[LS%b==0])
        records.append({'b':b,'nominal_cost':float(nominal),'angular_variation_cost':float(variation),
            'distance_multiplicity':multiplicity,'partial_block_cost':float(4*old.L),'total_cost':float(cost),
            'resonance_normalized_upper':float(resonance)})
    return values,records

@functools.lru_cache(None)
def kernel5_costs():
    values=np.full(Q,np.inf);resonant=np.zeros(Q);records=[]
    ls=np.arange(1,K5+1,dtype=float);weights=np.exp(-ETA5*ls)/ls
    for b in range(10,Q+1,5):
        period=b//5;r=np.arange(1,b//2+1,dtype=int);r=r[(5*r)%b!=0]
        angle=np.pi*r/b
        G=np.abs(np.sin(4*angle))/(np.sin(angle)*np.abs(np.sin(5*angle)))
        multiplicity=1 if b>2*K5 else 2*((K5+b-1)//b)
        pooled=np.sort(np.repeat(G,multiplicity))[::-1]
        top=np.zeros(K5);top[:min(len(pooled),K5)]=pooled[:K5]
        nominal=np.dot(weights,top)
        pole_multiplicity=2*((K5+period-1)//period)
        variation=np.pi**3*b/(30*Q*(1-K5/Q))*(multiplicity+pole_multiplicity/4)
        cost=nominal+variation+4*old.L5
        resonant[b-1]=4*np.sum(weights[ls%period==0]);values[b-1]=cost
        records.append({'b':b,'nominal_cost':float(nominal),'angular_variation_cost':float(variation),
            'distance_multiplicity':multiplicity,'pole_multiplicity':pole_multiplicity,
            'partial_block_cost':float(4*old.L5),'total_cost':float(cost),'resonance_normalized_upper':float(resonant[b-1])})
    return values,resonant,records

@functools.lru_cache(None)
def certified_costs():
    path=ROOT/'results/kernel_certificate.json'
    if not path.exists():return None
    cert=json.loads(path.read_text(encoding='utf-8'))
    assert cert['status']=='passed' and cert['Q']==Q and cert['K']==K and cert['K5']==K5
    assert cert['eta']=='11313/1250000' and cert['eta5']=='113/40000'
    non=np.full(Q,np.inf);five=np.full(Q,np.inf);res=np.zeros(Q);nonres=np.zeros(Q)
    for row in cert['denominators']:
        non[row['b']-1]=row['total_cost_upper'];nonres[row['b']-1]=row.get('resonance_normalized_upper',0.)
    for row in cert.get('five_denominators',[]):
        five[row['b']-1]=row['total_cost_upper'];res[row['b']-1]=row['resonance_normalized_upper']
    return non,five,res,nonres

def gaps(n,ta,tb,mode):
    n=np.atleast_1d(n).astype(float)
    kk=np.where(FIVE,K5,K);ll=np.where(FIVE,old.L5,old.L)
    penalty=np.where(FIVE,2*ETA5+old.TAIL5,2*ETA+old.TAIL)
    z=tb*kk/n[:,None]+10*np.pi*kk/(B*Q)
    gap=competition(ta,tb)-penalty-COST/n[:,None]-4*old.kappa(z)*ll/n[:,None]
    if mode in ['kernel','cusp','complete']:
        R=float(old.radial(tb)[0]);cost,records=kernel_costs();resonant=np.zeros(Q)
        for row in records:resonant[row['b']-1]=row['resonance_normalized_upper']
        if certified_costs() is not None:cost,resonant=certified_costs()[0],certified_costs()[3]
        direct=R-2*ETA-4*np.exp(-ETA*K)/(ETA*K)-resonant-cost/n[:,None]
        gap=np.maximum(gap,direct)
    if mode in ['cusp','complete']:
        ls=np.arange(1,K5+1,dtype=float);weight=np.exp(-ETA5*ls)/ls
        nonres=[]
        for a in [1,2]:
            rem=(a*ls)%5;r=np.minimum(rem,5-rem);valid=r>0
            nonres.append(np.sum(weight[valid]*5/(2*(r[valid]-ls[valid]/Q))))
        arg=ls*(tb/n[:,None]+2*np.pi/Q)
        resonance=2*np.sum(weight*old.kappa(arg),axis=-1)
        selected=ls%5==0
        resonance+=2*np.sum(weight[selected]*old.kappa(arg[:,selected]/5),axis=-1)
        cusp=old.grouped_gap(tb)-2*ETA5-old.TAIL5-(max(nonres)+resonance)/n
        gap[:,4]=np.maximum(gap[:,4],cusp)
    if mode=='complete':
        R=float(old.radial(tb)[0]);cost,resonant,_=kernel5_costs()
        if certified_costs() is not None:cost,resonant=certified_costs()[1:3]
        direct=R-2*ETA5-4*np.exp(-ETA5*K5)/(ETA5*K5)-resonant-cost/n[:,None]
        gap=np.maximum(gap,direct)
    return gap

def ratios(cell,n,mode):
    n=np.atleast_1d(n).astype(float);ta,tb=old.ends(cell['tau_interval'])
    parts,_=old.components(cell,n,'oracle')
    gg=gaps(n,ta,tb,mode);delta=gg.min(axis=-1)
    vhi=min(old.ends(cell['V_interval'])[1],4/3)
    phase=np.array([old.ends(p)[0] for p in cell['signed_phase_intervals']])
    minor=np.where(delta>0,5*np.sqrt(2*np.pi*vhi)*old.safe_exp(1.5*np.log(n)-n*delta),np.inf)
    parts[:,:,1]=minor[:,None]/phase
    return parts.sum(axis=-1),parts,gg

def thresholds(cells,mode):
    records=[]
    for cell in cells:
        lo=np.full(5,512,dtype=int);hi=np.full(5,31147,dtype=int)
        while np.any(hi-lo>1):
            mid=(hi+lo)//2
            result=ratios(cell,mid,mode)[0][np.arange(5),np.arange(5)]
            yes=result<.98;hi=np.where(yes,mid,hi);lo=np.where(yes,lo,mid)
        result,parts,gg=ratios(cell,hi,mode)
        previous=ratios(cell,hi-1,mode)[0]
        details=[]
        for a in range(5):
            assert result[a,a]<.98 and (hi[a]==513 or previous[a,a]>=.98)
            details.append({'n':int(hi[a]),'ratio':float(result[a,a]),
                'components':dict(zip(['local_main','minor_arc','intermediate','gaussian_tail'],map(float,parts[a,a]))),
                'worst_denominator':int(np.argmin(gg[a]))+1,'localization_gap':float(np.min(gg[a]))})
        records.append({'cell':cell['cell'],'tau':old.ends(cell['tau_interval']),'first_passing_n':hi.tolist(),'at_first_pass':details})
    return records

def run(modes):
    start=time.perf_counter();out=ROOT/'results';out.mkdir(exist_ok=True)
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text(encoding='utf-8'))['cells']
    for mode in modes:
        rows=thresholds(cells,mode)
        (out/f'bulk_thresholds_{mode}.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
        summary=old.frontier(rows,mode,out)
        print(json.dumps({k:v for k,v in summary.items() if k!='samples'}),flush=True)
    (out/'kernel_costs.json').write_text(json.dumps({'scope':'binary64 diagnostic, not certified','denominators':kernel_costs()[1]},indent=2)+'\n',encoding='utf-8')
    (out/'kernel5_costs.json').write_text(json.dumps({'scope':'binary64 diagnostic, not certified','denominators':kernel5_costs()[2]},indent=2)+'\n',encoding='utf-8')
    print('Seconds:',time.perf_counter()-start,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--modes',nargs='+',choices=['individual','kernel','cusp','complete'],default=['individual','kernel','cusp','complete'])
    args=p.parse_args();run(args.modes)
