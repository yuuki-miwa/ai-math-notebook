"""Build a self-contained review bundle, verify baseline manifests and ZIP hashes."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
contents={}
for folder,manifest in [('round4-6','MANIFEST.sha256.json'),('finite-compute','MANIFEST.json'),('coverage-frontier','MANIFEST.json')]:
    base=WORK/folder;record=json.loads((base/manifest).read_text(encoding='utf-8'))
    for row in record['files']:
        raw=(base/row['path']).read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],(folder,row['path'])
        contents[folder+'/'+row['path']]=raw
    contents[folder+'/'+manifest]=(base/manifest).read_bytes()
for p in (WORK/'proposal-review').iterdir():
    if p.is_file():contents['proposal-review/'+p.name]=p.read_bytes()
for p in ROOT.rglob('*'):
    relative=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in relative.parts):
        contents['hybrid-improvement/'+relative.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 改善ラウンド統合版・2026-09-09

最初に [今回の結果と再実行手順](hybrid-improvement/README.md) を読んでください。
診断上の最大未処理次数は 430,644,099 → 65,899,108。
合成核の4137分母について区間上界を計算しました。被覆全体の認証ではありません。
解析作業稿 n≥31147、厳密整数検算 n≤512 は今回変更していません。

- hybrid-improvement：今回のコード、結果、導出、図。
- round4-6：既存解析稿・証明書。歴史的な文書中の「証明」等は作業稿の主張です。
- finite-compute：既存 n≤512 の整数検算と効率化。
- coverage-frontier：前回の二次元被覆診断。
- proposal-review：前回の提案確認記録（未再現という記載は前回時点）。

AI使用は各記録に明記。著者名なし。全予想の解決や独立査読完了は主張しません。
依存パッケージは同梱しません。Python、NumPy、mpmath、図には Matplotlib が必要です。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_hybrid_improvement_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(contents)},indent=2))
