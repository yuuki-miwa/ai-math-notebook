"""Independent finite sanity checks and endpoint amplitude enclosures.

These checks supplement the kernel proof; they do not certify the coverage map.
"""
import collections,cmath,json,math
import explore as e
from mpmath import mp,iv
mp.dps=80;iv.dps=70

def interval(x):return [str(x.a),str(x.b)]

def run():
    counts=0
    for b in range(2,81):
        for k in [7,19,43]:
            for a in range(1,b):
                if math.gcd(a,b)!=1:continue
                period=b if b%5 else b//5
                ls=[l for l in range(1,k+1) if l%period]
                rs=[min(a*l%b,(-a*l)%b) for l in ls]
                c=1 if b>2*k else 2*((k+b-1)//b)
                assert max(collections.Counter(rs).values(),default=0)<=c
                if b%5:
                    qs=[min((5*a*l-j*b)%(5*b),(-5*a*l+j*b)%(5*b)) for l in ls for j in range(1,5)]
                    assert all(q>0 and q%5 for q in qs)
                    assert max(collections.Counter(qs).values(),default=0)<=c
                else:
                    qs=[min((a*l-j*period)%b,(-a*l+j*period)%b) for l in ls for j in range(1,5)]
                    assert all(q>0 for q in qs)
                    assert max(collections.Counter(qs).values(),default=0)<=2*((k+period-1)//period)
                counts+=1
    samples=0
    for u in [.13,.71,1.39,2.31,3.1,4.77]:
        z=cmath.exp(1j*u);kernel=sum(z**j for j in range(1,5))/(1-z**5)
        partial=4/(5*(1-z))-sum(1/(1-cmath.exp(2j*math.pi*j/5)*z) for j in range(1,5))/5
        assert abs(kernel-partial)<1e-12
        for m in [1,4,5,17,98,321]:
            for r in [0,.37,.95,1]:
                value=sum((r*z)**j for j in range(1,m+1) if j%5)
                assert abs(value)<=2*abs(kernel)+4+1e-10;samples+=1
    eta=iv.mpf(113)/40000;cost=[]
    for a in [1,2]:
        total=iv.mpf(0)
        for l in range(1,e.K5+1):
            r=min(a*l%5,(-a*l)%5)
            if r:total+=5*iv.exp(-eta*l)/(2*l*(r-iv.mpf(l)/e.Q))
        cost.append(interval(total))
    phases=[]
    for t in ['4','4.5','5','5.5']:
        x=iv.exp(-iv.mpf(t))
        phases.append({'T':t,'F_modulus_lower':interval(1-4*x/(1-x)),
          'F_prime_upper':interval(4/(1-x)**2),'F_second_upper':interval(8/(1-x)**3),
          'E17_margin':interval(iv.mpf(1)/25-x-x/(5*(1-x))-iv.mpf(1)/30)})
    rows=json.loads((e.ROOT/'results/bulk_thresholds_complete.json').read_text())
    worst=max(((d['n'],r['cell'],a,d) for r in rows for a,d in enumerate(r['at_first_pass'])),key=lambda x:x[0])
    # First-pass and predecessor inequalities are checked for all 640 entries by explore.py.
    report={'status':'passed','scope':'Finite sanity checks and interval amplitude bounds, not full coverage certification',
      'multiplicity_cases':counts,'partial_fraction_and_Abel_samples':samples,'cusp_nonresonant_cost_intervals':cost,
      'endpoint_amplitude_bounds':phases,'all_bulk_first_passing_n':worst[0],
      'limiting_cell':worst[1],'limiting_residue':worst[2],'limiting_components':worst[3]}
    (e.ROOT/'results/audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':run()
