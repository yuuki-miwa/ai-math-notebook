"""Outward binary64 interval certificate for non-5 and proper-5 denominators.

No libm sine is trusted: reduce exact rational angles, use a degree-21 Taylor
polynomial with outward basic operations and an exact rational remainder bound.
Weights and scalar constants are enclosed by mpmath.iv at 70 digits.
"""
import json,math,time
from fractions import Fraction as F
import explore as e
from mpmath import iv
np=e.np;iv.dps=70
down=lambda x:np.nextafter(x,-np.inf)
up=lambda x:np.nextafter(x,np.inf)

def atan_interval(q,terms):
    lower=sum((F((-1)**j,(2*j+1)*q**(2*j+1)) for j in range(terms)),F(0))
    assert terms%2==0
    return lower,lower+F(1,(2*terms+1)*q**(2*terms+1))

a,b=atan_interval(5,60);c,d=atan_interval(239,20)
PI_RATIONAL=(16*a-4*d,16*b-4*c)
PI_LO=math.nextafter(math.pi,-math.inf);PI_HI=math.nextafter(math.pi,math.inf)
assert F.from_float(PI_LO)<PI_RATIONAL[0]<PI_RATIONAL[1]<F.from_float(PI_HI)
assert PI_RATIONAL[1]<F(22,7)
REMAINDER=2.**-58
assert F(11,7)**23/math.factorial(23)<F(1,2**58)
COEFFICIENTS=[]
for j in range(11):
    rational=F((-1)**j,math.factorial(2*j+1));value=float(rational)
    lo=math.nextafter(value,-math.inf);hi=math.nextafter(value,math.inf)
    assert F.from_float(lo)<rational<F.from_float(hi)
    COEFFICIENTS.append((lo,hi))

def sin_pi_rational_abs(numerator,denominator):
    t=np.asarray(numerator,dtype=np.int64)%(2*denominator)
    t=np.minimum(t,2*denominator-t);t=np.minimum(t,denominator-t)
    xl=down(down(PI_LO*t)/denominator);xh=up(up(PI_HI*t)/denominator)
    xl=np.maximum(xl,0);zl=np.maximum(0,down(xl*xl));zh=up(xh*xh)
    pl=np.full(t.shape,COEFFICIENTS[-1][0]);ph=np.full(t.shape,COEFFICIENTS[-1][1])
    for cl,ch in reversed(COEFFICIENTS[:-1]):
        pl=down(down(np.minimum(pl*zl,pl*zh))+cl)
        ph=up(up(np.maximum(ph*zl,ph*zh))+ch)
    assert np.all(pl>0)
    lo=np.maximum(0,down(down(pl*xl)-REMAINDER));hi=up(ph*xh)
    lo=np.where(t==0,0,lo);hi=np.where(t==0,0,hi)
    return lo,hi

def upper_float(value):
    result=math.nextafter(float(value.b),math.inf)
    f=F.from_float(result);point=iv.mpf(f.numerator)/f.denominator
    assert bool(point.a>value.b)
    return result

def run():
    start=time.perf_counter();I=iv.mpf;eta=I(11313)/1250000
    weights=np.array([upper_float(iv.exp(-eta*l)/l) for l in range(1,e.K+1)])
    variation=upper_float(iv.pi**3/(30*e.Q)*(1/(1-I(e.K)/e.Q)+6/(1-I(5*e.K)/e.Q)))
    partial=upper_float(4*iv.log(2/eta));rows=[]
    diagnostic={r['b']:r['total_cost'] for r in e.kernel_costs()[1]}
    checked=0;max_extra=0.
    for b in range(2,e.Q+1):
        if b%5==0:continue
        r=np.arange(1,b//2+1,dtype=np.int64)
        s1l,_=sin_pi_rational_abs(r,b);_,s4h=sin_pi_rational_abs(4*r,b);s5l,_=sin_pi_rational_abs(5*r,b)
        denominator=down(s1l*s5l);assert np.all(denominator>0)
        gh=up(s4h/denominator)
        mult=1 if b>2*e.K else 2*((e.K+b-1)//b)
        pooled=np.sort(np.repeat(gh,mult))[::-1]
        top=np.zeros(e.K);top[:min(e.K,len(pooled))]=pooled[:e.K]
        products=up(top*weights)
        nominal=0.
        for x in products:nominal=math.nextafter(nominal+float(x),math.inf)
        var=math.nextafter(math.nextafter(variation*b,math.inf)*mult,math.inf)
        total=math.nextafter(math.nextafter(nominal+var,math.inf)+partial,math.inf)
        assert total>=diagnostic[b]-1e-8
        max_extra=max(max_extra,total-diagnostic[b]);checked+=len(r)
        res=0.
        for w in weights[b-1::b]:res=math.nextafter(res+float(w),math.inf)
        res=math.nextafter(4*res,math.inf)
        rows.append({'b':b,'nominal_upper':nominal,'variation_upper':var,'total_cost_upper':total,
                     'distance_multiplicity':mult,'resonance_normalized_upper':res})
    weights5=np.array([upper_float(iv.exp(-I(113)*l/40000)/l) for l in range(1,e.K5+1)])
    variation5=upper_float(iv.pi**3/(30*e.Q*(1-I(e.K5)/e.Q)))
    partial5=upper_float(4*iv.log(I(80000)/113));five_rows=[];checked5=0
    for b in range(10,e.Q+1,5):
        period=b//5;r=np.arange(1,b//2+1,dtype=np.int64);r=r[(5*r)%b!=0]
        s1l,_=sin_pi_rational_abs(r,b);_,s4h=sin_pi_rational_abs(4*r,b);s5l,_=sin_pi_rational_abs(5*r,b)
        gh=up(s4h/down(s1l*s5l))
        mult=1 if b>2*e.K5 else 2*((e.K5+b-1)//b)
        poles=2*((e.K5+period-1)//period)
        pooled=np.sort(np.repeat(gh,mult))[::-1]
        top=np.zeros(e.K5);top[:min(e.K5,len(pooled))]=pooled[:e.K5]
        products=up(top*weights5);nominal=0.
        for x in products:nominal=math.nextafter(nominal+float(x),math.inf)
        var=math.nextafter(math.nextafter(variation5*b,math.inf)*(mult+poles/4),math.inf)
        total=math.nextafter(math.nextafter(nominal+var,math.inf)+partial5,math.inf)
        res=0.
        for w in weights5[period-1::period]:res=math.nextafter(res+float(w),math.inf)
        res=math.nextafter(4*res,math.inf)
        checked5+=len(r)
        five_rows.append({'b':b,'nominal_upper':nominal,'variation_upper':var,'total_cost_upper':total,
                          'distance_multiplicity':mult,'pole_multiplicity':poles,'resonance_normalized_upper':res})
    # Independent arbitrary-precision interval checks of difficult small sines and zeros.
    samples=0
    for b in [1437,1440,2069,3001,4139]:
        for r in sorted(set([1,b//5,b//5+1,b//2-1,b//2])):
            for k in [1,4,5]:
                lo,hi=sin_pi_rational_abs(np.array([k*r]),b)
                exact=abs(iv.sin(iv.pi*(k*r)/b))
                if (k*r)%b==0:assert lo[0]==hi[0]==0
                else:
                    assert bool(iv.mpf(float(lo[0])).b<exact.a)
                    assert bool(iv.mpf(float(hi[0])).a>exact.b)
                samples+=1
    report={'status':'passed','scope':'Uniform combined-kernel cost enclosures for all listed denominators; not a full sign theorem',
      'assumptions':'IEEE-754 binary64 basic operations rounded to nearest, nextafter outward; no fast-math',
      'Q':e.Q,'K':e.K,'eta':'11313/1250000','K5':e.K5,'eta5':'113/40000',
      'denominator_count':len(rows),'rational_angles_per_sine_factor':checked,
      'sin_polynomial_degree':21,'sin_remainder_bound':'2^-58','pi_machin_terms':[60,20],
      'mpmath_interval_precision':70,'independent_sine_checks':samples,'maximum_increase_over_diagnostic':max_extra,
      'five_denominator_count':len(five_rows),'five_rational_angles_per_factor':checked5,
      'seconds':time.perf_counter()-start,'denominators':rows,'five_denominators':five_rows}
    (e.ROOT/'results/kernel_certificate.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ['denominators','five_denominators']},indent=2))

if __name__=='__main__':run()
