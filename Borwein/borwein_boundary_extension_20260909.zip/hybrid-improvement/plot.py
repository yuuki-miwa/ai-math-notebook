"""Saved-data scientific figure; no certification."""
import csv,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'coverage-frontier/.plot-deps'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.mplconfig')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
for folder,mode,label in [('coverage-frontier','local','Previous: 430.6 million'),('hybrid-improvement','individual','Individual denominators: 201.7 million'),('hybrid-improvement','complete','Combined kernels + cusp: 65.9 million'),('coverage-frontier','oracle','Hypothetical: minor-arc error = 0')]:
    with (ROOT.parent/folder/'results'/f'frontier_{mode}.csv').open() as f:rows=list(csv.DictReader(f))
    ax.plot([int(r['n']) for r in rows],[int(r['last_uncovered_degree']) for r in rows],label=label,lw=1.5,ls='--' if mode=='oracle' else '-')
ax.set(xlabel='Product index n',ylabel='Largest uncovered degree m',yscale='log',ylim=(1e5,1e9),xlim=(513,31146),title='Structural improvement of coverage — diagnostic, not certified')
ax.grid(alpha=.2);ax.legend(fontsize=9)
for ext in ['png','svg']:fig.savefig(ROOT/'results'/f'comparison.{ext}',dpi=160)
print('Saved comparison.png and comparison.svg')
