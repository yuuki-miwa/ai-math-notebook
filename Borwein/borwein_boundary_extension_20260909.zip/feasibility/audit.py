"""Consistency checks on measurement and planning artifacts."""
import json,math
import estimate as e

def run():
    result=json.loads((e.OUT/'estimates.json').read_text());micro=json.loads((e.OUT/'micro.json').read_text())
    assert len(micro['rows'])==28 and len(result['calibration'])==2
    for path in e.OUT.glob('prefix_*.json'):
        actual=json.loads(path.read_text());assert actual['status']=='passed'
        prediction=e.fixed(actual['cap'],actual['nmax'])
        assert prediction['integer_subtractions']==actual['integer_subtractions']
        assert prediction['memory_planning_bytes']>=actual['memory']['peak_working_set_bytes']
        assert prediction['planning_seconds_3x']>=actual['total_seconds']
    # Independent positive distinct-partition coefficients test the bit majorant.
    cap=1000;p=[0]*(cap+1);p[0]=1
    for k in range(1,cap+1):
        for m in range(cap,k-1,-1):p[m]+=p[m-k]
    for m,value in enumerate(p):assert value.bit_length()<=math.ceil(e.coefficient*math.sqrt(m))+1
    for row,budget in zip(result['arrival_lines'],[3600,86400,604800]):
        assert row['planning_seconds_3x']<=budget and row['fits_8_GiB_planning_budget']
        assert not row['bit_extrapolation_beyond_measured_range']
        beyond=e.fixed(row['model_cap_boundary']+1)
        assert beyond['planning_seconds_3x']>budget or beyond['memory_planning_bytes']>e.MEMORY_BUDGET
    report={'status':'passed','scope':'Model consistency and two short real-workload comparisons; not a long-run guarantee',
      'micro_cases':28,'real_cases':2,'positive_coefficient_majorant_checks':1001,'arrival_line_boundaries_checked':3,
      'current_frontier_performance_gate_24h':result['performance_gate_24h'],'current_frontier_performance_gate_7d':result['performance_gate_7d']}
    (e.OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':run()
