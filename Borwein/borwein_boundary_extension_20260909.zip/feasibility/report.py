import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
e=json.loads((ROOT/'results/estimates.json').read_text());micro=json.loads((ROOT/'results/micro.json').read_text())
def hours(s):return f'{s/3600:.1f}'
def gib(b):return f'{b/1024**3:.2f}'
scenarios='\n'.join(f"| {r['fixed_cap']:,} | {hours(r['base_seconds'])}時間 | {hours(r['planning_seconds_3x'])}時間 | {gib(r['memory_planning_bytes'])} GiB |" for r in e['fixed_prefix_scenarios'])
checks='\n'.join(f"| {r['cap']:,} | {r['nmax']:,} | {r['actual_seconds']:.1f}秒 | {r['predicted_base_seconds']:.1f}秒 | {r['peak_working_set_bytes']/1024**2:.1f} MiB |" for r in e['calibration'])
current=e['current_frontier']
text=f'''# このPCでの有限検算の到達ライン・2026-09-09

**暫定目標を「まず最大未処理次数300万以下、1日枠を狙うなら95万以下」と置く。**
解析的に全nの未処理係数がその次数以下へ収まることが前提。現在の未処理係数を勝手に切り捨てる意味ではない。
最大次数だけでなく、実際の被覆CSVをモデルに入れて時間・メモリの両方を判定する方が正確である。

| 許容時間 | 固定した先頭次数の目安 | メモリ予算見積り |
|---|---:|---:|
| 約1時間 | 13万以下 | 0.55 GiB |
| 約4時間 | 約31万以下 | 0.66 GiB |
| 約1日 | 95万以下 | 1.24 GiB |
| 約1週間 | 300万以下 | 4.31 GiB |

時間は実測モデルの**3倍を見込んだ計画値**。保証や統計的信頼区間ではない。
約31万次まで下げることは必須条件ではなく、数時間枠を狙う強めの目標だった。
現在の最大22,927,674次から、300万なら約7.6分の1、95万なら約24分の1が目安。
これは固定capが十分条件となる保守的な目安で、そこまで下がらなければ絶対に不可能という下界ではない。

## 実際に測ったもの

測定PCはWindows、物理RAM {gib(micro['hardware']['total_physical_bytes'])} GiB、論理CPU {micro['hardware']['logical_cpus']}個。
測定開始時の空きRAMは約{gib(micro['hardware']['available_physical_bytes'])} GiB。
現在のPython {micro['hardware']['python']} / NumPy {micro['hardware']['numpy']}の単一プロセス整数更新器を使用。
本番計画用の作業メモリ予算は8 GiBとした。GMP/FLINTや並列実装の性能は測定していない。

合成整数は128〜12288 bit、配列32768/131072要素、2種類のシフト幅、各7回を測定した。
別に実際のBorwein係数を、切り詰めた配列で構築し符号・零点も検査した。

| 保持次数 | 実行したnの上限 | 実測 | モデル基準時間 | 実測ピークWS |
|---|---:|---:|---:|---:|
{checks}

2つともモデルは実測より長めだった。ただしn=31146までの完走、数百万要素での長時間実行まで測定したわけではない。
実測した部分検査は全係数の新しい範囲検証ではないため、既存の全行整数検算n≤512を更新しない。

## シナリオ別の計画値

| 固定cap | 基準時間 | 3倍込み | メモリ予算見積り |
|---:|---:|---:|---:|
{scenarios}

現行の未処理領域をそのまま使うと、メモリ計画値は約{gib(current['memory_planning_bytes'])} GiB。
このPCの物理RAMと設定した8 GiB作業予算を超えるため、現行実装で本番に着手できる見積りではない。
RAMに常駐できるという仮定の参考時間は基準{current['base_seconds']/86400:.1f}日、3倍込み{current['planning_seconds_3x']/86400:.1f}日だが、
メモリ条件が成立せず、bit幅も測定上端を約2%超えるので、実際の完走時間として採用しない。
メモリ数字は計画モデルであり、この量を実際に確保したり、実測したりはしていない。

## 到達を判定する手順

1. 新しい解析結果の被覆CSVをestimate.pyへ渡す。
2. 8 GiB以内かつ3倍込みで1日/1週間以内、測定bit幅内なら性能面の候補とする。
3. 本番へ進む前に、残す範囲が数学的に正しいことを区間認証し、選んだ大きさで長めの実測を行う。

この到達ラインを作ったことで、今後はbulkの数字を下げるだけでなく、完走見積りがどれだけ縮むかを比較できる。
現在の結果は1日・1週間の性能ゲートをどちらも通っていない。

## 再実行

計測はCPU・メモリを奪い合わないよう、別々に順番に実行する。PythonとNumPyが必要。

```text
python feasibility/benchmark.py micro
python feasibility/benchmark.py prefix --cap 311468 --nmax 1024
python feasibility/benchmark.py prefix --cap 1000000 --nmax 512
python feasibility/estimate.py
python feasibility/report.py
```

新しい被覆を評価する場合：

```text
python feasibility/estimate.py --frontier NEW_FRONTIER.csv --output NEW_ESTIMATE.json
```

現モデルはn=513..31146の被覆CSVを想定し、それ以外はエラーにする。
[計算量・係数bit上界の導出](MODEL.md)、[生の測定結果](results/micro.json)、[機械可読の到達ライン](results/estimates.json)も同梱。

## AI使用と研究の状態

OpenAI Codexが測定コード、導出、ローカル計測、モデル化、文書化を行った。著者名なし。
専門家への連絡、GitHub公開は行っていない。
全域の解析作業稿閾値31147、厳密整数検算n≤512、被覆全体が未認証の診断である状態は変更しない。
今回作成したのは性能面の到達ラインであり、予想の証明完了ではない。
'''
(ROOT/'README.md').write_text(text,encoding='utf-8')
print('Wrote feasibility/README.md')
