"""Verified review bundle including the measured arrival-line model."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
assert json.loads((ROOT/'results/audit.json').read_text())['status']=='passed'
with zipfile.ZipFile(WORK/'borwein_proposal_completed_20260909.zip') as z:
    assert z.testzip() is None
    previous=json.loads(z.read('BUNDLE_MANIFEST.json'));contents={}
    for row in previous['files']:
        raw=z.read(row['path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        contents[row['path']]=raw
for p in ROOT.rglob('*'):
    r=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in r.parts):contents['feasibility/'+r.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 有限計算の到達ライン・2026-09-09

最新の実測と目安は [feasibility/README.md](feasibility/README.md) を参照。
現行Python実装と測定PCで、3倍の時間余裕込みの目安は95万次なら約1日、300万次なら約1週間。
解析的に未処理係数がその範囲へ収まることが前提です。完走保証ではありません。
現在の被覆ではメモリ予算を超え、本番実行の到達ラインには達していません。
コード、生計測、時間・メモリモデル、再評価CLIと過去ラウンド一式を同梱。
全域閾値31147、厳密な全行整数検算n≤512は変更なし。被覆全体も未認証の診断です。
AI使用は各記録に明記。著者名なし。GitHub公開はユーザーが行う想定です。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_feasibility_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(contents),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
