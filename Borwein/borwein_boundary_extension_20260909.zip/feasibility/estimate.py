"""Hardware-specific planning estimates; not runtime guarantees."""
import argparse,csv,json,math,hashlib
from pathlib import Path
import benchmark as b
np=b.np;OUT=b.OUT;WORK=b.WORK
N=31146;GIB=1024**3;MEMORY_BUDGET=8*GIB;RESERVE_FACTOR=3
micro=json.loads((OUT/'micro.json').read_text());bits=sorted(set(r['bits'] for r in micro['rows']))
rates=[]
for bit in bits:
    rows=[r for r in micro['rows'] if r['bits']==bit and r['size']==max(x['size'] for x in micro['rows'] if x['bits']==bit)]
    X=np.array([[r['subtractions'],4*r['size']] for r in rows]);y=np.array([r['update_median_seconds'] for r in rows])
    alpha,beta=np.linalg.lstsq(X,y,rcond=None)[0]
    if beta<0:alpha=max(r['update_median_seconds']/r['subtractions'] for r in rows);beta=0.
    if alpha<0:alpha=0.;beta=max(r['update_median_seconds']/(4*r['size']) for r in rows)
    rates.append((float(alpha),float(beta),max(r['check_median_seconds']/r['size'] for r in rows)))
rates=np.array(rates);coefficient=math.pi/(math.sqrt(3)*math.log(2))

def plan(caps,nmax=N):
    ns=np.arange(1,nmax+1,dtype=float);caps=np.asarray(caps,dtype=float)
    size=np.minimum(caps+1,10*ns*ns+1)
    # Uniform majorant for every intermediate coefficient of degree <= cap.
    maxbits=np.minimum(4*ns+1,np.ceil(coefficient*np.sqrt(size-1))+1)
    alpha=np.interp(maxbits,bits,rates[:,0]);beta=np.interp(maxbits,bits,rates[:,1]);checkrate=np.interp(maxbits,bits,rates[:,2])
    previous=np.r_[1,size[:-1]];adds=np.zeros(nmax);allocation=np.zeros(nmax)
    for j in range(4):
        shift=5*ns-4+j;new=np.minimum(previous+shift,caps+1)
        active=shift<new;adds+=np.where(active,new-shift,0);allocation+=np.where(active,new,0);previous=new
    # A fixed prefix ceases to change when the first new factor exceeds the cap.
    checks=np.where(allocation>0,np.minimum(size,5*ns*ns+1),0)
    seconds=float(np.sum(alpha*adds+beta*allocation+checkrate*checks))
    # Integral upper bound on the sum of coefficient-bit majorants, with
    # allocation slack and three simultaneous coefficient buffers.
    x0=(4*ns/coefficient)**2;small=np.minimum(size,x0)
    integrated_bits=size+(2/3)*coefficient*small**1.5+np.maximum(0,size-x0)*4*ns
    memory=3*(52*size+(4/30)*integrated_bits)+512*1024**2
    peak=int(np.argmax(memory));maxb=float(max(maxbits))
    return {'base_seconds':seconds,'planning_seconds_3x':RESERVE_FACTOR*seconds,'memory_planning_bytes':int(max(memory)),
      'memory_peak_n':int(ns[peak]),'max_degree':int(max(caps)),'integer_subtractions':int(sum(adds)),
      'max_bit_majorant':maxb,'bit_extrapolation_beyond_measured_range':bool(maxb>max(bits)),
      'fits_8_GiB_planning_budget':bool(max(memory)<=MEMORY_BUDGET)}

def fixed(cap,nmax=N):return plan(np.full(nmax,cap),nmax)

def run(frontier_path=None,output=None):
    source=Path(frontier_path) if frontier_path else WORK/'proposal-completion/results/frontier_adaptive.csv'
    with source.open() as f:frontier=list(csv.DictReader(f))
    assert [int(r['n']) for r in frontier]==list(range(513,N+1)), 'This model expects n=513..31146'
    caps=[int(frontier[0]['future_retention_degree'])]*512+[int(r['future_retention_degree']) for r in frontier]
    current=plan(caps)
    candidates=[100000,311468,500000,1000000,2000000,3000000,5000000]
    scenarios=[{'fixed_cap':cap,**fixed(cap)} for cap in candidates]
    lines=[]
    for label,seconds in [('1 hour',3600),('24 hours',86400),('7 days',604800)]:
        lo,hi=1,10_000_000
        while hi-lo>1:
            mid=(hi+lo)//2;r=fixed(mid)
            if r['planning_seconds_3x']<=seconds and r['memory_planning_bytes']<=MEMORY_BUDGET:lo=mid
            else:hi=mid
        rounded=(lo//10000)*10000
        lines.append({'time_budget':label,'model_cap_boundary':lo,'rounded_down_cap':rounded,**fixed(rounded)})
    checks=[]
    for path in sorted(OUT.glob('prefix_*.json')):
        actual=json.loads(path.read_text());calibration=fixed(actual['cap'],actual['nmax'])
        checks.append({'cap':actual['cap'],'nmax':actual['nmax'],'actual_seconds':actual['total_seconds'],
          'predicted_base_seconds':calibration['base_seconds'],'actual_over_predicted':actual['total_seconds']/calibration['base_seconds'],
          'peak_working_set_bytes':actual['memory']['peak_working_set_bytes'],
          'scope':'Partial real workload, not full-range validation'})
    result={'scope':'Single-host planning model, not certified runtime or a new sign theorem','method':'Current Python object-array exact updater',
      'N':N,'frontier_source':str(source),'frontier_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'memory_budget_bytes':MEMORY_BUDGET,'time_reserve_factor':RESERVE_FACTOR,'coefficient_bit_majorant_constant':coefficient,
      'fitted_rates':[{'bits':bit,'seconds_per_subtraction':r[0],'seconds_per_allocated_slot':r[1],'seconds_per_checked_slot':r[2]} for bit,r in zip(bits,rates)],
      'current_frontier':current,'fixed_prefix_scenarios':scenarios,'arrival_lines':lines,'calibration':checks,
      'performance_gate_24h':bool(current['fits_8_GiB_planning_budget'] and current['planning_seconds_3x']<=86400 and not current['bit_extrapolation_beyond_measured_range']),
      'performance_gate_7d':bool(current['fits_8_GiB_planning_budget'] and current['planning_seconds_3x']<=604800 and not current['bit_extrapolation_beyond_measured_range']),
      'critical_assumption':'A proven coverage would leave only coefficients up to the proposed fixed cap at every n; not true of current diagnostics.'}
    target=Path(output) if output else OUT/'estimates.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'current':current,'lines':lines,'calibration':checks},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--frontier');p.add_argument('--output');a=p.parse_args();run(a.frontier,a.output)
