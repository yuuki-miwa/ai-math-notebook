"""Exact Python-integer prefix workload and controlled microbenchmarks."""
import argparse,ctypes,gc,json,math,os,platform,random,statistics,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(WORK/'finite-compute'))
from verify_packed import np,memory,expected_zeros

def hardware():
    class Mem(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in ['total_phys','available_phys','total_page','available_page','total_virtual','available_virtual','extended']]
    m=Mem();m.length=ctypes.sizeof(m)
    if sys.platform=='win32':assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return {'python':platform.python_version(),'numpy':np.__version__,'logical_cpus':os.cpu_count(),'processor':os.environ.get('PROCESSOR_IDENTIFIER',platform.processor()),
      'total_physical_bytes':m.total_phys,'available_physical_bytes':m.available_phys,'platform':platform.platform()}

def step(old,k,cap):
    size=min(len(old)+k,cap+1)
    if k>=size:return old[:size]
    result=np.zeros(size,dtype=object);result[:min(len(old),size)]=old[:size]
    result[k:]-=old[:size-k]
    return result

def tests():
    # Independent list multiplication, including degrees past the cap and no-op shifts.
    for cap in [0,1,7,31,80]:
        a=np.array([1],dtype=object);full=[1]
        for k in [1,2,3,4,6,7,8,9,11,12,13,14]:
            b=full+[0]*k
            for j,v in enumerate(full):b[j+k]-=v
            full=b;a=step(a,k,cap)
            assert list(a)==full[:cap+1]

def prefix(cap,nmax):
    tests();a=np.array([1],dtype=object);rows=[];start=time.perf_counter();update=check=0.
    block_start=start;bu=bc=0.;adds=0
    for n in range(1,nmax+1):
        begin=time.perf_counter()
        for k in range(5*n-4,5*n):
            adds+=max(0,min(len(a)+k,cap+1)-k);a=step(a,k,cap)
        delta=time.perf_counter()-begin;update+=delta;bu+=delta
        begin=time.perf_counter();half=a[:5*n*n+1]
        for r in range(5):assert not np.any(half[r::5]<0 if r==0 else half[r::5]>0)
        if n>=2:assert set(map(int,np.flatnonzero(half==0)))=={z for z in expected_zeros(n) if z<len(half)}
        delta=time.perf_counter()-begin;check+=delta;bc+=delta
        if n in [64,128,256,512,768,1024,nmax]:
            sample=a[np.linspace(0,len(a)-1,min(4096,len(a))).astype(int)]
            bits=[abs(int(v)).bit_length() for v in sample]
            record={'n':n,'retained_degree':len(a)-1,'block_update_seconds':bu,'block_check_seconds':bc,'block_seconds':time.perf_counter()-block_start,
              'sample_mean_bits':statistics.mean(bits),'sample_max_bits':max(bits),'sample_mean_object_bytes':statistics.mean(sys.getsizeof(v) for v in sample),'memory':memory()}
            rows.append(record);print('Prefix',cap,'n',n,'seconds',time.perf_counter()-start,flush=True)
            bu=bc=0.;block_start=time.perf_counter()
    report={'status':'passed','scope':'Actual truncated coefficient updates and lower-half sign/zero checks; not a full finite verification extension',
      'hardware':hardware(),'cap':cap,'nmax':nmax,'update_seconds':update,'check_seconds':check,'total_seconds':time.perf_counter()-start,'integer_subtractions':adds,'rows':rows,'memory':memory()}
    (OUT/f'prefix_{cap}_{nmax}.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Prefix completed',report['total_seconds'],flush=True)

def micro():
    tests();hw=hardware();rng=random.Random(20260909);rows=[]
    for bits in [128,512,1024,2048,4096,8192,12288]:
        for size in [32768,131072]:
            if size*(bits/8+40)*4>hw['available_physical_bytes']*.15:continue
            base=np.array([(-1 if j%2 else 1)*((1<<(bits-1))|rng.getrandbits(bits-1)) for j in range(size)],dtype=object)
            for fraction in [.01,.5]:
                k=max(1,int(size*fraction));samples=[];checks=[]
                for repetition in range(7):
                    a=base;begin=time.perf_counter()
                    for shift in range(k,k+4):a=step(a,shift,size-1)
                    samples.append(time.perf_counter()-begin)
                    begin=time.perf_counter()
                    # Include both sign scans and zero identification, same array operations.
                    for r in range(5):np.any(a[r::5]<0 if r==0 else a[r::5]>0)
                    np.flatnonzero(a==0);checks.append(time.perf_counter()-begin)
                rows.append({'bits':bits,'size':size,'shift_fraction':fraction,'subtractions':sum(size-k-j for j in range(4)),
                  'update_median_seconds':statistics.median(samples[1:]),'update_min_seconds':min(samples[1:]),'update_max_seconds':max(samples[1:]),
                  'check_median_seconds':statistics.median(checks[1:]),'sample_object_bytes':sys.getsizeof(base[0]),'memory':memory()})
            del base,a;gc.collect();print('Micro',bits,size,flush=True)
    (OUT/'micro.json').write_text(json.dumps({'status':'completed','scope':'Synthetic exact-integer arithmetic workload, not Borwein coefficients','hardware':hw,'rows':rows},indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['micro','prefix','hardware']);p.add_argument('--cap',type=int,default=311468);p.add_argument('--nmax',type=int,default=1024);a=p.parse_args()
    if a.mode=='micro':micro()
    elif a.mode=='prefix':prefix(a.cap,a.nmax)
    else:print(json.dumps(hardware(),indent=2))
