"""Recheck all selected arc budgets using the previous interval verifier."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'arc-improvement'))
import certify_arcs
certify_arcs.e.ROOT=ROOT
if __name__=='__main__':
    certify_arcs.run()
    iv=certify_arcs.iv;I=iv.mpf
    selected=json.loads((ROOT/'results/bulk_thresholds_adaptive.json').read_text())
    tests=[]
    for index,a in [(0,4),(10,4),(64,3),(127,3)]:
        row=selected[index];n=row['first_passing_n'][a];tb=I(str(row['tau'][1]));eta=I(11313)/1250000
        total=I(0)
        def kappa(z):return I(1)/2+z/(12*(1-z*z/(4*iv.pi**2)))
        maxarg=718*(tb/n+10*iv.pi/4139)
        assert bool(maxarg.b<(2*iv.pi).a)
        for l in range(1,719):
            z=l*(tb/n+10*iv.pi/4139)
            total+=2*iv.exp(-eta*l)/l*(kappa(z)+kappa(z/5))
        tests.append({'cell':index,'residue':a,'n':n,'resonance_interval':str(total)})
    (ROOT/'results/cusp1_spot_checks.json').write_text(json.dumps({'status':'passed','scope':'Four interval evaluations, not uniform localization certification','checks':tests},indent=2)+'\n')
