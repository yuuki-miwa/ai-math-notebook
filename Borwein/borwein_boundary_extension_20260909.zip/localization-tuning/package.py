"""Verified extension of the preceding review bundle."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
with zipfile.ZipFile(WORK/'borwein_arc_improvement_20260909.zip') as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('BUNDLE_MANIFEST.json'));contents={}
    for row in manifest['files']:
        raw=z.read(row['path'])
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        contents[row['path']]=raw
for p in ROOT.rglob('*'):
    r=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in r.parts):contents['localization-tuning/'+r.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 局在化改善統合版・2026-09-09

最新の結果は [localization-tuning/README.md](localization-tuning/README.md) を参照。
最大未処理次数の診断値29,022,289。全域の解析作業稿閾値31147、厳密整数検算n≤512は変更なし。
今回の核の上界20,685組と円弧予算640点の区間検算を同梱。被覆全体は未認証の診断です。

過去の arc-improvement、hybrid-improvement、coverage-frontier、round4-6、finite-compute、
proposal-reviewも同梱しています。過去の状態説明はそれぞれの作成時点のものです。
Python、NumPy、mpmathが必要。過去の図の再生成にはMatplotlibも必要です。
AI使用は各記録に明記。著者名なし。独立査読完了や予想の証明完了は主張しません。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_localization_tuning_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(contents),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
