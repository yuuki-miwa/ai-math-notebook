"""Certified additional Fourier candidates with unchanged Dirichlet Q.
Coverage remains a floating-point diagnostic.
"""
import sys,json,math,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
sys.path.insert(0,str(WORK/'hybrid-improvement'))
cert=load('kernel_cert',WORK/'hybrid-improvement/certify_kernel.py')
arc=load('arc_model',WORK/'arc-improvement/explore.py')
np=arc.np;old=arc.old;iv=cert.iv;I=iv.mpf;Q=4139
CHOICES=[('0.012',667),('0.02',400),('0.03',267),('0.04',200),('0.0090504',718)]
OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)

def generate():
    data=[]
    for eta,k in CHOICES:
        e=I(eta);w=np.array([cert.upper_float(iv.exp(-e*l)/l) for l in range(1,k+1)])
        data.append((w,cert.upper_float(4*iv.log(2/e)),cert.upper_float(2*e+4*iv.exp(-e*k)/(e*k)),
          cert.upper_float(iv.pi**3/(30*Q)*(1/(1-I(k)/Q)+6/(1-I(5*k)/Q))),
          cert.upper_float(iv.pi**3/(30*Q*(1-I(k)/Q)))))
    rows=[]
    for b in range(2,Q+1):
        if b==5:continue
        r=np.arange(1,b//2+1,dtype=np.int64)
        if b%5==0:r=r[(5*r)%b!=0]
        s1,_=cert.sin_pi_rational_abs(r,b);_,s4=cert.sin_pi_rational_abs(4*r,b);s5,_=cert.sin_pi_rational_abs(5*r,b)
        g=cert.up(s4/cert.down(s1*s5));options=[]
        for (eta,k),(w,partial,penalty,vnon,vfive) in zip(CHOICES,data):
            mult=1 if b>2*k else 2*((k+b-1)//b)
            pooled=np.sort(np.repeat(g,mult))[::-1];top=np.zeros(k);top[:min(k,len(pooled))]=pooled[:k]
            total=0.
            for t in cert.up(top*w):total=math.nextafter(total+float(t),math.inf)
            # Retain the first 32 frequencies from the SAME numerator.
            # Only use multiplicity-one nonresonant denominators here.
            if b%5 and b>2*k:
                length=32;nums=np.arange(1,b//2+1,dtype=np.int64)
                nums=nums[np.gcd(nums,b)==1]
                accum=np.zeros(len(nums))
                for l in range(1,length+1):
                    rem=(nums*l)%b;dist=np.minimum(rem,b-rem)
                    accum=cert.up(accum+cert.up(w[l-1]*g[dist-1]))
                prefix=float(np.max(accum));tail=0.
                for t in cert.up(w[length:]*top[:k-length]):tail=math.nextafter(tail+float(t),math.inf)
                total=min(total,math.nextafter(prefix+tail,math.inf))
            factor=mult if b%5 else mult+2*((k+b//5-1)//(b//5))/4
            variation=math.nextafter(math.nextafter((vnon if b%5 else vfive)*b,math.inf)*factor,math.inf)
            total=math.nextafter(math.nextafter(total+variation,math.inf)+partial,math.inf)
            period=b if b%5 else b//5;res=0.
            for t in w[period-1::period]:res=math.nextafter(res+float(t),math.inf)
            constant=math.nextafter(penalty+math.nextafter(4*res,math.inf),math.inf)
            options.append({'cost_upper':total,'penalty_upper':constant})
        rows.append({'b':b,'options':options})
    report={'status':'passed','scope':'Additional combined-kernel cost and smoothing/tail/resonance enclosures, not full coverage',
      'Q':Q,'choices':CHOICES,'denominators':len(rows),'comparisons':len(rows)*len(CHOICES),'rows':rows,
      'prefix_length':32,'prefix_scope':'Non-5 denominators b>2K; all coprime numerators up to reflection',
      'arithmetic':'Outward binary64 kernel arithmetic and 70-digit mpmath.iv constants; inherits sin certificate assumptions'}
    (OUT/'candidate_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Certified',report['comparisons'],'denominator/parameter pairs',flush=True)
    return report

def run():
    report=generate();cost=np.full((len(CHOICES),Q),np.inf);penalty=np.zeros((len(CHOICES),Q))
    for row in report['rows']:
        for j,opt in enumerate(row['options']):cost[j,row['b']-1]=opt['cost_upper'];penalty[j,row['b']-1]=opt['penalty_upper']
    original=arc.prior.gaps
    def gaps(n,ta,tb,mode):
        base=original(n,ta,tb,mode);n=np.atleast_1d(n).astype(float);R=float(old.radial(tb)[0])
        for j in range(len(CHOICES)):base=np.maximum(base,R-penalty[j]-cost[j]/n[:,None])
        # At denominator 1 both Fourier sums are resonant. Keep each
        # frequency's actual argument, as previously done for denominator 5.
        ls=np.arange(1,old.K+1,dtype=float);weights=np.exp(-old.ETA*ls)/ls
        arg5=ls*(tb/n[:,None]+10*np.pi/Q)
        resonance=2*np.sum(weights*(old.kappa(arg5)+old.kappa(arg5/5)),axis=-1)
        cusp1=arc.prior.competition(ta,tb)[0]-2*old.ETA-old.TAIL-resonance/n
        base[:,0]=np.maximum(base[:,0],cusp1)
        return base
    arc.prior.gaps=gaps
    # arc.BASE uses the same module globals, including the patched gap evaluator.
    arc.prior.ratios=arc.ratios
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    allrows=[]
    for h in [.25,.3,.35,.4]:
        rows=arc.prior.thresholds(cells,str(h));allrows.append(rows)
        print('h',h,'bulk n',max(max(r['first_passing_n']) for r in rows),flush=True)
    combined=[]
    for i in range(128):
        row={'cell':i,'tau':allrows[0][i]['tau'],'first_passing_n':[],'at_first_pass':[],'selected_h':[]}
        for a in range(5):
            j=min(range(4),key=lambda j:allrows[j][i]['first_passing_n'][a])
            row['first_passing_n'].append(allrows[j][i]['first_passing_n'][a]);row['at_first_pass'].append(allrows[j][i]['at_first_pass'][a]);row['selected_h'].append([.25,.3,.35,.4][j])
        combined.append(row)
    (OUT/'bulk_thresholds_adaptive.json').write_text(json.dumps(combined,indent=2)+'\n')
    result=old.frontier(combined,'adaptive',OUT)
    print(json.dumps({k:v for k,v in result.items() if k!='samples'}),flush=True)

if __name__=='__main__':run()
