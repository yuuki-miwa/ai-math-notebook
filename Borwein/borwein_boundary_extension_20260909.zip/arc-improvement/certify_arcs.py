"""Interval upper bounds for the revised main, intermediate and Gaussian arcs.

The localization gap and coefficient-position mapping are NOT certified here.
"""
import json,functools
import explore as e
from mpmath import iv
iv.dps=60;I=iv.mpf

def parse(s):
    a,b=s.strip('[]').split(',');return I([a.strip(),b.strip()])
def point(s):return I(str(s))

@functools.lru_cache(None)
def constants(hstr):
    h=I(hstr);q=iv.cos(2*h);beta=I(1)/2-2*h*h/3
    c3=4/q+12*h/q**2+32*h**3/q**3
    c4=16/q+(64*h+12)/q**2+192*h*h/q**3+384*h**4/q**4
    decay=[]
    for i in range(256):
        u=h+(I('1.2')-h)*i/256;v=h+(I('1.2')-h)*(i+1)/256
        decay.append(((v-u),((iv.sin(2*v)/(2*v))**2*u*u/2).a))
    return h,beta,c3,c4,decay

def bounds(cell,n,a,hstr):
    h,beta,c3,c4,decay=constants(hstr);n=I(n)
    tau=parse(cell['tau_interval']);ta=tau.a;tb=tau.b
    V=parse(cell['V_interval']);vlo=V.a;vhi=min(V.b,(I(4)/3).b)
    phase=parse(cell['signed_phase_intervals'][a]);pl=phase.a;ph=phase.b
    w3=parse(cell['W3_interval']).b;w4=parse(cell['W4_interval']).b
    x=iv.exp(-ta);d=max(I('.75').a,(1-x).a)
    M=iv.exp(I('.8')*h/I('.75')).b
    if bool(ta>0):M=min(M,(1/(1-x)).b)
    a1=I('.8')*M*x/d;a2=M/2*(I('.8')*x/d**2+(I('.8')*x/d)**2)
    H=(ph*(c4*w4/(32*beta**2*vlo**2)+5*c3**2*w3**2/(192*beta**3*vlo**3))
       +4*(c3*a1*w3/(8*beta**2*vlo**2)+a2/(2*beta*vlo)))/iv.sqrt(2*beta)
    Z=iv.sqrt(tb**2+h*h);D=Z*(I(1)/30+2*x/(25*d))
    E=(Z/30*(ph+4*h*a1)+8*M*Z*x/(25*d))/iv.sqrt(2*beta)
    em=min(I(3400).b,(8*Z**3/I('.75')**3*((1-x)/ta if bool(ta>0) else I(1))).b)
    U=4*M/iv.sqrt(2*beta)*(em+D*D/2)*iv.exp(D/n+em/n**2)
    main=((H+E)/n+U/n**2)/pl
    amp=min(I(6).b,(1/(1-x)).b) if bool(ta>0) else I(6)
    integral=sum((width*iv.exp(-n*vlo*r) for width,r in decay),I(0))
    middle=8*amp*iv.sqrt(vhi/(2*iv.pi))*iv.sqrt(n)*iv.exp(7200/n)*integral/pl
    gaussian=8*iv.exp(-h*h*vlo*n/2)/pl
    return main,middle,gaussian

def run():
    cells=json.loads((e.old.PAPER/'results/profile_certificate.json').read_text())['cells']
    selected=json.loads((e.ROOT/'results/bulk_thresholds_adaptive.json').read_text())
    rows=[];max_discrepancy=0
    for cell,row in zip(cells,selected):
        for a in range(5):
            n=row['first_passing_n'][a];h=str(row['selected_h'][a])
            main,middle,gaussian=bounds(cell,n,a,h)
            total=main+middle+gaussian
            assert bool(total.b<I('.98').a),(cell['cell'],a,total)
            numerical=row['at_first_pass'][a]['components']
            for x,key in zip([main,middle,gaussian],['local_main','intermediate','gaussian_tail']):
                difference=abs(float(x.b)-numerical[key]);max_discrepancy=max(max_discrepancy,difference)
                assert difference<1e-10*max(1,numerical[key]),(cell['cell'],a,key,difference)
            rows.append({'cell':cell['cell'],'residue':a,'n':n,'h':h,
              'main_upper':str(main.b),'intermediate_upper':str(middle.b),'gaussian_upper':str(gaussian.b),
              'three_arc_sum_upper':str(total.b),'minor_arc_budget_lower':str((I('.98')-total).a)})
    report={'status':'passed','scope':'640 revised three-arc budgets conditional on inherited profile intervals; excludes localization and coverage mapping',
      'precision':60,'interval_count':len(rows),'maximum_float_comparison_error':max_discrepancy,'rows':rows}
    (e.ROOT/'results/arc_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))

if __name__=='__main__':run()
