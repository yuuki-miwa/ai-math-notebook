"""Adjust the small arc and integrate separate intermediate-arc bounds.
Diagnostic, not a complete interval coverage certificate.
"""
import sys,json,time,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'hybrid-improvement'))
spec=importlib.util.spec_from_file_location('hybrid_explore',ROOT.parent/'hybrid-improvement/explore.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
old=prior.old;np=old.np
BASE=prior.ratios

def constants(h):
    q=np.cos(2*h);beta=.5-2*h*h/3
    c3=4/q+12*h/q**2+32*h**3/q**3
    c4=16/q+(64*h+12)/q**2+192*h*h/q**3+384*h**4/q**4
    return beta,c3,c4

def ratios(cell,n,mode):
    h=float(mode);n=np.atleast_1d(n).astype(float)
    _,parts,gg=BASE(cell,n,'complete')
    ta,tb=old.ends(cell['tau_interval']);vlo,vhi=old.ends(cell['V_interval']);vhi=min(vhi,4/3)
    p=np.array([old.ends(x) for x in cell['signed_phase_intervals']]);pl=p[:,0];ph=p[:,1]
    w3=old.ends(cell['W3_interval'])[1];w4=old.ends(cell['W4_interval'])[1]
    beta,c3,c4=constants(h);x=np.exp(-ta);d=max(.75,1-x)
    M=min(np.exp(.8*h/.75),1/(1-x)) if ta>0 else np.exp(.8*h/.75)
    a1=.8*M*x/d;a2=M/2*(.8*x/d**2+(.8*x/d)**2)
    H=(ph*(c4*w4/(32*beta**2*vlo**2)+5*c3*c3*w3*w3/(192*beta**3*vlo**3))
       +4*(c3*a1*w3/(8*beta**2*vlo**2)+a2/(2*beta*vlo)))/np.sqrt(2*beta)
    Z=np.sqrt(tb*tb+h*h);D=Z*(1/30+2*x/(25*d))
    E=(Z/30*(ph+4*h*a1)+8*M*Z*x/(25*d))/np.sqrt(2*beta)
    em=min(3400,8*Z**3/.75**3*(-np.expm1(-ta)/ta if ta>0 else 1))
    U=4*M/np.sqrt(2*beta)*(em+D*D/2)*np.exp(D/n+em/n**2)
    parts[:,:,0]=((H+E)/n[:,None]+U[:,None]/n[:,None]**2)/pl
    edges=np.linspace(h,1.2,257);u=edges[:-1];v=edges[1:]
    decay=.5*(np.sin(2*v)/(2*v))**2*u*u
    amp=min(6,1/(1-x)) if ta>0 else 6
    integral=np.sum((v-u)*old.safe_exp(-n[:,None]*vlo*decay),axis=-1)
    middle=8*amp*np.sqrt(vhi/(2*np.pi))*np.sqrt(n)*np.exp(7200/n)*integral
    parts[:,:,2]=middle[:,None]/pl
    parts[:,:,3]=(8*old.safe_exp(-h*h*vlo*n/2))[:,None]/pl
    return parts.sum(axis=-1),parts,gg

def run():
    out=ROOT/'results';out.mkdir(parents=True,exist_ok=True)
    cells=json.loads((old.PAPER/'results/profile_certificate.json').read_text())['cells']
    prior.ratios=ratios
    summaries=[];best=None
    for h in [.25,.3,.35,.4]:
        rows=prior.thresholds(cells,str(h));last=max(max(r['first_passing_n']) for r in rows)
        summaries.append({'h':h,'all_bulk_first_n':last});print(summaries[-1],flush=True)
        (out/f'thresholds_h{h}.json').write_text(json.dumps(rows,indent=2)+'\n')
        if best is None or last<best[0]:best=(last,h,rows)
    # The union can choose a different valid arc width for every cell/residue.
    allrows=[json.loads((out/f'thresholds_h{h}.json').read_text()) for h in [.25,.3,.35,.4]]
    combined=[]
    for i in range(128):
        row={'cell':i,'tau':allrows[0][i]['tau'],'first_passing_n':[],'at_first_pass':[],'selected_h':[]}
        for a in range(5):
            j=min(range(4),key=lambda j:allrows[j][i]['first_passing_n'][a])
            row['first_passing_n'].append(allrows[j][i]['first_passing_n'][a]);row['at_first_pass'].append(allrows[j][i]['at_first_pass'][a]);row['selected_h'].append([.25,.3,.35,.4][j])
        combined.append(row)
    (out/'bulk_thresholds_adaptive.json').write_text(json.dumps(combined,indent=2)+'\n')
    result=old.frontier(combined,'adaptive',out)
    (out/'search.json').write_text(json.dumps(summaries,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='samples'}),flush=True)

if __name__=='__main__':run()
