"""Extend the verified previous review ZIP without modifying it."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
source=WORK/'borwein_hybrid_improvement_20260909.zip'
with zipfile.ZipFile(source) as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('BUNDLE_MANIFEST.json'))
    contents={}
    for row in manifest['files']:
        raw=z.read(row['path'])
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        contents[row['path']]=raw
for p in ROOT.rglob('*'):
    r=p.relative_to(ROOT)
    if p.is_file() and not any(s.startswith('.') or s=='__pycache__' for s in r.parts):contents['arc-improvement/'+r.as_posix()]=p.read_bytes()
contents['START_HERE.md']='''# Borwein 円弧改善統合版・2026-09-09

最初に [今回の結果](arc-improvement/README.md) を読んでください。
最大未処理次数の診断値は 65,899,108 → 31,681,364。
新しい円弧予算640点を区間検算しました。全体の被覆証明書ではありません。
解析作業稿の全域閾値31147、厳密整数検算 n≤512 は変更していません。

arc-improvementが今回、hybrid-improvementが前回、coverage-frontierが最初の被覆診断です。
round4-6は解析作業稿、finite-computeは厳密整数検算、proposal-reviewは過去の提案確認記録です。
過去の記録の「未再現」等は各作成時点の状態です。最新状況は今回のREADMEを優先してください。
Python、NumPy、mpmathが必要。図にはMatplotlibが必要です。依存パッケージは同梱しません。
AI使用は各記録に明記。著者名なし。独立査読完了や予想の証明完了は主張しません。
'''.encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=WORK/'borwein_arc_improvement_20260909.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(contents),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
