"""Independent exact checks of carry decoding, truncation, and l1 identity."""
import itertools,json,random
from pathlib import Path
from verify_packed import np,examine,expected_zeros

def decode(coeff,w=64,cap=None):
    if cap is None:cap=len(coeff)-1
    B=1<<w
    value=sum(c<<(w*j) for j,c in enumerate(coeff))%(B**(cap+1))
    raw=value.to_bytes((cap+1)*(w//8),'little')
    digits=[int.from_bytes(raw[j*w//8:(j+1)*w//8],'little') for j in range(cap+1)]
    signs=[int(x>=B//2) for x in digits]
    actual=[x-B*signs[j]+(signs[j-1] if j else 0) for j,x in enumerate(digits)]
    assert actual==coeff[:cap+1]
    array=np.frombuffer(raw,np.uint64).reshape(cap+1,w//64)
    previous=np.array([False]+[bool(s) for s in signs[:-1]])
    zero=((np.bitwise_or.reduce(array,axis=1)==0)&~previous)|((np.bitwise_and.reduce(array,axis=1)==np.iinfo(np.uint64).max)&previous)
    assert list(zero)==[x==0 for x in coeff[:cap+1]]

def naive(n):
    coeff=[1]
    for k in range(1,5*n):
        if k%5:
            new=coeff+[0]*k
            for j,c in enumerate(coeff):new[j+k]-=c
            coeff=new
    return coeff

def run():
    boundary=(1<<63)-1;cases=0
    for row in itertools.product((-boundary,-1,0,1,boundary),repeat=5):
        decode(list(row));cases+=1
    rng=random.Random(20260908)
    for _ in range(1000):
        row=[rng.randrange(-boundary,boundary+1) for _ in range(30)]
        decode(row,cap=rng.randrange(30));cases+=1
    # Includes the negative-to-zero borrow chain and modulo-truncated products.
    for n in range(1,21):
        coeff=naive(n);half=5*n*n+1
        assert coeff==coeff[::-1]
        assert [sum(coeff[a::5]) for a in range(5)]==[4*5**(n-1)]+[-5**(n-1)]*4
        assert sum(map(abs,coeff))==8*5**(n-1)
        for cap in (half-1,len(coeff)-1):
            w=64;mask=(1<<(w*(cap+1)))-1;value=1
            for j in range(1,n+1):
                for k in range(5*j-4,5*j):value=(value<<(w*k))-value
                value&=mask
            data=value.to_bytes((cap+1)*8,'little')
            raw,negative,previous,zeros=examine(data,8,n)
            actual=[int.from_bytes(r,'little')-int(s)*(1<<64)+int(p) for r,s,p in zip(raw,negative,previous)]
            assert actual==coeff[:half]
        decode(coeff,cap=half-1)
    result={'status':'passed','carry_and_zero_cases':cases,'naive_product_rows':20,
      'seed':20260908,'checks':['signed-digit decoding including extreme values and borrow chains','random truncation','packed update versus independent naive products','reciprocity','residue sums and l1 identity']}
    Path(__file__).with_name('results').joinpath('tests.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':run()
