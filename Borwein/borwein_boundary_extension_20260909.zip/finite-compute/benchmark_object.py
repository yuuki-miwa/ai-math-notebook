"""Legacy object-array update with the same sign/zero workload, without hashes.

Run separately from packed verification to avoid CPU/memory contention.
"""
import argparse,json,time
from pathlib import Path
from verify_packed import np,memory,expected_zeros

def verify(max_n,output,truncate=False):
    if not 1<=max_n<=(512 if truncate else 256):raise ValueError('Cap: 256 full / 512 truncated')
    start=time.perf_counter();multiply=check=0.;coeff=np.array([1],dtype=object)
    for n in range(1,max_n+1):
        t=time.perf_counter()
        for k in range(5*n-4,5*n):
            old=coeff
            size=min(len(old)+k,5*max_n*max_n+1) if truncate else len(old)+k
            coeff=np.zeros(size,dtype=object)
            coeff[:min(len(old),size)]=old[:size]
            coeff[k:]-=old[:size-k]
        multiply+=time.perf_counter()-t
        t=time.perf_counter();half=coeff[:5*n*n+1]
        for a in range(5):
            assert not np.any(half[a::5]<0 if a==0 else half[a::5]>0)
        zeros=set(map(int,np.flatnonzero(half==0)))
        if n>=2:assert zeros==expected_zeros(n)
        check+=time.perf_counter()-t
        if n%64==0:print(f'object: n={n}/{max_n}',flush=True)
    result={'status':'passed','method':('truncated' if truncate else 'legacy-full')+'-object-array-sign-zero-core',
      'max_n':max_n,'independent_coefficients_checked':5*max_n*(max_n+1)*(2*max_n+1)//6+max_n,
      'full_coefficients_covered':10*max_n*(max_n+1)*(2*max_n+1)//6+max_n,
      'seconds':{'total':time.perf_counter()-start,'multiplication':multiply,'decode_and_check':check},
      'memory':memory(),'note':'Same lower-half sign and zero decisions as packed; no hashes, RR identities or modular checks. The optional truncated variant retains degrees <= 5*max_n^2.'}
    Path(output).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-n',type=int,default=256);p.add_argument('--output',required=True)
    p.add_argument('--truncate',action='store_true')
    a=p.parse_args();verify(a.max_n,a.output,a.truncate)
