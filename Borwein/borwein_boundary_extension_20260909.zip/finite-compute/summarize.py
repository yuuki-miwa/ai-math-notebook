"""Build the result note from saved measurements; never runs verification."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def read(name):return json.loads((ROOT/'results'/name).read_text(encoding='utf-8'))
def core(r):return r['seconds']['multiplication']+r['seconds']['decode_and_check']
def main():
    full=read('object_256.json');trunc=read('object_truncated_256.json')
    packed=read('packed_v2_256.json');large=read('packed_v2_512.json');large_object=read('object_truncated_512.json')
    assert all(r['status']=='passed' for r in (full,trunc,packed,large,large_object))
    rows=[]
    for label,r in [('従来の全係数配列',full),('固定した半分までの配列',trunc),('整数詰め込み v2',packed)]:
        rows.append(f"| {label} | {core(r):.3f} 秒 | {r['seconds']['total']:.3f} 秒 | {r['memory']['peak_working_set_bytes']/2**20:.1f} MiB |")
    N=31146
    width=64*(((128*5**(N-2)).bit_length()+1+63)//64)
    target_bytes=(5*N*N+1)*(width//8)
    text=f'''# 第1ラウンドの実測結果

**採用候補は、従来の整数係数配列を固定した次数上限まで切り詰める方法です。**
256 までの同一検査で、計算本体は {core(full)/core(trunc):.2f} 倍速、
所要時間は {(1-core(trunc)/core(full))*100:.1f}% 減、ピークワーキングセットは
{(1-trunc['memory']['peak_working_set_bytes']/full['memory']['peak_working_set_bytes'])*100:.1f}% 減でした。
複雑な整数詰め込みより、今回の実測ではこの単純な変更が有利でした。

## 256 までの比較

| 方法 | 積の更新＋符号・零点検査 | 記録を含む総時間 | プロセスのピークワーキングセット |
|---|---:|---:|---:|
{chr(10).join(rows)}

全て同じホストで別々に実行した一回ずつの計測で、統計的な性能保証ではありません。
配列版はハッシュを作成せず、packed の総時間には生バイトハッシュと従来35行との照合を含みます。
速度比はこれらを除いた計算本体で比較しました。過去の全スイート約59秒との直接比較はしていません。
メモリはプロセス全体のピーク実測です。配列だけの理論サイズや OS のコミット量とは異なります。

## 有限範囲の拡張

**n=1..512 の全行が、二つの実装で通過しました。新たに確認した範囲は n=257..512 です。**

| 512 までの方法 | 計算本体 | 総時間 | ピークワーキングセット |
|---|---:|---:|---:|
| 切り詰めた通常の係数配列 | {core(large_object):.3f} 秒 | {large_object['seconds']['total']:.3f} 秒 | {large_object['memory']['peak_working_set_bytes']/2**20:.1f} MiB |
| 整数詰め込み v2 | {core(large):.3f} 秒 | {large['seconds']['total']:.3f} 秒 | {large['memory']['peak_working_set_bytes']/2**20:.1f} MiB |

packed は下半分の **{large['independent_coefficients_checked']:,} 個**を直接判定しました。
相反性で覆われる上半分も含めると、累計 **{large['full_coefficients_covered']:,} 個**です。
上半分を独立に再計算したという意味ではありません。
通常の配列版でも同じ符号・零点検査が通過しています。
二つの512実装は全行の係数ハッシュ同士を照合したわけではなく、全行の判定結果が一致しています。

追加の検証は、繰り下がり・極端な桁値・切り詰め等 4,125 例、独立な小さい積 20 行、
旧版の全係数十進ハッシュ 35 行との照合です。詳細は `results/tests.json` と `packed_v2_*.json` にあります。

## 研究全体での位置

- 解析側：v0.7 の作業定理 `n >= 31147` は変更していません。今回その証明全体を再監査していません。
- 有限計算側：以前の `n <= 256` から `n <= 512` に拡張しました。
- 両者の間に残る範囲：**513 <= n <= 31146**。全 n の予想の証明完了ではありません。

今回の改善は定数倍です。行数の上限を倍にすると、直接調べる係数数は概ね 8 倍、
この実装で扱う総ビット量は概ね 16 倍になります。
N=31146 を今回の packed 実装の固定桁幅で表すと、保持する整数の生データだけで約
**{target_bytes/2**40:.1f} TiB** が必要という設計上の見積りになります。実行はしていません。
この数字は最良のアルゴリズムに必要なメモリの下界ではありません。
計算の全面的な実用化には、さらに別の構造的な節約が必要です。

## 配布物

`README.md` に方法の根拠と再実行手順、`results/` に実測と検査結果、`reference/` に旧証明書を保存しました。
`MANIFEST.json` は配布ファイルの SHA-256 一覧です。従来の v0.7 ZIP は変更していません。
コード・検討・計測・文書作成は OpenAI Codex によります。著者名は記載せず、GitHub への送信も行っていません。
'''
    (ROOT/'RESULTS.md').write_text(text,encoding='utf-8')
    print('Wrote RESULTS.md (UTF-8)')
if __name__=='__main__':main()
