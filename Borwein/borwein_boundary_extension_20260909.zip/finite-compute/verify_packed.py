"""Exact Borwein coefficient signs via balanced base-2^w integer packing.

No floating point arithmetic is used for coefficient or sign decisions.
An inductive l1 coefficient bound and a guard bit exclude carry aliasing.
"""
import argparse,ctypes,hashlib,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
local=ROOT.parent/'.local-deps'
if local.is_dir():sys.path.insert(0,str(local))
import numpy as np
if not __debug__:raise RuntimeError('Do not use Python -O')

def memory():
    if sys.platform!='win32':return {}
    from ctypes import wintypes as w
    fields=[('cb',w.DWORD),('PageFaultCount',w.DWORD)]+[(x,ctypes.c_size_t) for x in
      ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage',
       'QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage')]
    S=type('PROCESS_MEMORY_COUNTERS_EX',(ctypes.Structure,),{'_fields_':fields});s=S();s.cb=ctypes.sizeof(s)
    get=ctypes.windll.psapi.GetProcessMemoryInfo
    get.argtypes=[w.HANDLE,ctypes.c_void_p,w.DWORD];get.restype=w.BOOL
    if not get(w.HANDLE(-1),ctypes.byref(s),s.cb):return {}
    return {'peak_working_set_bytes':s.PeakWorkingSetSize,'peak_commit_bytes':s.PeakPagefileUsage}

def expected_zeros(n):
    return {5*j+a for j in range(n) for a in (3,4)}|{7,5*n+8,5*n+9}

def examine(data,slot_bytes,n):
    count=5*n*n+1
    raw=np.frombuffer(data,dtype=np.uint8,count=count*slot_bytes).reshape(count,slot_bytes)
    negative=(raw[:,-1]&128)!=0
    previous=np.empty(count,dtype=bool);previous[0]=False;previous[1:]=negative[:-1]
    # A raw slot is c_j - carry_{j-1} modulo B. Restore the incoming carry.
    words=raw.view(np.uint64)
    zero=((np.bitwise_or.reduce(words,axis=1)==0)&~previous)|((np.bitwise_and.reduce(words,axis=1)==np.iinfo(np.uint64).max)&previous)
    for a in range(5):
        bad=(negative[a::5] if a==0 else ~negative[a::5])&~zero[a::5]
        if np.any(bad):raise AssertionError(('sign',n,a,int(np.flatnonzero(bad)[0])*5+a))
    positions=set(map(int,np.flatnonzero(zero)))
    if n>=2:assert positions==expected_zeros(n),('zeros',n,positions)
    return raw,negative,previous,positions

def decimal_digest(raw,negative,previous):
    width=raw.shape[1];B=1<<(8*width)
    half=[int.from_bytes(row,'little')-int(s)*B+int(p) for row,s,p in zip(raw,negative,previous)]
    digest=hashlib.sha256()
    for x in half:digest.update((str(x)+'\n').encode('ascii'))
    for x in reversed(half[:-1]):digest.update((str(x)+'\n').encode('ascii'))
    return digest.hexdigest()

def verify(max_n=256,output=None,reference=None,cross_through=32,cross_at=(64,128,256),hash_rows=True):
    if not 1<=max_n<=768:raise ValueError('This round is limited to max_n <= 768')
    bound=max(16,128*5**max(0,max_n-2))
    w=64*((bound.bit_length()+1+63)//64);slot_bytes=w//8;cap=5*max_n*max_n
    packed_bytes=(cap+1)*slot_bytes
    if packed_bytes>1200*1024**2:raise ValueError('Packed data budget exceeded')
    reference_rows={}
    if reference:
        old=json.loads(Path(reference).read_text(encoding='utf-8'))
        assert old['status']=='passed'
        reference_rows={r['n']:r['coefficients_sha256_decimal_lines'] for r in old['finite_rows']}
    start=time.perf_counter();multiply=check=hashing=cross=0.
    value=1;degree=0;mask=None;rows=[];checked=0
    for n in range(1,max_n+1):
        t=time.perf_counter()
        for k in range(5*n-4,5*n):
            degree+=k
            # Four sign reversals give the same B_n; each update stays positive.
            value=(value<<(w*k))-value
        # Reduction once per four-factor block is exact in Z/(B^(cap+1)).
        if degree>cap:
            if mask is None:mask=(1<<(w*(cap+1)))-1
            value&=mask
        multiply+=time.perf_counter()-t
        t=time.perf_counter()
        assert value>=0
        data=value.to_bytes((min(degree,cap)+1)*slot_bytes,'little')
        raw,negative,previous,zeros=examine(data,slot_bytes,n)
        check+=time.perf_counter()-t
        row={'n':n,'degree':10*n*n,'independent_coefficients_checked':5*n*n+1,
             'full_coefficients_covered':10*n*n+1,'zeros_in_lower_half':len(zeros),'status':'passed'}
        if hash_rows:
            t=time.perf_counter();row['packed_lower_half_sha256']=hashlib.sha256(raw).hexdigest();hashing+=time.perf_counter()-t
        if reference and (n<=cross_through or n in cross_at) and n in reference_rows:
            t=time.perf_counter();digest=decimal_digest(raw,negative,previous)
            assert digest==reference_rows[n],('legacy digest mismatch',n)
            row['legacy_decimal_digest_match']=True;row['legacy_decimal_digest']=digest
            cross+=time.perf_counter()-t
        rows.append(row);checked+=5*n*n+1
        # Release buffers before the next large shift to reduce peak live memory.
        del raw,negative,previous,data
        if n%64==0:print(f'packed: n={n}/{max_n}',flush=True)
    elapsed=time.perf_counter()-start
    result={'status':'passed','method':'balanced-integer-packing-v2','python':sys.version.split()[0],
      'numpy':np.__version__,'max_n':max_n,'slot_bits':w,'slot_bytes':slot_bytes,
      'coefficient_bound':'n=1: 16; n>=2: 128*5^(n-2), conditional only on previously verified rows; see README proof',
      'retained_degree_cap':cap,
      'largest_packed_bytes':packed_bytes,'independent_coefficients_checked':checked,
      'full_coefficients_covered':2*checked-max_n,
      'legacy_rows_matched':sum(bool(x.get('legacy_decimal_digest_match')) for x in rows),
      'seconds':{'total':elapsed,'multiplication':multiply,'decode_and_check':check,'hashing':hashing,'legacy_cross_check':cross},
      'memory':memory(),'rows':rows,
      'scope':'Exact signs and zero locations for every 1<=n<=max_n; upper halves follow from the proved reciprocal identity. No claim for larger n.'}
    if output:
        path=Path(output);path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2),flush=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-n',type=int,default=256);p.add_argument('--output')
    p.add_argument('--reference');p.add_argument('--cross-through',type=int,default=32)
    p.add_argument('--no-hash',action='store_true')
    a=p.parse_args();verify(a.max_n,a.output,a.reference,a.cross_through,hash_rows=not a.no_hash)
