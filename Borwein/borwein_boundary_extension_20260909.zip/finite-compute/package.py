"""Package this completed finite-computation round, without changing v0.7."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXCLUDED={'results/packed_128.json','results/packed_256.json','MANIFEST.json'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.relative_to(ROOT).as_posix() not in EXCLUDED)
manifest={'format':1,'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
m=ROOT/'MANIFEST.json';m.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
target=ROOT.parent/'borwein_finite_compute_round1_20260908.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files+[m]:z.write(p,'finite-compute/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:
        data=z.read('finite-compute/'+row['path'])
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(files)+1},indent=2))
