"""Create the standalone diagnostic package and verify every archive member."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
files=[]
for folder in [ROOT,ROOT/'results',ROOT/'reference',ROOT/'reference/results']:
    for p in folder.iterdir():
        if p.is_file() and p.name!='MANIFEST.json':files.append(p)
files.sort()
manifest={'scope':'Diagnostic package, not a proof certificate','files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
m=ROOT/'MANIFEST.json';m.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
target=ROOT.parent/'borwein_coverage_frontier_round1_20260908.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[m]:z.write(p,'coverage-frontier/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for item in manifest['files']:
        raw=z.read('coverage-frontier/'+item['path'])
        assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(files)+1},indent=2))
