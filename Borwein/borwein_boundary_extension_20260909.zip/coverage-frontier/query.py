"""Print every unresolved interval for one n, including gaps below plot resolution."""
import argparse,csv,json,math
import diagnose as d

def query(n,mode='local'):
    if not 513<=n<=31146:raise ValueError('Require 513 <= n <= 31146')
    root=d.ROOT/'results';rows=json.loads((root/f'bulk_thresholds_{mode}.json').read_text(encoding='utf-8'))
    tau=[rows[0]['tau'][0]]+[row['tau'][1] for row in rows];rho=5*d.radial(tau)[1]
    lower=d.endpoint_kmin(n);residues=[]
    for a in range(5):
        def lattice(lo,hi):return math.ceil((lo-a)/5),math.floor((hi-a)/5)
        covered=[lattice(0,5*n if a<3 else 10*n-1)]
        if lower is not None:
            shift=0 if a<3 else 5*n
            covered.append(lattice(lower+shift,rho[-1]*n*n+shift))
        for j,row in enumerate(rows):
            if n>=row['first_passing_n'][a]:covered.append(lattice(rho[j+1]*n*n,rho[j]*n*n))
        remaining=d.complement(covered,(5*n*n-a)//5)
        residues.append({'residue':a,'intervals_step5':[[5*lo+a,5*hi+a] for lo,hi in remaining],
                         'uncovered_count':sum(hi-lo+1 for lo,hi in remaining)})
    maximum=max((hi for r in residues for lo,hi in r['intervals_step5']),default=-1)
    count=sum(r['uncovered_count'] for r in residues)
    with (root/f'frontier_{mode}.csv').open(encoding='utf-8') as f:
        saved=next(r for r in csv.DictReader(f) if int(r['n'])==n)
    assert maximum==int(saved['last_uncovered_degree']) and count==int(saved['uncovered_coefficients_lower_half'])
    return {'n':n,'mode':mode,'scope':'Uncertified diagnostic; m is in the lower half and intervals have step 5',
            'endpoint_kmin':lower,'last_uncovered_degree':maximum,'uncovered_count':count,'residues':residues}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,required=True);p.add_argument('--mode',choices=['uniform','local','oracle'],default='local')
    args=p.parse_args();print(json.dumps(query(args.n,args.mode),indent=2))
