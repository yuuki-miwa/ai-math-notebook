"""Independent 80-digit recomputation and exact interval-union tests.

This checks the diagnostic implementation, not the analytic theorem.
"""
import functools,json,random
import diagnose as d
from mpmath import mp
mp.dps=80
M=mp.mpf;P=mp.pi;E=M(11313)/1250000;E5=M(113)/40000
Q=4139;K=718;K5=2717
L=mp.log(2/E);L5=mp.log(2/E5)
TAIL=10*mp.exp(-E*K)/(E*K);TAIL5=10*mp.exp(-E5*K5)/(E5*K5)
def ivends(s):return [M(x.strip()) for x in s[1:-1].split(',')]
def calL(x):return (1+x)*mp.log1p(x)-x*mp.log(x)
def kappa(z):return M('.5')+z/(12*(1-z*z/(4*P*P))) if z<2*P else mp.inf
def R(t):return mp.log(5) if not t else (2*P**2/15+mp.polylog(2,mp.exp(-5*t))/5-mp.polylog(2,mp.exp(-t)))/t
def mu(t):return M(1) if not t else (R(t)-mp.log((1-mp.exp(-5*t))/(1-mp.exp(-t))))/t
def sums(k,e):return sum(mp.exp(-e*l)/(l*((l+1)//2)) for l in range(1,k+1)),sum(mp.exp(-e*l)/l**2 for l in range(1,k+1))
s0,s1=sums(K,E);s05,_=sums(K5,E5)
def period(b,k,e,s):
    q=mp.exp(-e*b)
    return s+2*(1+mp.log(k))*q/(b*(1-q)),P**2/(3*(1-q))
corr=1/(Q*(1-M(K)/Q))+5/(Q*(1-M(5*K)/Q))
t,u=period(101,K,E,s0);t1,u1=period(301,K5,E5,s05);t5,u5=period(61,K5,E5,s05)
cost=[0,(1/(2*(1-M(K)/Q))+1/(2*(1-M(5*K)/Q)))*100*L,
      K*(2*t+corr*u),Q*M('.5')*(2*s1+corr*P**2/6),
      M('.6')/(1-M(K5)/Q)*300*L5,Q*M('.5')*(t1+t5/5+(u1+u5/5)/(Q*(1-M(K5)/Q))),
      5*L5/(2*(1-M(K5)/Q))]

@functools.lru_cache(None)
def gamma(b):
    total=M(0)
    for diff in range(1,5):
        g=[]
        for i in range(1,401):
            y=mp.exp(-E5-b*M(i)/400)
            g.append(min(M(5-diff)/25,sum(y**(2*j+diff) for j in range(5-diff))/sum(y**j for j in range(5))**2))
        g.append(M(0))
        for i in range(1,401):
            x=M(i)/400;a=min(M(2),M('1.2')*diff*x)
            total+=(g[i-1]-g[i])*x*(a*a/6-a**4/120)
    return total

@functools.lru_cache(None)
def bases(a,b):
    r=R(b);short=4*(1-P/6)*mp.log(2*mp.sin(1))
    g1=r-max(short,M('.8')+4*P*calL(E/2));g2=r-M('.4')-4*P*calL(E)
    if a:
        B=mp.polylog(2,mp.exp(-a));q=B*B/(P*P/6*a)
        g1=max(g1,r-q-4*calL(E/a));g2=max(g2,r-q/2-2*calL(E/a))
    return [max(g1,M('.025')),max(g2,M('.1')),r-4*mp.log(2)/101,r-4*mp.log(2)/(2*K+1),r/2,r-5*mp.log(5)/301,gamma(b)]

def ratio(cell,n,residue,mode):
    a,b=ivends(cell['tau_interval']);n=M(n)
    base=bases(a,b)
    z=b*K/n+10*P*K/Q;z5=b*K5/n+2*P*K5/Q
    penalties=[2*E+TAIL+4*kappa(z)*L/n]*4+[2*E5+TAIL5+4*kappa(z5)*L5/n]*3
    delta=min(g-c/n-p for g,c,p in zip(base,cost,penalties))
    vlo,vhi=ivends(cell['V_interval']);vhi=min(vhi,M(4)/3)
    phase=ivends(cell['signed_phase_intervals'][residue])[0]
    r=cell['grouped_residue_bounds'][residue]
    H=ivends(r['Gaussian_coefficient_interval'])[1];em=ivends(r['EM_first_coefficient_interval'])[1]
    Z=mp.sqrt(b*b+M('.16'));D=Z*(M(1)/30+2*mp.exp(-a)/(25*M('.75')))
    U=4*M('1.54')*(3400+D*D/2)/mp.sqrt(M('.78'))*mp.exp(D/n+3400/n**2)
    minor=0 if mode=='oracle' else (5*mp.sqrt(2*P*vhi)*n**M('1.5')*mp.exp(-n*delta) if delta>0 else mp.inf)
    middle=4*M('2.4')*6*mp.sqrt(vhi/(2*P))*mp.sqrt(n)*mp.exp(7200/n-M('.052')*vlo*n)
    tail=8*mp.exp(-M('.08')*vlo*n)
    return ((H+em)/n+U/n**2+minor+middle+tail)/phase

def run():
    root=d.ROOT/'results';source=json.loads((d.PAPER/'results/profile_certificate.json').read_text(encoding='utf-8'))
    radial_error=0.;mu_error=0.
    for j in range(129):
        t=M(11)*j/256;rf,mf,_=d.radial(float(t))
        radial_error=max(radial_error,abs(float(rf)-float(R(t))));mu_error=max(mu_error,abs(float(mf)-float(mu(t))))
    assert radial_error<1e-12 and mu_error<1e-12
    endpoint_error=0.
    for n in [847,1000,10350,17454,31146]:
        exact=5*n*n*mu(5*n*M('.0013'))
        endpoint_error=max(endpoint_error,abs(d.endpoint_kmin(n)-float(exact)))
    assert endpoint_error<1e-7
    ratios=[]
    for mode in ['local','oracle']:
        rows=json.loads((root/f'bulk_thresholds_{mode}.json').read_text(encoding='utf-8'))
        for cellid in [0,7,127]:
            cell=source['cells'][cellid]
            for residue in range(5):
                threshold=rows[cellid]['first_passing_n'][residue]
                for n in [threshold-1,threshold]:
                    high=ratio(cell,n,residue,mode)
                    low=float(d.components(cell,d.np.array([n]),mode)[0].sum(axis=-1)[0,residue])
                    assert abs(float(high)-low)<1e-7,(mode,cellid,residue,n,str(high),low)
                    assert (high<M('.98'))==(n==threshold)
                    ratios.append({'mode':mode,'cell':cellid,'residue':residue,'n':n,'ratio_80_digits':str(high),'binary64_ratio':low,'passed':bool(high<M('.98'))})
    rng=random.Random(20260908)
    for _ in range(1000):
        end=rng.randrange(1,100);pairs=[sorted([rng.randrange(-5,end+10),rng.randrange(-5,end+10)]) for _ in range(rng.randrange(20))]
        expected=set(range(end+1))
        for lo,hi in pairs:expected-=set(range(max(0,lo),min(end,hi)+1))
        actual={j for lo,hi in d.complement(pairs,end) for j in range(lo,hi+1)}
        assert actual==expected
    for cell in source['cells']:
        a,b=d.ends(cell['tau_interval'])
        assert d.np.all(d.competition(a,b,'local')>=d.competition(a,b,'uniform')-1e-12)
        assert d.np.all(d.components(cell,d.np.array([31147]),'uniform')[0].sum(axis=-1)<.98)
    report={'status':'passed','scope':'High-precision diagnostic audit, NOT an interval proof',
       'precision':80,'radial_boundary_points':129,'max_R_difference':radial_error,'max_mu_difference':mu_error,
       'endpoint_tests':5,'max_endpoint_kmin_difference':endpoint_error,'ratio_comparisons':len(ratios),
       'exact_union_tests':1000,'v07_uniform_threshold_cells':128,'comparisons':ratios}
    (root/'audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='comparisons'},indent=2))
if __name__=='__main__':run()
