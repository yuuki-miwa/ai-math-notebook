"""Ordinary floating-point coverage exploration, NOT an interval certificate.

Retains all tau cells and all uncovered intervals; no monotonicity in tau assumed.
The v0.7 proof and certificate files are read-only inputs.
"""
import argparse,csv,hashlib,json,math,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'.local-deps'))
import numpy as np
PAPER=ROOT/'reference' # Snapshot of the v0.7 inputs, for standalone reproduction.
Q=4139;K=718;K5=2717;ETA=11313/1250000;ETA5=113/40000
C=2*math.pi**2/15;BETA=.39;WMAX=.0013;NMAX=31146
LABELS=['b=1','2<=b<=100, non5','100<b<=1436, non5','1436<b<=Q, non5',
        '5<b<=300, five','300<b<=Q, five','b=5 cusp']

def ends(s):return json.loads(s)
def calL(x):return (1+x)*np.log1p(x)-x*np.log(x)
def kappa(z):
    with np.errstate(divide='ignore',invalid='ignore'):
        return np.where(z<2*np.pi,.5+z/(12*(1-z*z/(4*np.pi**2))),np.inf)

X,W=np.polynomial.legendre.leggauss(96);X=(X+1)/2;W=W/2
def radial(t):
    """R, -R', R'' by positive quadrature; diagnostic, not certified."""
    y=np.exp(-np.asarray(t)[...,None,None]*X[:,None]*np.arange(5))
    total=y.sum(axis=-1);p=y/total[...,None]
    mean=(p*np.arange(5)).sum(axis=-1)
    var=(p*(np.arange(5)-mean[...,None])**2).sum(axis=-1)
    return (np.log(total)*W).sum(axis=-1),(mean*X*W).sum(axis=-1),(var*X**2*W).sum(axis=-1)

def li(t):
    ls=np.arange(1,201,dtype=float);v=np.exp(-t)
    # Used only for t>=.5. Include a positive tail bound, though float arithmetic remains diagnostic.
    return np.sum(v**ls/ls**2)+v**201/(201**2*(1-v))

def endpoint_kmin(n):
    t=5*n*WMAX
    if t<5.5:return None
    r=(C+li(5*t)/5-li(t))/t
    f=np.log1p(-np.exp(-5*t))-np.log1p(-np.exp(-t))
    return 5*n*n*(r-f)/t

def grouped_gap(t):
    b=np.arange(1,401,dtype=float)/400;y=np.exp(-ETA5-t*b)
    S=sum(y**j for j in range(5));gap=0.
    for d in range(1,5):
        g=np.minimum((5-d)/25,sum(y**(2*j+d) for j in range(5-d))/S**2)
        assert np.all(np.diff(g)<=1e-14)
        a=np.minimum(2,1.2*d*b)
        gap+=np.sum((g-np.r_[g[1:],0])*b*(a*a/6-a**4/120))
    return float(gap)

def prepare_localization():
    L=np.log(2/ETA);L5=np.log(2/ETA5)
    tail=10*np.exp(-ETA*K)/(ETA*K);tail5=10*np.exp(-ETA5*K5)/(ETA5*K5)
    def sums(k,e):
        l=np.arange(1,k+1,dtype=float)
        return np.sum(np.exp(-e*l)/(l*np.ceil(l/2))),np.sum(np.exp(-e*l)/l**2)
    s0,s1=sums(K,ETA);s05,_=sums(K5,ETA5)
    def period(b,k,e,s):
        q=np.exp(-e*b)
        return s+2*(1+np.log(k))*q/(b*(1-q)),np.pi**2/(3*(1-q))
    corr=1/(Q*(1-K/Q))+5/(Q*(1-5*K/Q))
    t,u=period(101,K,ETA,s0)
    t1,u1=period(301,K5,ETA5,s05);t5,u5=period(61,K5,ETA5,s05)
    gamma=.5/(1-K/Q)+.5/(1-5*K/Q)
    costs=np.array([0,gamma*100*L,K*(2*t+corr*u),Q/2*(2*s1+corr*np.pi**2/6),
        .6/(1-K5/Q)*300*L5,Q/2*(t1+t5/5+(u1+u5/5)/(Q*(1-K5/Q))),
        .5/(1-K5/Q)*5*L5])
    return L,L5,tail,tail5,costs

L,L5,TAIL,TAIL5,COSTS=prepare_localization()
def competition(a,b,mode):
    if mode=='uniform':return np.array([.025,.1,.238-4*np.log(2)/101,.238-4*np.log(2)/(2*K+1),.119,.238-5*np.log(5)/301,.00992])
    R=float(radial(b)[0]);short=4*(1-np.pi/6)*np.log(2*np.sin(1))
    def small():return R-max(short,.8+4*np.pi*calL(ETA/2)),R-(.4+4*np.pi*calL(ETA))
    def large(a):
        B=li(a);base=B*B/(np.pi**2/6*a)
        return R-base-4*calL(ETA/a),R-base/2-2*calL(ETA/a)
    g1,g2=small()
    if a>0:
        # Both upper bounds hold for all tau>0, not only on their chosen
        # v0.7 subranges. The quadratic proof for M is in README.md.
        r1,r2=large(a);g1=max(g1,r1);g2=max(g2,r2)
    # Retain established global floors as well as the competing local bounds.
    return np.array([max(g1,.025),max(g2,.1),R-4*np.log(2)/101,R-4*np.log(2)/(2*K+1),R/2,R-5*np.log(5)/301,grouped_gap(b)])

def gaps(n,a,b,mode):
    n=np.asarray(n,dtype=float);t=5.5 if mode=='uniform' else b
    z=t*K/n+10*np.pi*K/Q;z5=t*K5/n+2*np.pi*K5/Q
    res=4*kappa(z)*L/n;res5=4*kappa(z5)*L5/n
    base=competition(a,b,mode)
    penalty=np.r_[np.repeat(2*ETA+TAIL,4),np.repeat(2*ETA5+TAIL5,3)]
    resonance=np.stack([res]*4+[res5]*3,axis=-1)
    return base-penalty-COSTS/n[...,None]-resonance

def safe_exp(x):return np.exp(np.clip(x,-745,700))

def components(cell,n,mode):
    a,b=ends(cell['tau_interval']);n=np.asarray(n,dtype=float)
    vlo,vhi=ends(cell['V_interval']);vhi=min(vhi,4/3)
    phases=np.array([ends(p)[0] for p in cell['signed_phase_intervals']])
    H=np.array([ends(r['Gaussian_coefficient_interval'])[1] for r in cell['grouped_residue_bounds']])
    E=np.array([ends(r['EM_first_coefficient_interval'])[1] for r in cell['grouped_residue_bounds']])
    Z=np.sqrt(b*b+.16);D=Z*(1/30+2*np.exp(-a)/(25*.75))
    U=4*1.54*(3400+D*D/2)/np.sqrt(2*BETA)*safe_exp(D/n+3400/n**2)
    main=(H+E)/n[...,None]+U[...,None]/n[...,None]**2
    all_gaps=gaps(n,a,b,'local' if mode=='oracle' else mode)
    delta=all_gaps.min(axis=-1)
    # Replace all three 1/n allocations by the actual exponential bounds.
    minor=5*np.sqrt(2*np.pi*vhi)*safe_exp(1.5*np.log(n)-n*delta)
    minor=np.where(delta>0,minor,np.inf)
    if mode=='oracle':minor=np.zeros_like(n) # Counterfactual: NOT a proof bound.
    middle=4*2.4*6*np.sqrt(vhi/(2*np.pi))*safe_exp(.5*np.log(n)+7200/n-.052*vlo*n)
    gaussian=8*safe_exp(-.08*vlo*n)
    parts=np.stack([np.broadcast_to(main,n.shape+(5,)),np.broadcast_to(minor[...,None],n.shape+(5,)),
                    np.broadcast_to(middle[...,None],n.shape+(5,)),np.broadcast_to(gaussian[...,None],n.shape+(5,))],axis=-1)
    return parts/phases[...,None],all_gaps

def thresholds(cells,mode):
    ns=np.arange(513,NMAX+2,dtype=float);rows=[]
    for cell in cells:
        parts,gg=components(cell,ns,mode);ratio=parts.sum(axis=-1);passed=ratio<.98
        # This validates monotone behavior only on the explicitly scanned integer n grid.
        assert np.all(np.diff(passed.astype(int),axis=0)>=0),('nonmonotone n',mode,cell['cell'])
        first=[];details=[]
        for a in range(5):
            ids=np.flatnonzero(passed[:,a]);idx=int(ids[0]) if len(ids) else None
            first.append(int(ns[idx]) if idx is not None else NMAX+2)
            details.append(None if idx is None else {'n':int(ns[idx]),'ratio':float(ratio[idx,a]),
                'components':dict(zip(['local_main','minor_arc','intermediate','gaussian_tail'],map(float,parts[idx,a]))),
                'limiting_localization_class':LABELS[int(np.argmin(gg[idx]))],
                'localization_gap':float(np.min(gg[idx]))})
        rows.append({'cell':cell['cell'],'tau':ends(cell['tau_interval']),'first_passing_n':first,'at_first_pass':details})
    assert max(max(r['first_passing_n']) for r in rows)<=31147
    return rows

def complement(intervals,end):
    intervals.sort();out=[];pos=0
    for lo,hi in intervals:
        lo=max(lo,0);hi=min(hi,end)
        if hi<lo:continue
        if pos<lo:out.append((pos,lo-1))
        pos=max(pos,hi+1)
    if pos<=end:out.append((pos,end))
    return out

def frontier(rows,mode,out):
    taus=np.linspace(0,5.5,129);rho=5*radial(taus)[1]
    cutoff=np.array([r['first_passing_n'] for r in rows])
    records=[];samples=[];maximum=(-1,None);unknown_total=0;holes=0
    sample_ns=set([513,600,800,846,847,1000,2000,3000,4000,5000,6000,8000,10000,12000,15000,20000,25000,30000,31146])
    for n in range(513,NMAX+1):
        half=5*n*n;kmin=endpoint_kmin(n);resmax=[];counts=[];pieces=[];all_intervals=[]
        for a in range(5):
            end=(half-a)//5
            def lattice(lo,hi):return math.ceil((lo-a)/5),math.floor((hi-a)/5)
            covered=[lattice(0,5*n if a<3 else 10*n-1)]
            if kmin is not None:
                shift=0 if a<3 else 5*n
                covered.append(lattice(kmin+shift,rho[-1]*n*n+shift))
            for j in np.flatnonzero(cutoff[:,a]<=n):covered.append(lattice(rho[j+1]*n*n,rho[j]*n*n))
            remaining=complement(covered,end)
            maxm=5*remaining[-1][1]+a if remaining else -1
            count=sum(hi-lo+1 for lo,hi in remaining)
            resmax.append(maxm);counts.append(count);pieces.append(len(remaining))
            if n in sample_ns:all_intervals.append([[5*lo+a,5*hi+a] for lo,hi in remaining])
        peak=max(resmax);unknown_total+=sum(counts);holes=max(holes,max(pieces))
        if peak>maximum[0]:maximum=(peak,n)
        records.append([n,peak,*resmax,sum(counts),max(pieces)])
        if n in sample_ns:samples.append({'n':n,'last_uncovered_degree':peak,'endpoint_kmin':kmin,'uncovered_by_residue_step5':all_intervals})
    # A prefix updater must retain the largest degree needed by any future row.
    suffix=np.maximum.accumulate(np.array([r[1] for r in records])[::-1])[::-1]
    with (out/f'frontier_{mode}.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['n','last_uncovered_degree','a0_last','a1_last','a2_last','a3_last','a4_last','uncovered_coefficients_lower_half','max_uncovered_components_per_residue','future_retention_degree'])
        for row,keep in zip(records,suffix):writer.writerow(row+[int(keep)])
    # Upper estimates for four array updates per n; includes building rows 1..512.
    update_slots=sum(4*(min(10*n*n,int(suffix[0] if n<=512 else suffix[n-513]))+1) for n in range(1,NMAX+1))
    full_slots=sum(4*(10*n*n+1) for n in range(1,NMAX+1))
    half_slots=sum(4*(min(10*n*n,5*NMAX*NMAX)+1) for n in range(1,NMAX+1))
    result={'mode':mode,'scope':'Unrounded diagnostic coverage, not certified and not new exact coefficient verification',
      'maximum_uncovered_degree':maximum[0],'n_at_maximum':maximum[1],
      'remaining_lower_half_coefficients':unknown_total,'max_uncovered_components_per_residue':holes,
      'array_update_slot_upper_estimate':update_slots,'full_polynomial_update_slot_upper_estimate':full_slots,
      'slot_reduction_factor':full_slots/update_slots,
      'previous_half_retention_slot_estimate':half_slots,'slot_reduction_vs_half_retention':half_slots/update_slots,
      'samples':samples}
    (out/f'summary_{mode}.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result

def run():
    start=time.perf_counter();out=ROOT/'results';out.mkdir(exist_ok=True)
    source=PAPER/'results/profile_certificate.json';profile=json.loads(source.read_text(encoding='utf-8'))
    assert profile['status']=='passed' and profile['theorem_threshold']==31147
    summaries=[]
    for mode in ['uniform','local','oracle']:
        rows=thresholds(profile['cells'],mode)
        (out/f'bulk_thresholds_{mode}.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
        result=frontier(rows,mode,out);summaries.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!='samples'}),flush=True)
    meta={'status':'diagnostic_completed','arithmetic':'IEEE binary64, NOT outward rounded',
      'numpy':np.__version__,'python':sys.version.split()[0],'seconds':time.perf_counter()-start,
      'source_profile_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'fixed_parameters':{'Q':Q,'K':K,'K5':K5,'eta':ETA,'eta5':ETA5,'wmax':WMAX},
      'tau_cells':128,'integer_n_scanned':[513,31147],'frontier_n_range':[513,31146],
      'exact_finite_verified_through':512,'analytic_working_threshold_unchanged':31147}
    (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print('Completed in',meta['seconds'],'seconds',flush=True)

if __name__=='__main__':run()
