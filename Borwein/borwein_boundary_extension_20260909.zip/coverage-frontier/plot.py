"""Scientific figures from saved diagnostics; does not issue certificates."""
import csv,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.plot-deps'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.mplconfig')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import numpy as np
import diagnose as d

OUT=ROOT/'results'
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(10,5.2),layout='constrained')
styles=[('uniform','Uniform localization reused','#8795a1'),('local','Tau-local bounds','#176b91'),('oracle','Minor-arc error set to zero (hypothetical)','#a45695')]
for mode,label,color in styles:
    with (OUT/f'frontier_{mode}.csv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f))
    n=np.array([int(r['n']) for r in rows]);m=np.array([int(r['last_uncovered_degree']) for r in rows])
    ax.plot(n,m,label=label,color=color,lw=1.7)
ax.axhline(311463,color='#333333',ls='--',lw=1,label='Proposed prefix: about 311,000')
ax.set(xlabel='Product index n',ylabel='Largest degree m left uncovered',yscale='log',xlim=(513,31146),ylim=(1e5,1e10),title='Coverage frontier — diagnostic, not certified')
ax.grid(True,which='major',alpha=.2)
ax.legend(loc='upper left',fontsize=9)
ax.annotate('430.6 million at n = 10,350',xy=(10350,430644099),xytext=(13000,3e9),arrowprops={'arrowstyle':'-','color':'#176b91'},color='#176b91',fontsize=10)
for ext in ['png','svg']:fig.savefig(OUT/f'frontier.{ext}',dpi=160)
plt.close(fig)

rows=json.loads((OUT/'bulk_thresholds_local.json').read_text())
cutoff=np.array([r['first_passing_n'] for r in rows]);tau=np.array([rows[0]['tau'][0]]+[r['tau'][1] for r in rows]);rho=5*d.radial(tau)[1]
ns=np.linspace(513,31146,320).round().astype(int);fractions=np.linspace(0,1,600)
mask=np.zeros((len(fractions),len(ns)),dtype=int)
for col,n in enumerate(ns):
    m=fractions*5*n*n;lower=d.endpoint_kmin(int(n));unknown=np.zeros(len(m),dtype=bool)
    for a in range(5):
        covered=m<=(5*n if a<3 else 10*n-1)
        if lower is not None:
            shift=0 if a<3 else 5*n
            covered|=(m>=lower+shift)&(m<=rho[-1]*n*n+shift)
        for j in np.flatnonzero(cutoff[:,a]<=n):covered|=(m>=rho[j+1]*n*n)&(m<=rho[j]*n*n)
        unknown|=~covered
    mask[:,col]=unknown
fig,ax=plt.subplots(figsize=(10,5.2),layout='constrained')
ax.imshow(mask,origin='lower',aspect='auto',extent=[ns[0],ns[-1],0,1],interpolation='nearest',cmap=ListedColormap(['#d7eee5','#d98341']),vmin=0,vmax=1)
ax.set(xlabel='Product index n',ylabel='Coefficient position m / (5 n²)',title='Uncovered regions — tau-local diagnostic (any residue)')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color='#d98341',label='At least one residue unresolved'),Patch(color='#d7eee5',label='Covered by formulas / candidate analytic bounds')],loc='upper right',fontsize=9)
ax.text(.01,.015,'Display grid only; thin gaps remain recorded in the CSV.',transform=ax.transAxes,fontsize=9,bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
for ext in ['png','svg']:fig.savefig(OUT/f'coverage_map.{ext}',dpi=160)
plt.close(fig)
print('Wrote frontier and coverage_map figures (PNG and SVG).')
