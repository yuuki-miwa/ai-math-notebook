"""Write the Japanese result note from the saved diagnostics."""
import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'
def read(name):return json.loads((OUT/name).read_text(encoding='utf-8'))
def main():
    uniform=read('summary_uniform.json');local=read('summary_local.json');oracle=read('summary_oracle.json')
    bulk=read('bulk_thresholds_local.json');obulk=read('bulk_thresholds_oracle.json');audit=read('audit.json')
    assert audit['status']=='passed'
    with (OUT/'frontier_local.csv').open(encoding='utf-8') as f:data={int(r['n']):r for r in csv.DictReader(f)}
    choices=[1000,5000,10000,10350,15000,25000,31025,31146]
    rows='\n'.join(f"| {n:,} | {int(data[n]['last_uncovered_degree']):,} | {int(data[n]['uncovered_coefficients_lower_half']):,} | {data[n]['max_uncovered_components_per_residue']} |" for n in choices)
    floor=max(max(r['first_passing_n']) for r in bulk);ofloor=max(max(r['first_passing_n']) for r in obulk)
    text=f'''# 被覆境界の診断結果

**ハイブリッド化は有効ですが、現行の評価を位置別に使い直すだけでは、先頭約31万次の検査には収まりませんでした。**
今回の条件で残る次数の最大は **{local['maximum_uncovered_degree']:,}**、n={local['n_at_maximum']:,} 付近です。
これは「その程度の計算が必ず必要」という下界ではなく、今回の評価で覆えなかった上端です。

## どれだけ減ったか

| 診断条件 | 未処理次数の最大 | その n |
|---|---:|---:|
| §8 の一様化を保持 | {uniform['maximum_uncovered_degree']:,} | {uniform['n_at_maximum']:,} |
| tau ごとに §8 を再評価 | **{local['maximum_uncovered_degree']:,}** | {local['n_at_maximum']:,} |
| 副円弧誤差だけを強制的に0にする仮想比較 | {oracle['maximum_uncovered_degree']:,} | {oracle['n_at_maximum']:,} |

下半分の未処理係数は local で延べ **{local['remaining_lower_half_coefficients']:,} 個**です。
必要次数を未来の行まで考慮して保持した場合、4回の配列更新で扱う係数枠の上側見積りは
**{local['array_update_slot_upper_estimate']:,}**。全係数保持の見積り比で約{local['slot_reduction_factor']:.1f}分の1、
前回の「最終行の半分まで保持」の方式を基準にすると約{local['slot_reduction_vs_half_retention']:.1f}分の1です。
これは更新枠数の比較であり、実行時間が同じ倍率で短くなるという実測結果ではありません。
大整数の桁数やメモリ費用も含みません。

## 最大の障害はどこか

全体の必要次数を最大にしたのは、**tau=0.30078125..0.34375 の内部区間**です。
そこで効いているのは **2<=b<=100 の非5倍数分母の一括評価**でした。
弱い剰余類3,4の通過候補は n=10351 からで、その一つ前 n=10350 の高い次数に大きな未処理帯が残ります。
この区間では、副円弧の誤差が位相に対して約0.83〜0.87、主円弧の局所誤差は約0.075です。

従って、次の対象は「分母5だけ」ではありません。
特に、小さい非5倍数分母で **b=2 などを想定した粗い主項上界と、b=100 を想定した非共鳴誤差を同時に使う損失** が残っています。
分母ごとの評価へ分ける案は、今回の目的に直接対応します。
ただし、この改善を実装・認証したわけではありません。

tau=5.45703125..5.5 の区間では、逆に **1436<b<=4139 の非5倍数分母** が支配し、
弱い剰余類が通過する候補は n=31025 からでした。
場所によって支配する分類が変わることが、二次元で調べた利点です。

## 「31万次で済む」はどの範囲なら見えるか

現在の local 診断では、n>={floor:,} で全128内部区間・全剰余類が通過候補になります。
そのため、**n={floor:,}..31146 の範囲については、先頭約31万次だけが残る形が見えています。**
問題はそれより小さい n の内部、および端点と内部の間の未処理帯です。

| n | 最後に未処理となる次数 | 下半分の未処理係数数 | 剰余類ごとの未処理区間数の最大 |
|---:|---:|---:|---:|
{rows}

例えば n=31146 では、今回の診断上で残るのは m=155731,155732,311463 の3箇所だけです。
これらの係数を今回新たに計算・証明したわけではありません。

## §8だけで閉じるか

副円弧誤差を非現実的に0にした仮想比較でも、現行の主円弧・中間円弧の評価を保つと
最大 **{oracle['maximum_uncovered_degree']:,} 次**が残りました。
全内部区間が通過する候補は n={ofloor:,} からです。
最後の弱い剰余類の境界では、位相に対する局所誤差が約0.63、中間円弧が約0.35となります。

つまり、**n=31147で主円弧に余裕があることは、より小さい n の接続問題でも主円弧を改善不要という意味ではありません。**
まず分母別評価を改善する価値はありますが、その後には中間円弧・主円弧と端点の接続を再設計する課題も残ります。
仮想比較の数字は、手法全体の限界でも、数学的な計算量下界でもありません。

## 信頼性と成果物

二次元領域は128個の tau 区間と全整数 n を使って調べ、未処理区間の和集合・補集合を計算しました。
図だけは表示用に間引いています。図で見えない細い未処理帯も、CSVの個数と上端、JSONの代表行には残っています。
80桁で129点の R と -R'、5点の端点下限、60個の通過境界を再計算し、
区間結合も1000個の整数例で照合しました。結果は `results/audit.json` にあります。

**今回の新しい被覆は未認証の診断です。解析の作業定理 n>=31147、厳密な有限検査 n<=512 は更新していません。**
採用前には区間演算による認証と解析上の接続確認が必要です。
現在の成果は、次の改善対象と、まだ計算すべき領域を具体化したことです。

コード・入力スナップショット・CSV・JSON・図・再実行手順を同梱しました。
AI使用は README に明記しています。著者名は記載せず、GitHubへ公開していません。
'''
    (ROOT/'RESULTS.md').write_text(text,encoding='utf-8')
    print('Wrote RESULTS.md (UTF-8)')
if __name__=='__main__':main()
