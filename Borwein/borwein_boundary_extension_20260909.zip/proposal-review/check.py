"""Exact cyclotomic algebra and a small numerical check of the received proposal."""
from fractions import Fraction as F
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'.local-deps'))
import numpy as np

def check():
    c=[F(2*r-5,10) for r in range(1,5)]
    # Multiply -sum c_r*y^r = y/(1-y)+1/2 by (1-y), then reduce by Phi_5.
    p=[F(0)]*6
    for r,cr in enumerate(c,1):p[r]-=cr;p[r+1]+=cr
    p[0]-=F(1,2);p[1]-=F(1,2)
    for degree in range(5,3,-1):
        coefficient=p[degree]
        for k in range(5):p[degree-4+k]-=coefficient
    assert all(x==0 for x in p)
    assert sum(c)==0
    phases=[]
    for ell in range(1,5):
        # arg(1-zeta^s)/pi = s/5 - 1/2, for 1<=s<=4.
        phase=-sum(cr*F(2*((ell*r)%5)-5,10) for r,cr in enumerate(c,1))
        phases.append(phase)
    assert phases==[F(-1,5),F(0),F(0),F(1,5)]
    n=30628;b=4139;Q=4139;tau=5.5
    j=np.arange(1,5*n+1);j=j[j%5!=0];u=np.exp(-tau*j/(5*n))
    samples=[]
    for delta in [-1,0,1]:
        theta=2*np.pi*(1/b+delta/(b*Q))
        value=np.sum(.5*np.log((1-u)**2+4*u*np.sin(j*theta/2)**2))/n
        samples.append({'dirichlet_offset_units':delta,'log_abs_product_over_n':float(value)})
    result={'exact_checks':'passed','cyclotomic_remainder':[str(x) for x in p],
      'constant_arguments_in_units_of_pi':[str(x) for x in phases],
      'sample_parameters':{'n':n,'b':b,'a':1,'Q':Q,'tau':tau},'product_samples':samples,
      'scope':'Exact identities plus three binary64 product samples; no uniform kernel bound or threshold claim.'}
    (ROOT/'checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':check()
