"""Bundle the three existing packages, preserving each verified manifest."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
contents={}
for folder,manifest in [('round4-6','MANIFEST.sha256.json'),('finite-compute','MANIFEST.json'),('coverage-frontier','MANIFEST.json')]:
    base=WORK/folder;record=json.loads((base/manifest).read_text(encoding='utf-8'))
    for row in record['files']:
        raw=(base/row['path']).read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],(folder,row['path'])
        contents[folder+'/'+row['path']]=raw
    contents[folder+'/'+manifest]=(base/manifest).read_bytes()
for path in ROOT.iterdir():
    if path.is_file():contents['proposal-review/'+path.name]=path.read_bytes()
contents['START_HERE.md']=('''# Borwein 研究・確認用統合パッケージ

最初に [今回の確認・訂正記録](proposal-review/README.md) を読んでください。

- [解析の作業稿](round4-6/README.md)：v0.7、n>=31147。§8のetaの誤記を訂正。
- [厳密な有限検査](finite-compute/README.md)：n<=512。コード・実行結果を同梱。
- [二次元の被覆診断](coverage-frontier/README.md)：未認証の数値探索。証明済み領域の拡張ではありません。

追加案の分母個別化による202,920,944という値は今回未再現です。
既存のZIPを変更せず、欠けていた有限検算パッケージを含む形で一つにまとめました。
解析全体の独立監査、全nの予想の証明完了、新規性は主張しません。
AI使用は各記録に明記し、著者名は記載していません。
''').encode('utf-8')
manifest={'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(contents.items())]}
contents['BUNDLE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode('utf-8')
target=WORK/'borwein_review_bundle_20260908.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(contents.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(contents)},indent=2))
