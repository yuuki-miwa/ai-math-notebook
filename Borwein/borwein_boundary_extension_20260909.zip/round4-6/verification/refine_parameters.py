"""Refine a declared finite search grid; this is not a global optimality proof."""
import explore_parameters as s
import numpy as np,json
s.non=s.group(np.arange(.00900,.009052,.000002),np.arange(680,761))
s.five=s.group(np.arange(.0026,.00301,.00001),np.arange(2600,2901,5))
def test(N):
    best=(-float('inf'),None)
    for Q in range(4050,4251,2):
        a,pa=s.margin(N,Q,s.non,False);b,pb=s.margin(N,Q,s.five,True)
        if min(a,b)>best[0]:best=min(a,b),{'N':N,'Q':Q,'non5':pa,'five':pb,'margin_non5':a,'margin_five':b}
    return best
lo=30000;hi=31500
with np.errstate(all='ignore'):
    while hi-lo>1:
        mid=(hi+lo)//2
        if test(mid)[0]>0:hi=mid
        else:lo=mid
    positive=test(hi);negative=test(lo)
result={'scope':'Finite-grid ordinary arithmetic exploration, not a proof of global optimality.',
        'grid':{'Q':'4050:2:4250','eta_non5':'.00900:.000002:.00905','K_non5':'680:1:760',
                'eta_five':'.0026:.00001:.0030','K_five':'2600:5:2900'},
        'first_passing':positive[1],'last_failing':negative[1]}
(s.root/'results/parameter_refinement_diagnostics.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
