"""Ordinary floating-point parameter exploration; no proof claims."""
import json,math,sys
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1]
pi=math.pi
def calL(x):return (1+x)*np.log1p(x)-x*np.log(x)
def group(etas,ks):
    e,k=np.meshgrid(etas,ks,indexing='ij');e=e.ravel();k=k.ravel()
    ls=np.arange(1,8001,dtype=float)
    S0=np.array([np.sum(np.exp(-x*ls)/(ls*np.ceil(ls/2))) for x in etas])
    S1=np.array([np.sum(np.exp(-x*ls)/ls**2) for x in etas])
    return e,k,np.repeat(S0,len(ks)),np.repeat(S1,len(ks))
non=group(np.array([.0088,.009,.00902,.00904]),np.arange(550,951,10))
five=group(np.arange(.0018,.00401,.0001),np.arange(1500,3501,25))
def margin(N,Q,data,isfive):
    e,k,S0,S1=data;L=np.log(2/e);tail=10*np.exp(-e*k)/(e*k)
    z=5.5*k/N+(2 if isfive else 10)*pi*k/Q
    kap=.5+z/(12*(1-z*z/(4*pi*pi)))
    res=4*kap*L/N
    def T(B):
        q=np.exp(-e*B);return S0+2*(1+np.log(k))*q/(B*(1-q)),pi*pi/(3*(1-q))
    if isfive:
        gamma=.6/(1-k/Q);gc=.5/(1-k/Q)
        t1,u1=T(301);t5,u5=T(61)
        large=Q/(2*N)*(t1+t5/5+(u1+u5/5)/(Q*(1-k/Q)))
        m=np.minimum.reduce([.119-2*e-gamma*300*L/N-res-tail-.001,
             .238-5*math.log(5)/301-2*e-large-res-tail-.001,
             .0099-2*e-gc*5*L/N-res-tail-.001])
        valid=(k<Q)&(z<2*pi)
    else:
        gamma=.5/(1-k/Q)+.5/(1-5*k/Q)
        correction=1/(Q*(1-k/Q))+5/(Q*(1-5*k/Q))
        t,u=T(101)
        mid=k/N*(2*t+correction*u)
        large=Q/(2*N)*(2*S1+correction*pi*pi/6)
        m=np.minimum.reduce([.025-2*e-res-tail-.001,
             .1-2*e-gamma*100*L/N-res-tail-.001,
             .238-4*math.log(2)/101-2*e-mid-res-tail-.001,
             .238-4*math.log(2)/(2*k+1)-2*e-large-res-tail-.001,
             1.189-.8-4*pi*calL(e/2)-.025,
             1.189-.4-4*pi*calL(e)-.1])
        valid=(5*k<Q)&(z<2*pi)
    m=np.where(valid,m,-np.inf)
    j=int(np.argmax(m));return float(m[j]),{'eta':float(e[j]),'K':int(k[j]),'kappa':float(kap[j])}
results=[]
with np.errstate(all='ignore'):
    for N in range(29000,40001,250):
        best=(-float('inf'),None)
        for Q in range(3400,5501,25):
            a,pa=margin(N,Q,non,False);b,pb=margin(N,Q,five,True)
            if min(a,b)>best[0]:best=(min(a,b),{'N':N,'Q':Q,'non5':pa,'five':pb,'margin_non5':a,'margin_five':b})
        results.append(best[1])
        if best[0]>0:
            print(json.dumps(best[1],indent=2));break
out=root/'results/parameter_search_diagnostics.json';out.write_text(json.dumps({'scope':'Floating-point exploration, not certification.','grid_results':results},indent=2)+'\n',encoding='utf-8')
