"""Portable SHA-256 manifest of the publication package. Run after editing."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def build():
    files=[]
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.pyc':
            continue
        if path==ROOT/'MANIFEST.sha256.json':
            continue
        # Reproduction output belongs outside the package; do not add local environments.
        if any(part in {'.venv','.local-deps'} for part in path.relative_to(ROOT).parts):
            continue
        content=path.read_bytes()
        files.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(content),
                      'sha256':hashlib.sha256(content).hexdigest()})
    data={'algorithm':'SHA-256','scope':'All package files except this manifest and bytecode.',
          'files':files}
    (ROOT/'MANIFEST.sha256.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'manifest: {len(files)} files')


if __name__=='__main__':
    build()
