# v0.7 の探索記録

浮動小数点による候補探索と、最終値の区間検証を区別する。

1. 分母別のeta・Kと共通Qを同時探索し、31250を候補とした。
2. より細かい有限格子で31176を候補とした。この時点の共鳴ギャップ採用値は0.0099。
3. 証明書の丸めを0.00992へ詰め、固定したw上限0.0013の端点条件が許す31147を試した。
4. 最終パラメータで全区間証明書と整数・多倍長検算を再生成した。

最終値は[parameters.py](verification/parameters.py)、合否は[summary.json](results/summary.json)に記録する。
各段階の探索の失敗を、別のパラメータも含めた不可能性の証明には使わない。
最適性を証明した対象は、固定したw上限での端点比較だけである。
その正確な範囲は[端点条件の証明書](results/threshold_boundary_certificate.json)に記録する。

初期二段階の探索を再現する任意の補助コマンド：

~~~bash
python verification/explore_parameters.py
python verification/refine_parameters.py
~~~

これらは候補を出す通常のNumPy計算であり、証明用の一括スイートには含めない。
results内のparameter_search_diagnostics.jsonとparameter_refinement_diagnostics.jsonを生成する。
最終値31147の検証にはREADMEのrun_all.pyを使用する。

今回の変更と停止点の整理にOpenAI Codexを使用した。著者名は記載しない。
