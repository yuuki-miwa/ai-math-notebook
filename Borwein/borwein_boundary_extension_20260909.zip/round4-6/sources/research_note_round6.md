# 有限 Borwein 積の一般論 VI
## 固定内部区間の有効化と、全係数を覆う明示閾値

2026-09-07／証明を記載した研究作業稿。独立監査・新規性確認は未了。

## 0. 結論・依存関係・まだ解いていない部分

対象は

\[
B_n(q)=\prod_{\substack{1\le j\le5n\\5\nmid j}}(1-q^j)
      =\sum_{m=0}^{10n^2}c_n(m)q^m.
\]

このラウンドでは、前稿 V に残した固定パラメータ区間 \(0\le\tau\le8\) の係数誤差を有効化する。

**今回の内部定理。** 以下で定義する正の前因子 \(P_{\rm bulk}(n,m)\) と主位相 \(\Phi_a\) に対し、整数 \(n\ge10^{16}\)、\(0\le\tau\le8\)、

\[
-R'(\tau)=\frac{m}{5n^2},\qquad a\equiv m\pmod5
\]

なら

\[
\boxed{
\left|\frac{c_n(m)}{P_{\rm bulk}(n,m)}-\Phi_a(e^{-\tau})\right|
\le\frac{1000}{\sqrt n}\le10^{-5}<\frac{e^{-8}}4.
}\tag{0.1}
\]

**前稿 V の端定理との系。** 前稿 V の定理 2.1 と第8節の端への適用を用いると、すべての整数 \(n\ge10^{16}\) とすべての係数位置について

\[
\boxed{c_n(m)\ge0\quad(5\mid m),\qquad c_n(m)\le0\quad(5\nmid m).}\tag{0.2}
\]

今回は前稿 V の29個の数値不等式も再実行した。ただし再実行は、端定理の解析的証明全体を独立に機械検証したという意味ではない。全域の系は、その端定理と本稿の内部証明の**両方**に依存する。

**第三 Borwein 予想の全 n 版を証明したわけではない。** 前稿に記録された全係数の有限検査は \(1\le n\le256\)。この稿によっても

\[
257\le n<10^{16}
\]

の全体を処理したことにはならない。\(10^{16}\) は一京であり、単純な全展開・全走査へ渡せる現実的な閾値ではない。本稿の進展は「閾値の存在」から「明示された閾値」への前進であって、「残りは小さな計算」という前進ではない。

また、ここでの Fourier 平滑化・有理近似・鞍点評価は古典的な手法を組み合わせて本族に適用したもの。以下の有効な部分結果が文献上新しいという認定は行っていない。

## 1. 基本関数と内部の主項

\[
h(z)=\frac{\operatorname{Li}_2(e^{-z})-\pi^2/6}{z},\quad
R(z)=h(5z)-h(z),\quad
M(\tau)=\sup_{t\in\mathbb R}\Re h(\tau-it).
\]

\(R\) は0で解析的に延長され、

\[
R(0)=\log5,\quad R'(0)=-1,\quad R''(0)=2/3.
\]

実 \(\tau\ge0\) で

\[
R(\tau)=\int_0^1\log\!\left(\sum_{j=0}^4e^{-j\tau x}\right)dx.
\]

\(V=R''(\tau)>0\) とし、

\[
P_{\rm bulk}(n,m)=
\frac{\exp\{nR(\tau)+m\tau/(5n)\}}
 {5\sqrt{2\pi V}\,n^{3/2}}.\tag{1.1}
\]

\(\zeta=e^{2\pi i/5}\) と置き、原始根の振幅を

\[
\lambda_\ell(z)=\sum_{j=1}^4
\left(\frac j5-\frac12\right)
\left[\log(1-\zeta^{\ell j}e^{-z})-\log(1-\zeta^{\ell j})\right],
\quad A_\ell(z)=e^{\lambda_\ell(z)}.\tag{1.2}
\]

対数は各原始根の近傍で0から連続する枝を使う。実 \(\tau\) で \(|A_\ell(\tau)|=1\)。

\[
\Phi_a(e^{-\tau})=\sum_{\ell=1}^4\zeta^{-a\ell}A_\ell(\tau).\tag{1.3}
\]

### 1.1. 位相の符号と余裕

\(x=e^{-\tau}\)、\(v=(1-x)/(1+x)\) とし、

\[
\alpha=\arctan(v\cot(\pi/5)),\quad
\beta=\arctan(v\cot(2\pi/5)),\quad
U=(\alpha+2\beta)/5,\quad V_0=(2\alpha-\beta)/5.
\]

共役な根を組にして余弦の加法定理を使うと

\[
\Phi_a(x)=4\cos(3\pi a/5+U)\cos(-\pi a/5+V_0).
\]

\(U,V_0\) は \(v\in[0,1]\) で厳密に増加し、0から \(\pi/10\) へ動く。この角度範囲から、\(x>0\) で \(\Phi_0>0\)、\(\Phi_a<0\)（\(a\ne0\)）。さらに

\[
\boxed{\epsilon_a\Phi_a(x)\ge x/4,\qquad
\epsilon_0=1,\quad\epsilon_1=\cdots=\epsilon_4=-1.}\tag{1.4}
\]

弱い二つの剰余類では

\[
-\Phi_3=4\cos(\pi/5-U)\sin(\pi/10-V_0),
\quad
-\Phi_4=4\sin(\pi/10-U)\cos(\pi/5+V_0).
\]

\[
V_0'\ge\frac{\sin(2\pi/5)-\cot(2\pi/5)}5=:v_*,
\quad
U'\ge\frac{\sin(\pi/5)\cos(\pi/5)+2\sin(2\pi/5)\cos(2\pi/5)}5=:u_*.
\]

\(\sin y\ge2y/\pi\)、\(1-v\ge x\) より、その下界の係数はそれぞれ
\(8\cos(\pi/5)v_*/\pi>1/4\)、\(8\cos(3\pi/10)u_*/\pi>1/4\)。他の三剰余類は角度範囲から一定の正の下界を持つ。

## 2. q=1 型の寄与との、一様な指数差

以下を数値パラメータの証明に使う。

\[
\boxed{R(\tau)-4M(\tau)>0.009\qquad(0\le\tau\le8).}\tag{2.1}
\]

### 2.1. 小さい半径パラメータ

\(M\) は非負・非増加で、\(M(0)=\kappa<1/4\)。この性質を簡単に確認する。

\(\Re h\) は右半平面で調和であり、無限遠では0へ近づく。原点での特異点は負側に発散する。最大値原理によって \(M\) は非増加、また無限遠の極限から非負。

単位円側では

\[
L(t)=\Re h(-it)=\frac1t\int_0^t\log|2\sin(y/2)|dy.
\]

最初の周期の最大点 \(t_0\in(\pi,2\pi)\) は一意。実際、\(f(t)=\log(2\sin(t/2))\)、\(H(t)=tf(t)-\int_0^tf\) とすると \(H'(t)=t\cot(t/2)/2\)。後続周期の平均は最初の周期の値を0側へ縮めるので、最大値はここで得られる。1000項の Fourier 和と尾部 \(1/1000\) を使って \(H(4.9)>0\) を囲み、\(f(4.9)<1/4\) を確認すれば \(\kappa=f(t_0)<1/4\)。この二つの不等式も証明書に含めた。

AM–GM より \(R(\tau)\ge\log5-\tau\)。従って \(0\le\tau\le0.6\) では

\[
R-4M>\log5-0.6-1>0.009.
\]

### 2.2. 残りの固定区間

\(A_0=\pi^2/6\)、\(B=\operatorname{Li}_2(e^{-\tau})\) とすると

\[
M(\tau)\le\frac{B^2}{4A_0\tau},\qquad
R(\tau)\ge\frac{4A_0/5-B}{\tau}.
\]

第一式は \(|\operatorname{Li}_2(e^{-\tau+it})|\le B\) と
\(-A_0\tau/y^2+B/y\le B^2/(4A_0\tau)\) から従う。

\(\tau\ge0.6\) なら \(A_0>1.6\)、\(B<0.72\)。後者には
\(e^{-0.6}<0.55\)、\(\operatorname{Li}_2(x)\le x+x^2/(4(1-x))\) を使えばよい。よって

\[
R-4M>\frac{1.28-0.72-0.72^2/1.6}{\tau}
=\frac{0.236}{\tau}\ge\frac{0.236}{8}>0.009.
\]

また \(R\) の単調性と閉じた形から

\[
R(\tau)\ge R(8)>0.16\qquad(0\le\tau\le8).\tag{2.2}
\]

## 3. 有限積の副円弧を、実効的に一様評価する

ここが前稿までの部分列・コンパクト性の議論を、有効な評価に置き換える箇所である。

固定する数値は

\[
\eta=\frac1{50000},\quad K=10^7,\quad
Q=\lfloor384\sqrt n\rfloor,\quad T=\frac65.
\]

主円弧を

\[
\operatorname{dist}(\theta,2\pi\ell/5)\le\frac{T}{5n},
\qquad\ell=1,2,3,4
\]

とする。距離は円周上の距離。

### 定理 3.1：明示的な副円弧評価

\(n\ge10^{16}\)、\(0\le\tau\le8\)、\(r=e^{-\tau/(5n)}\) とする。上の四つの主円弧の外では

\[
\boxed{|B_n(re^{i\theta})|\le
 \exp\{n(R(\tau)-4\cdot10^{-6})\}.}\tag{3.1}
\]

### 3.1. 対数の特異点を平滑化する

\(0\le u\le1\) について

\[
|1-ue^{iv}|\le e^{\eta/2}|1-ue^{-\eta+iv}|.
\]

両辺の平方の差を取ると、必要な非負性は
\((e^\eta-1)+u^2(e^{-\eta}-1)\ge0\) から従う。4n個の因子を合わせ、

\[
\frac1n\log|B_n(re^{i\theta})|
\le 2\eta-rac1n\Re\sum_{l\ge1}\frac{e^{-\eta l}}l
\left(\sum_{j=1}^{5n}e^{-l\tau j/(5n)+ilj\theta}
      -\sum_{j=1}^{n}e^{-l\tau j/n+i5lj\theta}\right).\tag{3.2}
\]

これは \(\tau=0\) でも使える上界。積が0なら対数を \(-\infty\) と解釈すればよい。

### 3.2. 有理近似と Riemann 和の誤差

Dirichlet の有理近似を使い、既約な \(a/b\) で

\[
1\le b\le Q,\qquad
\left|\frac\theta{2\pi}-\frac ab\right|\le\frac1{bQ}
\]

を選ぶ。\(t=5n(\theta-2\pi a/b)\) とする。

\(l\le K\) では \(Q\ge10K\) なので、\(b\nmid dl\)（\(d=1,5\)）なら

\[
\left\|\frac{dl\theta}{2\pi}\right\|\ge\frac1{2b}.
\]

等比級数と単調な重みへの Abel 変換により、対応する有限和の絶対値は \(b\) 以下。正規化した二つの和の非共鳴誤差は合わせて \(2b/n\) 以下。

\(b\mid dl\) の和は、\(I_l=\int_0^1e^{-l(\tau-it)x}dx\) に対応する Riemann 和になる。二つを合わせた正規化誤差は、安全に

\[
\frac{2l(\tau+|t|)}n
\]

で抑えられる。\(|t|\le10\pi n/Q\) なので、Fourier 係数を掛けて合計した誤差は

\[
\mathcal R_n\le
\frac{2Q}{n}\log\frac2\eta
+\frac1\eta\left(\frac{16}n+\frac{20\pi}{Q}\right)
+\frac{10e^{-\eta K}}{\eta K}.
\]

従って

\[
\boxed{\mathcal R_n\le
\frac{18000}{\sqrt n}+\frac{800000}{n}+10^{-80}.}\tag{3.3}
\]

実際に必要な \(n^{-1/2}\) の係数は

\[
768\log(2/\eta)+\frac{20\pi}{383\eta}
=17044.51854\ldots<18000.
\]

**\(10^7\) 個の周波数を計算したわけではない。** 和は幾何級数等で上から評価している。K は解析的な打切り点である。

### 3.3. 共鳴した連続主項

(3.2) の有限和を共鳴した積分で置き換え、無限和へ戻すと、主項は次のいずれかになる。

\(5\nmid b\) の場合：

\[
\mathcal H_b=rac4b\int_0^1
\log|1-e^{-b\eta-b(\tau-it)x}|dx.\tag{3.4}
\]

\(b=5j\) の場合：

\[
\mathcal H_b=rac1j\int_0^1
\log\left|\sum_{r=0}^4e^{-rj(\eta+(\tau-it)x)}\right|dx.\tag{3.5}
\]

したがって \(n^{-1}\log|B_n|\le2\eta+\mathcal H_b+\mathcal R_n\)。以下で全分母を処理する。

### 3.4. 5と互いに素な分母

\(\mathcal L(y)=(1+y)\log(1+y)-y\log y\) とする。

\(\delta>0\)、\(s\ge0\) では

\[
\log|1-e^{-s-\delta+iv}|-\log|1-e^{-s+iv}|
\le\log\left(1+\frac\delta{2|\sin(v/2)|}\right).
\]

右辺を一周期で平均すると、\(\sin(v/2)\ge\operatorname{dist}(v,2\pi\mathbb Z)/\pi\) より、その上界は \(\mathcal L(\delta/2)\)。長さ \(|bt|\ge1\) の区間の平均は8倍で抑えられる。

\(\mathcal L(y)/y\) は減少するから、\((3.4)\) は

\[
\mathcal H_b\le\frac4b M(b\tau)
+\frac{32}b\mathcal L(b\eta/2)
\le4M(\tau)+32\mathcal L(\eta/2).\tag{3.6}
\]

\(|bt|<1\) の場合は、積分内の位相が1以下なので各対数が0以下となり、同じ上界が成り立つ。

(2.1) と

\[
0.009-32\mathcal L(\eta/2)-2\eta-\mathcal R_{10^{16}}>4\cdot10^{-6}
\]

でこの場合は終了する。

### 3.5. 5の真の倍数の分母

\(b=5j\)、\(j\ge2\) なら三角不等式、幾何級数の単調性、Rの単調性により

\[
\mathcal H_b\le R(j\tau)/j\le R(\tau)/2.
\]

(2.2) より指数差は少なくとも0.08あり、誤差を差し引いても十分である。

### 3.6. 分母が5の場合

残る \(b=5\) は主円弧に対応する。ただし今はその外側なので \(|t|\ge6/5\)。

\(y=e^{-\eta-\tau x}\)、\(p_j=y^j/\sum_{r=0}^4y^r\) と置く。\(0\le x\le1/2\) では

\[
\frac1{p_0p_1}=y^{-1}+2+3y+4y^2+5y^3+4y^4+3y^5+2y^6+y^7
\le e^{4+\eta}+24<80.
\]

特性関数の恒等式から

\[
\log\left|\sum p_je^{ijt x}\right|
\le-p_0p_1(1-\cos tx).
\]

また全実数vについて

\[
1-\frac{\sin v}v\ge\frac1{10}\min(v^2,1).
\]

小さいvではTaylorの不等式、\(1\le|v|\le\pi\) ではsincの単調性、\(|v|\ge\pi\) では \(\sin v/v\le1/\pi\) を使えばよい。

したがって

\[
R(\tau)-\mathcal H_5
\ge\frac1{1600}\min(t^2/4,1)
\ge\frac{0.36}{1600}=0.000225.\tag{3.7}
\]

\(n=10^{16}\) で、平滑化と有限和の誤差を引いた残りは

\[
0.000225-2\eta-\left(18000/10^8+800000/10^{16}+10^{-80}\right)
>0.00000499991>4\cdot10^{-6}.
\]

誤差上界は以後減少するので、これで定理3.1が従う。□

## 4. 原始根の主円弧での積の有効展開

\[
\mathcal B=\{z:0\le\Re z\le8,\ |\Im z|\le6/5\}
\]

を考える。\(0\le x\le1\) と非自明な5乗根ξに対して

\[
|1-\xi e^{-zx}|>0.05\quad(z\in\mathcal B).
\]

実際、最小の角距離は \(2\pi/5-6/5>0\) で、その正弦は0.05を上回る。\(|\Im z|\le1/10\) の小さい箱では同様に下界0.9が使える。

### 4.1. シフト付き Riemann 和の一段補正

\(0\le\alpha\le1\)、\(f\in C^2[0,1]\) なら

\[
\left|\sum_{r=0}^{n-1}f((r+\alpha)/n)-n\int_0^1f
-(\alpha-1/2)(f(1)-f(0))\right|
\le\frac{\sup|f''|}{n}.\tag{4.1}
\]

各小区間の左端で一次Taylor展開すると、区間積分との差の二次剰余の和は \(2\sup|f''|/(3n)\) 以下。一次導関数の左Riemann和と積分との差から高々 \(\sup|f''|/(4n)\) を加えても、この上界に収まる。複素値関数にも絶対値で同じ証明が通る。

\(f_j(x)=\log(1-\zeta^{\ell j}e^{-zx})\) に適用する。\(|z|<9\) なので、小さい箱で \(|f_j''|\le81/0.9^2=100\)、大きい箱で \(|f_j''|\le81/0.05^2=32400\)。従って

\[
B_n(\zeta^\ell e^{-z/(5n)})
=e^{nR(z)}A_\ell(z)e^{E_{\ell,n}(z)},\tag{4.2}
\]

\[
|E_{\ell,n}(z)|\le
\begin{cases}500/n,&|\Im z|\le1/10,\\150000/n,&|\Im z|\le6/5.\end{cases}\tag{4.3}
\]

### 4.2. 振幅の定数

(1.2)より、小さい箱では \(|\lambda_\ell'|\le0.8/0.9\)。実軸上で \(|A_\ell|=1\) だから

\[
|A_\ell(\tau-it)|<1.1,\qquad
|A_\ell(\tau-it)-A_\ell(\tau)|\le|t|\quad(|t|\le1/10).\tag{4.4}
\]

大きい箱でも

\[
|A_\ell(z)|\le e^{(6/5)(0.8/0.05)}=e^{19.2}<3\cdot10^8.\tag{4.5}
\]

この大きな定数は、主項の近似には使わず、中間円弧の指数減衰に掛けるだけである。

## 5. Gaussian 誤差を、分散で正規化して抑える

粗い一様な三階微分上界をそのまま使うと、R''の小さい場所で定数が不必要に大きくなる。ここでは有限確率分布の分散・累積量で比較する。

### 5.1. 二階・三階微分

実 \(\tau\) で、xごとに \(\Pr(J=j)\propto e^{-j\tau x}\)、\(j=0,\ldots,4\) とする。

\[
V=R''(\tau)=\int_0^1x^2\operatorname{Var}(J)dx,
\qquad
\boxed{1/1920\le V\le4/3.}\tag{5.1}
\]

下界は \(x\le1/2\) で \(p_0p_1>1/80\)、\(\operatorname{Var}(J)\ge p_0p_1\) を使う。上界は \(\operatorname{Var}(J)\le4\)。

\(Y=J-\mathbb EJ\)、\(v_x=\mathbb EY^2\) とする。\(|Y|\le4\)、\(|\omega|\le0.1\) で

\[
|\mathbb Ee^{i\omega Y}|\ge\cos0.4>0.92,
\quad |\mathbb EY e^{i\omega Y}|\le|\omega|v_x,
\quad |\mathbb EY^2e^{i\omega Y}|\le v_x,
\quad |\mathbb EY^3e^{i\omega Y}|\le4v_x.
\]

対数の三階微分の式から、その三次累積量の絶対値は

\[
v_x\left(\frac4{0.92}+\frac{1.2}{0.92^2}+\frac{0.032}{0.92^3}\right)<6v_x.
\]

よって

\[
\boxed{|R'''(\tau-it)|\le6V\qquad(|t|\le0.1).}\tag{5.2}
\]

### 5.2. 実部の減衰

\(|t|\le0.1\) なら \(|(j-k)tx|\le0.4\)。特性関数の恒等式と
\(1-\cos y\ge(1/2-0.4^2/24)y^2>0.49y^2\) から

\[
\boxed{\Re R(\tau-it)-R(\tau)\le-0.49Vt^2.}\tag{5.3}
\]

\(0.1\le|t|\le1.2\) でも、\(x\le1/2\) の対 \(j=0,1\) だけ使えば

\[
\Re R(\tau-it)-R(\tau)\le-t^2/4000\le-1/400000.\tag{5.4}
\]

### 5.3. 積分の誤差

\[
J_0=\sqrt{2\pi/(nV)},\qquad
\mathcal F_n(t)=n\{R(\tau-it)-R(\tau)+iR'(\tau)t\}.
\]

鞍点条件で一次項は消え、(5.2)より

\[
|\mathcal F_n(t)+nVt^2/2|\le nV|t|^3.
\]

(5.3)を使って二つの指数を直線補間し、積分すると

\[
\frac1{J_0}\int_{-0.1}^{0.1}
|e^{\mathcal F_n(t)}-e^{-nVt^2/2}|dt
\le\frac1{0.49^2\sqrt{2\pi nV}}.\tag{5.5}
\]

振幅の変化(4.4)の誤差は

\[
\frac1{0.49\sqrt{2\pi nV}}.\tag{5.6}
\]

4個の根を合わせ、(5.1)を使うと (5.5)–(5.6) の和は \(450/\sqrt n\) 未満。

(4.3) の積の剰余について、\(n\ge10^{16}\) では \(|e^{E_{\ell,n}}-1|\le501/n\)。絶対値を取った積分とJ0の比は \(1/\sqrt{0.98}\)。従って4根合計で \(2240/n\) 以下。

残る三種類の積分誤差は、正の前因子(1.1)で割った後、次で抑えられる。

* 副円弧：\(15n^{3/2}e^{-4\cdot10^{-6}n}\)。
* 主円弧内の \(0.1\le|t|\le1.2\)：\(10^{10}\sqrt n\,e^{-n/400000}\)。
* 完全Gaussianに延長した尾部：\(8e^{-n/384000}\)。

それぞれ \(n\ge10^{16}\) で \(1/n\) 未満。対数を取って閾値で確認し、その後の差の導関数が正であることを使う。これらの数値不等式も証明書に含める。

したがって

\[
\boxed{
\left|c_n(m)/P_{\rm bulk}(n,m)-\Phi_a(e^{-\tau})\right|
\le450/\sqrt n+2243/n<1000/\sqrt n.
}\tag{5.7}
\]

Cauchy積分の変数変換は \(\theta=2\pi\ell/5+t/(5n)\)。各根の \(J_0/(2\pi\cdot5n)\) が、正確に(1.1)の前因子を与える。\(\zeta^{-a\ell}\) を含む4根の合成が(1.3)になる。\(\tau=0\) も連続延長で含まれる。□

## 6. 全係数への接続

前稿 V と同じ

\[
\rho=-5R'(8)=0.1025724696443808629180409635\ldots
\]

を用いる。

前稿 V の端定理は、\(n\ge60000\) で \(0\le m\le\rho n^2\) の所望符号を示す。これは弱剰余類に対する正確な第一尾部恒等式と、位置を5nずらした端点鞍点評価を接続した結果である。

残る左半分

\[
\rho n^2\le m\le5n^2
\]

では、未シフトの鞍点方程式 \(-R'(\tau)=m/(5n^2)\) の解が \(0\le\tau\le8\) にある。本稿の(5.7)と(1.4)によって、\(n\ge10^{16}\) では全て**厳密に**所望符号を持つ。

右半分は \(c_n(m)=c_n(10n^2-m)\) で処理する。これで(0.2)が得られる。

### 零係数の系

前稿 V の厳密恒等式から、\(n\ge2\) で

\[
\mathcal Z_n^-=
\{5j+3,5j+4:0\le j<n\}\cup\{7,5n+8,5n+9\}
\]

は実際の零係数の位置である。端定理の厳密符号と本稿の内部厳密符号を合わせると、\(n\ge10^{16}\) では全零集合は

\[
\mathcal Z_n^-\cup(10n^2-\mathcal Z_n^-),
\qquad\#\mathcal Z_n=4n+6.
\]

この数値閾値も全 n の分類ではない。

## 7. 今回の検証と、検証の限界

### 7.1. 数値不等式の証明書

`certify_round6.py` は、今回必要な45個の実数不等式を mpmath.iv、60桁、外向き丸めで検査した。内容は、平滑化と有理近似の誤差予算、角度全体の評価に用いるスカラー定数、原始根の分母下界、分散・三次累積量の比較、積分誤差の集計、位相余裕との比較である。

**角度のサンプルが通ったことを、全角度の証明として使っていない。** 全角度の被覆は第3節の有理近似と場合分けで行い、証明書はその数値比較を検査する。

また、前稿 V の `certify_constants.py` を再実行し、29個の数値不等式の検査が通った。これら74個のスカラー検査が、解析的推論全体や新規性まで自動検証したという意味ではない。

### 7.2. 独立の診断計算

`check_local_and_finite.py` は次を行った。

* n=8,32、τ=0,0.5,2,8、ずれ角パラメータ t=0,0.1,1.2、根 ℓ=1,2 の計48ケースで、直接有限積の対数と(4.2)の差が(4.3)に収まることを通常の50桁計算で確認。
* n=1,…,64 の全係数を任意精度整数で再計算。延べ894,464係数。符号違反なし、左右対称性・剰余類和・零集合が一致。選んだnでは二つの素数法の独立積評価とも一致。

この有限検査は前稿の1,…,256を拡張したものではなく、再確認用。\(10^{16}\) の多項式を計算したことにも、その未満を網羅したことにもならない。

## 8. 監査すべき箇所と次の数学的課題

今回新たに重点監査すべきなのは次の論理接続である。

1. 平滑化の上界の向き、4n因子による \(2\eta n\)、有理分母別の係数 \(4/b\) と \(1/j\)、Riemann和の規格化。
2. \(\mathcal L(y)/y\) の単調性を用いた、分母bに一様な平滑化誤差。特に \(b\eta\) を小さいと仮定していない点。
3. 分母5で使う特性関数の損失の下界と、主円弧の外にいる条件 \(|t|\ge6/5\) の対応。
4. 同じ枝での積のEuler–Maclaurin展開、三次累積量の分散による比較、Cauchy積分の前因子。
5. 前稿 V の端定理自体。その結果は本稿の全域の系に依存として残る。

数学的に残っているのは、\(257\le n<10^{16}\) を覆うことである。ただし現実的な方針は、この全範囲の素朴な計算ではない。

大きな閾値の主要因は、第3節の汎用的な有理近似を通すことで、正規化対数の誤差に \(18000/\sqrt n\) が出る点。一方、局所積分の誤差は \(450/\sqrt n+2243/n\) まで小さい。さらに進めるなら、原始5乗根以外の円弧を有限積に特化して直接評価するか、より小さいnを一括して覆う代数的・組合せ的補題を作る必要がある。

この稿では、その閾値低減や未検査区間の一括処理を証明してはいない。

## 9. 再現と参考文献

```bash
python certify_round6.py
python check_local_and_finite.py
python previous/borwein_round5/certify_constants.py
```

必要環境：Python、NumPy、mpmath。`round6_scalar_certificate.json` は区間検査、`local_and_finite_checks.json` は整数検査と通常の多倍長診断計算を区別して記録する。

前稿の本文と再現コードは `previous/borwein_round5/` に保存する。前稿は本対話で作った未査読の研究作業稿であり、外部で確立された結果として引用しない。

古典的な道具・関連する原論文：

* NIST DLMF §17.2：Rogers–Ramanujan 恒等式等。https://dlmf.nist.gov/17.2
* NIST DLMF §23.18：Dedekind eta の変換則。https://dlmf.nist.gov/23.18
* Liuquan Wang, *Sign Changes of Coefficients of Powers of the Infinite Borwein Product*, arXiv:2108.03932v3, Proposition 3.6 の5分解。https://arxiv.org/html/2108.03932v3
* Chen Wang and Christian Krattenthaler, *An asymptotic approach to Borwein-type sign pattern theorems*, arXiv:2201.12415。第一・第二の全係数定理、cubicの部分結果、第三の位相相殺の説明。https://arxiv.org/abs/2201.12415

本稿の証明案は、第三 Borwein 予想が既知に解決済みだと仮定せずに組み立てた。一方で、本稿の部分結果の網羅的な新規性調査はしていない。
