"""Interval evaluation of rearrangement bounds for nonresonant frequencies.

For a coprime residue progression within one period, each nonzero distance
occurs at most twice. Rearrangement against decreasing Fourier weights then
gives the sums below, uniformly in the numerator of the rational approximation.
"""
import argparse
from common import metadata,write_result
from parameters import ETA_NUMERATOR,ETA_DENOMINATOR,FOURIER_K
from mpmath import iv

def certify(output_dir=None):
    iv.dps=60
    I=iv.mpf
    eta=I(ETA_NUMERATOR)/ETA_DENOMINATOR
    sums={}
    for name,shift in [('one_tenth',I(1)/10),('one_half',I(1)/2)]:
        sums[name]=sum((iv.exp(-eta*l)/(I(l)*(I((l+1)//2)-shift))
                       for l in range(1,FOURIER_K+1)),I(0))
    data={**metadata('uniform residue rearrangement interval certificate'),'status':'passed',
          'decimal_precision':60,'frequencies':FOURIER_K,'eta':f'{ETA_NUMERATOR}/{ETA_DENOMINATOR}',
          'S_one_tenth_interval':str(sums['one_tenth']),
          'S_one_half_interval':str(sums['one_half']),
          'scope':'Finite interval sums; uniformity in coprime numerators follows from multiplicity and rearrangement in manuscript.'}
    write_result('residue_sum_certificate.json',data,output_dir)
    return sums

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output-dir')
    certify(parser.parse_args().output_dir)
