"""Directed interval checks of scalar budgets, not a formal proof of the manuscript.

All input decimals are exact strings. Each check requires a STRICTLY positive
lower interval endpoint. No floating-point sampling is used for certification.
"""
import argparse
from common import write_result, metadata
from mpmath import iv
from certify_resonant_gap import gap_bound
from certify_profiles import certify as certify_profiles
from certify_residue_sums import certify as certify_residue_sums
from parameters import (THRESHOLD, ETA_NUMERATOR, ETA_DENOMINATOR, FOURIER_K,
                        DIRICHLET_Q, SMALL_DENOMINATOR, BOUNDARY_NUMERATOR, BOUNDARY_DENOMINATOR)


def certify(output_dir=None):
    iv.dps = 60
    I = iv.mpf
    p = iv.pi
    boundary=I(BOUNDARY_NUMERATOR)/BOUNDARY_DENOMINATOR
    x = iv.exp(-boundary)
    w = I('0.001')
    v = I('0.005')
    A = 2*p*p/75
    C = 5*A
    eta = I(ETA_NUMERATOR)/ETA_DENOMINATOR
    N = I(THRESHOLD)
    K = FOURIER_K
    Q = DIRICHLET_Q
    assert Q==10*K
    log_budget = iv.log(2/eta)
    fourier_tail = 10*iv.exp(-eta*K)/(eta*K)
    records = []

    def positive(key, section, expression, value):
        ok = bool(value.a > 0)
        records.append({'id': key, 'section': section, 'positive_expression': expression,
                        'interval': str(value), 'passed': ok})

    def lt(key, section, description, left, right):
        positive(key, section, description + ' (right - left)', right-left)

    # Endpoint periodic-product estimate and eta/tail expansions.
    lt('E01','5.1','0.2 < far-cusp lower bound', I('0.2'),
       (4-10*v)/5*(1-1/iv.sqrt(1+16*iv.exp(-5*v)/(p*p))))
    lt('E02','5.1','sqrt(5)-1 < 1.25',iv.sqrt(5)-1,I('1.25'))
    length = 5*iv.sqrt(5)*v
    lt('E03','5.1','coth remainder < 0.505', I('0.5')+length/(12*(1-length**2/(4*p*p))),I('0.505'))
    lt('E04','5.1','6.15+2.02+4.02 < 13', I('6.15')+I('2.02')+I('4.02'),I(13))
    lt('E05','5.1','0.2 < 0.288 - 13v',I('0.2'),I('0.288')-13*v)
    lt('E06','5.1','0.2 < 0.55 - 13v',I('0.2'),I('0.55')-13*v)
    lt('E07','5.2','1 < eta transformed exponent',I(1),(4*p*p/25)*I(16)/25)
    z = iv.exp(-1/w)
    lt('E08','5.2','two transformed log-product bounds < 3 exp(-1/w)',2/(1-z)**2,I(3))
    lt('E09','5.2','eta relative remainder < 10 exp(-1/w)',3*iv.exp(3*z),I(10))
    lt('E10','5.2','root-filter product bound < 2',iv.exp(2*w)*(4*I('1.001')+I('0.001'))/5,I(2))
    lt('E11','5.3','root derivative bound for Re(t)<=1',1/(2*(1-iv.cos(2*p/5-I('0.75')))),I(4))
    lt('E12','5.3','root derivative bound for Re(t)>=1',1/(iv.exp(1)+iv.exp(-1)-2),I(4))
    lt('E13','5.3','4+5/12 < 5',4+I(5)/12,I(5))
    L = x/(1-x)
    lt('E14','5.3','weak-mode quadratic remainder < 8x^2',
       4*(1/(2*(1-x))+iv.exp(L)/(2*(1-x)**2)),I(8))
    lt('E15','5.3','four tail exponential errors < 25 |w| x',
       20*iv.exp(L+5*I('0.00125')*x/(1-x))/(1-x),I(25))
    lt('E16','5.4','tail log budget <= x/w',(4*w+I(4)/5)/(1-x),I(1))
    lt('E17','5.4','minor-arc exponent gap > 1/30',I(1)/30,I('0.04')-x-x/(5*(1-x)))
    lt('E18','5.4','minor-arc prefactor < 16',6*iv.sqrt(2*p*I('0.67'))*iv.exp(w/6),I(16))
    lt('E19','5.4','eta exponent gap > 0.9',I('0.9'),1-x-x/(5*(1-x)))
    lt('E20','5.4','q=1 exponent gap > 0.9',I('0.9'),A+C/(1+I('0.75')**2)-x-x/(5*(1-x)))
    # Normalized eta and q=1 errors can each be absorbed into one exponential budget.
    positive('E21','5.4','(0.9-1/30)/w - log(100) + log(w)/2',
             (I('0.9')-I(1)/30)/w-iv.log(100)+iv.log(w)/2)
    B2 = I(8)/5*(1+boundary+boundary**2/2)*x/(1-x)
    B3 = I(24)/5*((1+boundary+boundary**2/2)*x/(1-x)+boundary**3/6*x/(1-x)**2)
    lt('E22','5.5','B2 < 0.142', B2,I('0.142'))
    lt('E23','5.5','0.38 < 2A-B2',I('0.38'),2*A-B2)
    lt('E24','5.5','2A+B2 < 0.67',2*A+B2,I('0.67'))
    lt('E25','5.5','6A+B3 < 2.56',6*A+B3,I('2.56'))
    lt('E26','5.5','A/(1+(3/4)^2)-B2/2 > 0.097',I('0.097'),A/(1+I('0.75')**2)-B2/2)
    lt('E27','5.5','Gaussian L1 coefficient < 14.9',
       I('2.56')/6*iv.sqrt(I('0.67')/(2*p))/I('0.097')**2,I('14.9'))
    lt('E28','5.5','absolute integral / Gaussian < 1.86',iv.sqrt(I('0.67')/I('0.194')),I('1.86'))
    lt('E29','5.5','amplitude x coefficient < 15',8*I('1.86'),I(15))
    lt('E30','5.5','amplitude w coefficient < 60',32*I('1.86'),I(60))
    lt('E31','5.5','endpoint Gaussian tail < 0.1 sqrt(w)',
       2*iv.exp(-I('0.106875')/w),I('0.1')*iv.sqrt(w))
    lt('E32','5.5','combined endpoint error < 0.60',
       15*iv.sqrt(w)+15*x+60*w+50*w**(-3)*iv.exp(-1/(30*w)),I('0.60'))
    positive('E33','5.5','1/30 - 3w',I(1)/30-3*w)
    lt('E34','6','endpoint cutoff < 60000',C/(25*I('0.000001')),I(60000))
    lt('E35','5.3','strong mode linear error / min sigma < 8x',
       4*iv.exp(L)/(1-x)/((5-iv.sqrt(5))/2),I(8))
    lt('E36','5.2','primitive eta factor < 1.001',1+10*iv.exp(-1/w),I('1.001'))
    lt('E37','5.2','q=1 root-filter term < 0.001 of primitive exponential',
       iv.sqrt(5)*(1+10*iv.exp(-1/w))*iv.exp(-(C+A)/w),I('0.001'))

    # Bulk phase and competition bounds.
    u0 = (iv.sin(p/5)*iv.cos(p/5)+2*iv.sin(2*p/5)*iv.cos(2*p/5))/5
    v0 = (iv.sin(2*p/5)-iv.cos(2*p/5)/iv.sin(2*p/5))/5
    lt('B01','7','weak phase a=3 margin > x/4',I(1)/4,8*iv.cos(p/5)*v0/p)
    lt('B02','7','weak phase a=4 margin > x/4',I(1)/4,8*iv.cos(3*p/10)*u0/p)
    for key,expr in [('B03',4*iv.cos(p/10)**2),
                     ('B04',4*(-iv.cos(3*p/5))*iv.cos(p/5)),
                     ('B05',4*(-iv.cos(13*p/10))*iv.cos(2*p/5))]:
        lt(key,'7','strong-mode constant lower bound > 1/4',I(1)/4,expr)
    t = I('4.97')
    H = t*iv.log(2*iv.sin(t/2))+sum((iv.sin(k*t)/(k*k) for k in range(1,1001)),I(0))
    positive('B06','8.1','H(4.97) lower bound',H-I(1)/1000)
    lt('B07','8.1','f(4.97) < 1/5',iv.log(2*iv.sin(t/2)),I(1)/5)
    def calL(y): return (1+y)*iv.log(1+y)-y*iv.log(y)
    lt('B08','8.1','smoothed competition gap > 0.03 for tau<=0.45',I('0.03'),
       iv.log(5)-I('0.45')-I('0.8')-8*p*calL(eta/2))
    lt('B09','8.1','exp(-0.6) < 0.55',iv.exp(I('-0.6')),I('0.55'))
    lt('B10','8.1','dilog upper bound at 0.55 < 0.72',I('0.55')+I('0.55')**2/(4*(1-I('0.55'))),I('0.72'))
    lt('B11','8.1','pi^2/6 > 1.6',I('1.6'),p*p/6)
    lt('B12','8.1','0.236/8 > 0.009',I('0.009'),I('0.236')/8)
    # R(8) >= (C - Li_2(exp(-8)))/8, with a positive tail bound.
    li_upper = x+x*x/(4*(1-x))
    lt('B13','8.1','R(11/2) > 0.238',I('0.238'),(C-li_upper)/boundary)
    lt('B14','8.2','geometric argument |l z/M| < 3.2',boundary*K/N+10*p*K/Q,I('3.2'))
    lt('B15','8.2','geometric kernel remainder < 1',
       I('0.5')+I('3.2')/(12*(1-I('3.2')**2/(4*p*p))),I(1))
    lt('B16','8.2','Fourier tail < 0.00059',fourier_tail,I('0.00059'))
    remainder = (2*SMALL_DENOMINATOR+4)*log_budget/N+fourier_tail
    resonant_remainder = I(22)/3*log_budget/N+fourier_tail
    residue_sums=certify_residue_sums(output_dir)
    large_non5_remainder = I(Q)/(2*N)*(residue_sums['one_tenth']+residue_sums['one_half'])+4*log_budget/N+fourier_tail
    large_five_remainder = I(3)*Q/(5*N)*residue_sums['one_tenth']+4*log_budget/N+fourier_tail
    lt('B17','8.3','small non-5 denominator gap > 0.0002',I('0.0002'),I('0.03')-2*eta-remainder)
    lt('B18','8.3','small proper multiple-of-5 gap > 0.0002',I('0.0002'),I('0.119')-2*eta-remainder)
    lt('B19','8.3','inverse p0p1 < 80',iv.exp(4+eta)+24,I(80))
    lt('B20','8.3','sinc Taylor gap at 1 > 1/10',I(1)/10,I(1)/6-I(1)/120)
    lt('B21','8.3','sinc far gap > 1/10',I(1)/10,1-1/p)
    lt('B22','8.3a','denominator 5 residual gap > 0.0002',I('0.0002'),I('0.008')-2*eta-resonant_remainder)
    resonant_gap=gap_bound(output_dir)
    lt('B44','8.3a','all-pairs uniform resonant gap > 0.008',I('0.008'),resonant_gap)
    lt('B45','8.3a','global sinc bound: 1-1/pi > 8/15',I(8)/15,1-1/p)
    lt('B23','9.1','large-box denominator > 0.05',I('0.05'),iv.sin(2*p/5-I('1.2')))
    lt('B24','9.1','small-box denominator > 0.85',I('0.85'),iv.sin(2*p/5-I('0.2')))
    lt('B25','9.1','four EM errors < 500/n',4*81/I('0.9')**2,I(500))
    lt('B26','9.1','large-box integral EM error < 7200/n',
       (boundary**2+I('1.44'))/(2*I('0.05')**2),I(7200))
    lt('B27','9.1','small-box amplitude < 1.21',iv.exp(I('0.2')*I('0.8')/I('0.85')),I('1.21'))
    lt('B28','9.1','small-box |z| < 5.6',iv.sqrt(boundary**2+I('0.04')),I('5.6'))
    lt('B29','9.1','large-box amplitude < 6',I(80)**(I(2)/5),I(6))
    lt('B30','9.2','cos(0.8) > 0.69',I('0.69'),iv.cos(I('0.8')))
    lt('B31','9.2','complex third cumulant coefficient < 12',
       4/I('0.69')+I('2.4')/I('0.69')**2+I('0.256')/I('0.69')**3,I(12))
    lt('B32','9.2','small-angle cosine coefficient > 0.47',I('0.47'),I('0.5')-I('0.8')**2/24)
    lt('B33','9.2','intermediate-angle decay coefficient > 1/4000',I(1)/4000,(I('0.5')-I('0.6')**2/24)/(80*24))
    beta=I('0.49')
    integrated_coefficient = 4*1920/iv.sqrt(2*beta)*(I(33)/(16*beta**2)
                               +I(15)/(16*beta**3)+1/(2*beta))
    lt('B34','9.3','odd cancellation: four-root integrated error < 140000/n',
       integrated_coefficient,I(140000))
    lt('B35','9.1','EM second-order remainder coefficient < 2400',8*I('5.6')**3/I('0.85')**3,I(2400))
    lt('B36','9.1','absolute first EM coefficient < 1',I('5.6')*(I(1)/30+I(2)/(25*I('0.85'))),I(1))
    lt('B37','9.3','bulk minor-arc prefactor < 15',5*iv.sqrt(2*p*I(4)/3),I(15))
    lt('B38','9.3','bulk intermediate-arc prefactor < 30',
       4*I('2.4')*6*iv.exp(7200/N)*iv.sqrt((I(4)/3)/(2*p)),I(30))
    for key,decay,power,prefactor in [('B39',I('0.0002'),I('2.5'),I(15)),
                                     ('B40',I(3)/20000,I('1.5'),I(30)),
                                     ('B41',I(1)/4000,I(1),I(8))]:
        positive(key,'9.3','decay*N - power*log(N) - log(prefactor)',decay*N-power*iv.log(N)-iv.log(prefactor))
        positive(key+'m','9.3','decay - power/N',decay-power/N)
    # B42 was the obsolete v0.2 relaxation to 1000/sqrt(n); it is retired.
    profiles=certify_profiles(output_dir)
    lt('B43','10','uniform weighted error/phase ratio < 0.98',profiles['max_ratio'],I('0.98'))
    lt('B46','9.1','sum absolute Bernoulli B2 weights / 2 < 0.081',I(2)/25,I('0.081'))
    lt('B47','9.2','complex fourth cumulant coefficient < 104',
       16/I('0.69')+I('24.8')/I('0.69')**2+I('7.68')/I('0.69')**3
       +I('0.6144')/I('0.69')**4,I(104))
    lt('B48','8.3','b>=K, non-5 denominator residual gap > 0.0002',I('0.0002'),
       I('0.238')-4*iv.log(2)/K-2*eta-large_non5_remainder)
    lt('B49','8.3','b>=5K, multiple-of-5 residual gap > 0.0002',I('0.0002'),
       I('0.238')-iv.log(5)/K-2*eta-large_five_remainder)
    lt('B50','10','endpoint theorem threshold < new theorem threshold',I(60000),N)
    def dilog_exp_upper(a):
        y=iv.exp(-I(a))
        return sum((y**k/k**2 for k in range(1,101)),I(0))+y**101/(101**2*(1-y))
    for key,(a,b) in enumerate([('0.45','0.6'),('0.6','1'),('1','2'),('2','4'),('4','5.5')],51):
        B=dilog_exp_upper(a)
        lt('B'+str(key),'8.1',f'smoothed q=1 competition gap > 0.03 on [{a},{b}]',I('0.03'),
           (C-B-B*B/(p*p/6))/I(b)-4*calL(eta/I(a)))
    lt('B56','9.2','cosine loss coefficient for |t|<=0.6 > 0.30',I('0.30'),
       (iv.sin(I('1.2'))/I('1.2'))**2/2)
    lt('B57','9.2','cosine loss coefficient for |t|<=1.2 > 0.039',I('0.039'),
       (iv.sin(I('2.4'))/I('2.4'))**2/2)
    lt('B58','9.2','outer intermediate loss > 0.012 V',I('0.012'),I('0.039')*I('0.6')**2)
    lt('B60','8.3','500<b<K non-5 residual gap > 0.0002',I('0.0002'),
       I('0.238')-4*iv.log(2)/(SMALL_DENOMINATOR+1)-2*eta
       -(I(14)*K/9+4)*log_budget/N-fourier_tail)
    lt('B61','8.3','500<b<5K multiple-of-5 residual gap > 0.0002',I('0.0002'),
       I('0.238')-5*iv.log(5)/(SMALL_DENOMINATOR+1)-2*eta
       -(I(10)*K/3+4)*log_budget/N-fourier_tail)
    data = {**metadata('outward-rounded scalar interval certificate'), 'decimal_precision':60,
            'theorem_threshold':THRESHOLD,
            'localization_parameters':{'eta':f'{ETA_NUMERATOR}/{ETA_DENOMINATOR}',
                                       'K':K,'Q':Q,'small_denominator_cutoff':SMALL_DENOMINATOR},
            'check_count':len(records), 'status':'passed' if all(r['passed'] for r in records) else 'FAILED',
            'scope':'Scalar comparisons only; analytic reductions are in manuscript.md.', 'checks':records}
    write_result('scalar_certificate.json',data,output_dir)
    for r in records:
        if not r['passed']: print('FAILED',r['id'],r['positive_expression'],r['interval'])
    if data['status'] != 'passed': raise RuntimeError('Scalar certification failed')
    return data


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir')
    certify(parser.parse_args().output_dir)
