"""Uniform denominator-5 gap via analytic monotone lower envelopes.

The 400 subintervals partition x in [0,1], NOT the angle t. The sinc
inequality in manuscript section 8.3a handles every real |t| >= 6/5.
"""
import argparse
from common import metadata, write_result
from mpmath import iv
from parameters import ETA_NUMERATOR, ETA_DENOMINATOR, BOUNDARY_NUMERATOR, BOUNDARY_DENOMINATOR


def gap_bound(output_dir=None):
    iv.dps=60
    I=iv.mpf
    eta=I(ETA_NUMERATOR)/ETA_DENOMINATOR
    T=I(6)/5
    boundary=I(BOUNDARY_NUMERATOR)/BOUNDARY_DENOMINATOR
    cells=400
    profiles={}
    branches={'uniform':0,'endpoint':0}
    for s in range(1,8):
        profile=[]
        for i in range(1,cells+1):
            z=eta+boundary*I(i)/cells
            y=iv.exp(-z)
            value=y**s/sum((y**r for r in range(5)),I(0))**2
            uniform=I(1)/25
            # Certify which exact endpoint gives min(1/25,f_s(z)).
            if value.a > uniform.b:
                profile.append(uniform)
                branches['uniform']+=1
            elif value.b < uniform.a:
                profile.append(value)
                branches['endpoint']+=1
            else:
                raise RuntimeError(f'Undecided interval min at s={s}, i={i}')
        profile.append(I(0))
        profiles[s]=profile
    total=I(0)
    pairs=[]
    for j in range(5):
        for k in range(j+1,5):
            profile=profiles[j+k]
            contribution=I(0)
            for i in range(1,cells+1):
                b=I(i)/cells
                # Compare rational arguments using integers, not floating point.
                a=T*(k-j)*b if 6*(k-j)*i<=10*cells else I(2)
                primitive_lower=b*(a*a/6-a**4/120)
                contribution+=(profile[i-1]-profile[i])*primitive_lower
            pairs.append({'j':j,'k':k,'lower_bound_expression_interval':str(contribution)})
            total+=contribution
    positive_margin=total-I('0.008')
    if not bool(positive_margin.a>0):
        raise RuntimeError('Uniform resonant gap did not exceed 0.008')
    report={**metadata('uniform resonant-gap interval certificate'),'status':'passed',
            'decimal_precision':60,'subintervals':cells,'eta':f'{ETA_NUMERATOR}/{ETA_DENOMINATOR}','T':'6/5',
            'tau_range':f'[0,{BOUNDARY_NUMERATOR}/{BOUNDARY_DENOMINATOR}]','angle_range':'all real |t| >= 6/5',
            'analytic_basis':'monotone endpoint envelope and global sinc bound; manuscript 8.3a',
            'branches_certified':branches,'pair_contributions':pairs,
            'gap_interval':str(total),'certified_gap':'0.008',
            'strict_margin_interval':str(positive_margin),
            'scope':'Finite interval evaluation of an analytically uniform bound; no angle sampling.'}
    write_result('resonant_gap_certificate.json',report,output_dir)
    return total


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir')
    gap_bound(parser.parse_args().output_dir)
