"""Run the full reconstructed suite and save an execution log and summary."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from common import ROOT, metadata, write_result
from parameters import THRESHOLD


def run(max_n=256, large=True, output_dir=None):
    output=Path(output_dir).resolve() if output_dir else ROOT/'results'
    output.mkdir(parents=True,exist_ok=True)
    scripts=Path(__file__).resolve().parent
    commands=[
        ['certify_scalars.py'],
        ['diagnose_threshold.py'],
        ['diagnose_grouped.py'],
        ['verify_exact.py','--max-n',str(max_n),'--degree','350'],
        ['diagnose_analytic.py']+(['--large'] if large else []),
    ]
    failed=[]
    with (output/'execution.log').open('w',encoding='utf-8') as log:
        log.write('Reconstructed verification suite, 2026-09-08\n')
        for command in commands:
            heading='python '+' '.join(command)+' --output-dir <results>\n'
            print(heading.strip(),flush=True)
            log.write(heading);log.flush()
            proc=subprocess.Popen([sys.executable,str(scripts/command[0]),*command[1:],
                                   '--output-dir',str(output)],
                                  stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                  text=True,encoding='utf-8',errors='replace')
            for line in proc.stdout:
                print(line,end='',flush=True);log.write(line);log.flush()
            rc=proc.wait()
            log.write(f'exit_code={rc}\n')
            if rc:failed.append(command[0])
    if failed:
        write_result('summary.json',{**metadata('suite summary'),'status':'FAILED',
                                     'failed_scripts':failed},output)
        raise RuntimeError('Verification failed: '+', '.join(failed))
    scalar=json.loads((output/'scalar_certificate.json').read_text(encoding='utf-8'))
    exact=json.loads((output/'exact_certificate.json').read_text(encoding='utf-8'))
    diagnostic=json.loads((output/'analytic_diagnostics.json').read_text(encoding='utf-8'))
    threshold=json.loads((output/'threshold_diagnostics.json').read_text(encoding='utf-8'))
    profiles=json.loads((output/'profile_certificate.json').read_text(encoding='utf-8'))
    grouped=json.loads((output/'grouped_diagnostics.json').read_text(encoding='utf-8'))
    residue=json.loads((output/'residue_sum_certificate.json').read_text(encoding='utf-8'))
    if any(x['status']!='passed' for x in (scalar,exact,diagnostic,threshold,profiles,grouped,residue)):
        raise RuntimeError('Invalid result status')
    summary={**metadata('suite summary'),'status':'passed',
             'theorem_threshold':scalar['theorem_threshold'],
             'scalar_interval_checks':scalar['check_count'],
             'profile_parameter_cells':profiles['tau_cells'],
             'profile_interval_checks':profiles['inequality_count'],
             'finite_max_n':exact['max_n'],'exact_coefficients_checked':exact['coefficients_checked'],
             'RR_series_degree':exact['series_degree'],
             'bulk_diagnostic_cases':len(diagnostic['bulk_samples']),
             'eta_diagnostic_cases':len(diagnostic['eta_samples']),
             'large_endpoint_coefficients':len(diagnostic['large_endpoint_samples']),
             'geometric_diagnostic_cases':len(threshold['geometric_samples']),
             'weighted_local_remainder_diagnostic_cases':len(threshold['local_remainder_samples']),
             'weighted_scaled_integral_diagnostic_cases':len(threshold['scaled_integral_samples']),
             'integral_EM_diagnostic_cases':sum('v04_integral_EM_bound' in row for row in diagnostic['bulk_samples']),
             'B2_EM_diagnostic_cases':len(grouped['EM_samples']),
             'grouped_local_diagnostic_cases':len(grouped['grouped_samples']),
             'grouped_scaled_integral_diagnostic_cases':len(grouped['scaled_integral_samples']),
             'full_profile':max_n==256 and large,
             'limitations':['Not a formal verification of the analytic proof.',
                            f'No verification of 257 <= n < {THRESHOLD}.',
                            'No exhaustive novelty assessment.']}
    write_result('summary.json',summary,output)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--quick',action='store_true',help='n<=20, skip large endpoint samples')
    parser.add_argument('--output-dir',help='Use a new directory when comparing against saved results')
    args=parser.parse_args()
    run(20 if args.quick else 256,not args.quick,args.output_dir)
