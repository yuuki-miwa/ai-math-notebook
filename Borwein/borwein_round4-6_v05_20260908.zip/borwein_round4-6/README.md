# 第三 Borwein 予想：Round 4–6 統合証明稿と再検証

2026-09-08 / v0.5 / 未査読・新規性未確定

**[統合証明稿を読む](manuscript.md)**

零剰余類の先行除去、端点の明示的誤差評価、内部の誤差評価、全係数への接続を一本の稿にまとめた。作業定理は **n ≥ 300000（30万）** の全係数の符号であり、全 n の第三 Borwein 予想の解決を主張するものではない。

v0.5 では四根の先行合成、Euler–Maclaurin のB2補正、境界 tau=5.5、
非共鳴剰余の出現回数を使い、500万から30万へ約16.7分の1に下げた。
主円弧の誤差・位相の上界比は約0.00992。新しい導出は本文 §5・§8–10 に記載する。

本フォルダは単独でリポジトリに置ける。元の会話や作業フォルダを参照しなくても、本文と再構築した検証コードを読める構成にした。

## 内容

| ファイル | 内容 |
|---|---|
| [manuscript.md](manuscript.md) | 記号・証明・依存関係・適用範囲を統合した本文 |
| [AUDIT.md](AUDIT.md) | 元ノートからの変更、確認範囲、残る監査箇所 |
| [CHANGELOG.md](CHANGELOG.md) | v0.1–v0.5 の数学的更新 |
| [verification/](verification/) | 今回新規作成した Python 検証コード |
| [results/summary.json](results/summary.json) | 今回実行した検査の要約 |
| [results/scalar_certificate.json](results/scalar_certificate.json) | 99個のスカラー不等式の検査式・区間・合否 |
| [results/profile_certificate.json](results/profile_certificate.json) | 全128区間、1408比較による位置に応じた一様評価 |
| [results/resonant_gap_certificate.json](results/resonant_gap_certificate.json) | 全10組による一様ギャップの区間証明書 |
| [results/residue_sum_certificate.json](results/residue_sum_certificate.json) | 非共鳴剰余の出現回数による一様上界 |
| [results/grouped_diagnostics.json](results/grouped_diagnostics.json) | 四根合成・B2補正の有限多倍長診断 |
| [results/exact_certificate.json](results/exact_certificate.json) | n≤256 の整数係数検査と再計算用ハッシュ |
| [results/analytic_diagnostics.json](results/analytic_diagnostics.json) | 通常の多倍長計算による局所診断・大きい n の個別係数 |
| [results/threshold_diagnostics.json](results/threshold_diagnostics.json) | 等比級数、重みを保持した局所剰余、正規化積分の多倍長診断 |
| [results/execution.log](results/execution.log) | 一括実行の出力と終了コード |
| [sources/](sources/) | 変更せず保存した Round 4–6 の原ノート |
| [MANIFEST.sha256.json](MANIFEST.sha256.json) | 配布ファイルの SHA-256 |

## 再現方法

Python 3.10 以降を使用する。依存ライブラリは mpmath 1.3.0 と NumPy 2.x。
このフォルダで以下を実行する。

~~~bash
python -m venv .venv
~~~

仮想環境を有効化する。

~~~powershell
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
~~~

~~~bash
# macOS / Linux
source .venv/bin/activate
~~~

~~~bash
python -m pip install -r requirements.txt
python verification/run_all.py --output-dir ../borwein-reproduced
~~~

元の results を上書きせず、新しい出力と比較できる。出力先を省略すると results を再生成する。
Python の最適化オプション -O は使用しない。コード側でもこれを拒否する。

軽い動作確認だけなら次を実行する。これは完全プロファイルの再現にはならない。

~~~bash
python verification/run_all.py --quick --output-dir ../borwein-quick
~~~

個別の検査も実行できる。

~~~bash
python verification/certify_scalars.py
python verification/certify_profiles.py
python verification/certify_residue_sums.py
python verification/diagnose_grouped.py
python verification/diagnose_threshold.py
python verification/verify_exact.py --max-n 256
python verification/diagnose_analytic.py --large
~~~

整数検査は最大次数655360の全係数を保持するため、メモリと実行時間は環境に依存する。
不要な大規模化を防ぐため、有限積の検査には n≤256 の実行上限を設けた。

## 何が再現されたか

- 99個のスカラー不等式：60桁の区間演算ですべて通過。
- 128個のパラメータ区間、計1408比較：全域を区間演算で包含し、分散と誤差・位相の比を保証。
- 非負恒等式：t=1,2,3,4,9、Q の次数350まで整数で一致。
- n=1,...,256 の全56,252,416係数：符号・相反対称性・剰余類和・最初の尾部公式が一致。
- n=2,...,256：提案された零集合と完全一致。
- 原始根の局所展開48例、eta 変換16例、巨大な n の個別係数6例：通常の80桁計算で整合。
- 等比級数60例、重みを保持した局所剰余192例、正規化積分8例：通常の80桁計算で整合。
- B2補正の有限積36例、合成後の局所誤差120例、弱い剰余類の積分4例：通常の80桁計算で整合。
- 小箱の局所展開32例：v0.4 の積分型剰余とも整合。

結果の小数表示・ライブラリの版などは環境で変わりうる。整数係数のハッシュ、
検査範囲、合否が一致することを確認する。区間出力は各検査の下端が正であることを見る。
数値診断は記載精度の範囲で比較する。

## 主張の限界

区間証明書は本文で導いた数値比較を検査する。全角度の被覆、極限操作、
枝の選択、積分誤差の導出などの解析的推論全体を自動証明するものではない。
有限個の数値診断を全パラメータの証明として使っていない。

本稿の解析的主張を前提にしても、257≤n<300000 は未処理。
新規性の網羅的調査と第三者による独立監査は未了である。

## 来歴と AI 使用

原ノートで参照された過去のコード・証明書は今回受領していない。
このパッケージの検証コードは、原ノートの本文から **OpenAI Codex が新規に再構築** し、
実行したものである。元コードの復元や原実行ログの認証とは区別する。

統合本文、説明の補足、検証コード、実行結果の整理に Codex を使用した。
v0.5 はユーザー提供の別のAIによる改善案を基に、Codex が再導出・実装・検算した。
原ノートは AI との対話による研究作業稿である。
人間による全証明の独立検証を受けたとは主張しない。著者名は記載しない。
趣味の研究記録として、未確認事項を含めて保存する。
