#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT}"
find README.md RELEASE_NOTES.md ENVIRONMENT.txt paper docs notes src data scripts expected independent archive logs work \
  -type f \
  ! -path '*/__pycache__/*' \
  ! -name '*.pyc' \
  ! -name 'SHA256SUMS' \
  -print0 \
| sort -z \
| xargs -0 sha256sum > SHA256SUMS
echo "wrote ${ROOT}/SHA256SUMS"
