#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CXX="${CXX:-g++}"
OUT="${ROOT}/build/strict"
mkdir -p "${OUT}"

FLAGS=(
  -std=c++17 -O2
  -Wall -Wextra -Wpedantic
  -Wconversion -Wshadow -Werror
  -Wno-sign-conversion
)

"${CXX}" "${FLAGS[@]}" "${ROOT}/src/stage1_exact.cpp" -o "${OUT}/stage1_exact"
"${CXX}" "${FLAGS[@]}" "${ROOT}/src/stage2_exact.cpp" -o "${OUT}/stage2_exact"
"${CXX}" "${FLAGS[@]}" \
  "${ROOT}/independent/third_formula_reimplementation/indep_scan.cpp" \
  -o "${OUT}/third_indep_scan"
"${CXX}" "${FLAGS[@]}" \
  "${ROOT}/independent/third_formula_reimplementation/promotion_test.cpp" \
  -o "${OUT}/third_promotion_test"

python3 -m py_compile \
  "${ROOT}/src/tau3_orbit_audit.py" \
  "${ROOT}/scripts/run_primary.py" \
  "${ROOT}/scripts/verify_outputs.py" \
  "${ROOT}/scripts/verify_worst_states_fraction.py" \
  "${ROOT}/scripts/k3_actual_profile_audit.py" \
  "${ROOT}/independent/erdos7_seven_prime_independent_checker.py" \
  "${ROOT}/independent/third_formula_reimplementation/orbits.py" \
  "${ROOT}/independent/third_formula_reimplementation/fraction_check.py" \
  "${ROOT}/independent/third_formula_reimplementation/run_third_independent.py"

echo "STRICT_COMPILE_STATUS: PASS"
