#!/usr/bin/env python3
"""Audit which vertices of the broad K_3 relaxation are closure-realizable.

After the pure mod-3 class has removed one branch, the pure mod-9 class can
remove one full three-leaf node (or no new live leaves), and the pure mod-27
class can remove one further leaf (or no new leaf).  A K_3 vertex has exactly
four zero leaves, so closure-realizability requires its zero set to be one
complete mod-9 node plus one extra leaf.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
from pathlib import Path


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser()
    p.add_argument("--tau", type=Path, default=root / "data/tau3_orbit_types.txt")
    p.add_argument("--out", type=Path, default=root / "logs/k3_actual_profile_audit.txt")
    return p.parse_args()


def is_closure_realizable_vertex(weights: list[int]) -> tuple[bool, int | None, int | None]:
    zeros = {i for i, x in enumerate(weights) if x == 0}
    if len(zeros) != 4:
        return False, None, None
    for node in range(6):
        triple = {3 * node, 3 * node + 1, 3 * node + 2}
        if triple <= zeros:
            extra = next(iter(zeros - triple))
            return True, node, extra
    return False, None, None


def main() -> None:
    args = parse_args()
    reps: dict[int, list[int]] = {}
    for line in args.tau.read_text().splitlines():
        z = [int(x) for x in line.split()]
        reps[z[0]] = z[1:]

    caps = {L: Fraction(2, 2 * L - 1) for L in (14, 15, 17, 18)}
    actual: list[int] = []
    rows: list[str] = []
    for typ in sorted(reps):
        w = reps[typ]
        ok, node, extra = is_closure_realizable_vertex(w)
        if ok:
            actual.append(typ)
        zeros = [i for i, x in enumerate(w) if x == 0]
        one = [i for i, x in enumerate(w) if x == 1]
        rows.append(
            f"type {typ:2d}: realizable={str(ok):5s} zeros={zeros} one={one}"
            + (f" full_node={node} extra={extra}" if ok else "")
        )

    assert actual == [7, 13, 15, 23, 25, 26], actual
    assert is_closure_realizable_vertex(reps[7])[0]
    assert not is_closure_realizable_vertex(reps[11])[0]
    assert is_closure_realizable_vertex(reps[13])[0]

    text = [
        "K_3 actual-profile audit",
        "==========================",
        "Possible live-leaf counts after pure classes mod 3,9,27: 14,15,17,18",
        "Leaf-mass caps 2/(2L-1):",
    ]
    for L in (14, 15, 17, 18):
        text.append(f"  L={L}: {caps[L]} = {float(caps[L]):.12f}")
    text += [
        "",
        "Closure-realizable broad-K_3 vertex types:",
        "  " + " ".join(map(str, actual)),
        "",
        "Critical types:",
        f"  type 7  realizable: {is_closure_realizable_vertex(reps[7])[0]}",
        f"  type 11 realizable: {is_closure_realizable_vertex(reps[11])[0]}",
        f"  type 13 realizable: {is_closure_realizable_vertex(reps[13])[0]}",
        "",
        "All 28 representatives:",
        *rows,
        "",
        "STATUS: PASS",
    ]
    output = "\n".join(text) + "\n"
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(output)
    print(output, end="")


if __name__ == "__main__":
    main()
