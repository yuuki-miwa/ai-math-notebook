#!/usr/bin/env python3
"""Exact Fraction recomputation of the reported extremal states.

This is not the exhaustive search.  It is an independent scaling/formula check
for every reported Stage-I maximizer and the three Stage-II maximizers.
"""
from __future__ import annotations
from fractions import Fraction
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
DENS = (3, 5, 9, 11, 15)
P = range(5)
ALL_MASK = (1 << 5) - 1


def load_tau() -> dict[int, list[int]]:
    out = {}
    for line in (ROOT / "data/tau3_orbit_types.txt").read_text().splitlines():
        z = [int(x) for x in line.split()]
        out[z[0]] = z[1:]
    return out


def state_decode(s: int) -> tuple[int, int]:
    # Portable C++ enumerates parent outer, node inner.
    return s // 7 - 1, s % 7 - 1


def q_stage1(state: tuple[int, ...]) -> list[list[Fraction]]:
    q = [[Fraction(1) for _ in range(18)] for _ in P]
    for p in P:
        parent, node = state_decode(state[p])
        beta = Fraction(1, DENS[p])
        for a in range(18):
            j = a // 3
            q[p][a] -= beta * ((parent == j // 3) + (node == j))
    return q


def q_stage2(state: tuple[int, ...], choices: tuple[int, int, int]) -> list[list[Fraction]]:
    q = q_stage1(state)
    for p, leaf in enumerate(choices):
        if leaf >= 0:
            q[p][leaf] -= Fraction(1, DENS[p])
    return q


def r_value(q: list[list[Fraction]], T: int, a: int) -> Fraction:
    ans = Fraction(1)
    for p in P:
        if not ((T >> p) & 1):
            ans *= q[p][a]
    return ans


def score(tau_scaled: list[int], q: list[list[Fraction]], stage2: bool) -> Fraction:
    tau = [Fraction(x, 27) for x in tau_scaled]
    total = Fraction(0)
    for a in range(18):
        comp = Fraction(1)
        for p in P:
            comp *= q[p][a]
        total += tau[a] * (1 - comp)

    for T in range(1, 32):
        support_size = T.bit_count()
        beta_T = Fraction(1)
        for p in P:
            if (T >> p) & 1:
                beta_T *= Fraction(1, DENS[p])
        vals = [tau[a] * r_value(q, T, a) for a in range(18)]

        if support_size >= 2:
            total += beta_T * sum(vals)
            total += beta_T * max(sum(vals[:9]), sum(vals[9:]))
            total += beta_T * max(sum(vals[3*j:3*j+3]) for j in range(6))
            total += beta_T * max(vals)
        elif not stage2:
            total += beta_T * max(vals)
        else:
            bit = (T & -T).bit_length() - 1
            if bit >= 3:  # 13 and 17 are not level-3 promoted.
                total += beta_T * max(vals)

        # corrected all-leaf g>=4 tail
        total += beta_T * Fraction(1, 27) * max(r_value(q, T, a) for a in range(18))
    return total


def parse_stage1_states() -> dict[int, tuple[int, ...]]:
    out = {}
    for line in (ROOT / "logs/stage1_all.txt").read_text().splitlines():
        z = line.split()
        typ = int(z[0])
        i = z.index("state")
        out[typ] = tuple(map(int, z[i+1:i+6]))
    return out


def parse_stage2_states() -> dict[int, tuple[tuple[int, ...], tuple[int, ...]]]:
    out = {}
    for line in (ROOT / "logs/stage2_all.txt").read_text().splitlines():
        z = line.split()
        typ = int(z[1])
        i = z.index("state")
        j = z.index("choices")
        out[typ] = (tuple(map(int, z[i+1:i+6])), tuple(map(int, z[j+1:j+4])))
    return out


def main() -> None:
    tau = load_tau()
    manifest = json.loads((ROOT / "expected/certificate_manifest.json").read_text())
    s1states = parse_stage1_states()
    for typ in range(28):
        value = score(tau[typ], q_stage1(s1states[typ]), stage2=False)
        expected = Fraction(manifest["stage1"][str(typ)]["numerator"], manifest["denominator"])
        assert value == expected, (typ, value, expected)

    s2states = parse_stage2_states()
    for typ in (7, 11, 13):
        state, choices = s2states[typ]
        value = score(tau[typ], q_stage2(state, choices), stage2=True)
        expected = Fraction(manifest["stage2"][str(typ)]["numerator"], manifest["denominator"])
        assert value == expected, (typ, value, expected)

    text = (
        "Exact Fraction extremal-state check: PASS\n"
        "- all 28 reported Stage-I maximizers recompute exactly\n"
        "- all 3 reported Stage-II maximizers recompute exactly\n"
        "- global Stage-II maximum = 200282/200475\n"
    )
    (ROOT / "logs/fraction_extremal_check.txt").write_text(text)
    print(text, end="")

if __name__ == "__main__":
    main()
