#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import re
from fractions import Fraction
from pathlib import Path

S1_RE = re.compile(r"^(\d+) best (\d+)/(\d+).* survivors (\d+) state")
S2_RE = re.compile(r"^type (\d+) cases (\d+) evals (\d+) best (\d+)/(\d+) reduced (\d+)/(\d+)")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    return p.parse_args()


def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / "expected/certificate_manifest.json").read_text())
    den = manifest["denominator"]
    errors: list[str] = []

    s1_lines = (root / "logs/stage1_all.txt").read_text().splitlines()
    got1: dict[str, tuple[int,int,int]] = {}
    for line in s1_lines:
        m = S1_RE.search(line)
        if m:
            typ, num, d, surv = map(int, m.groups())
            got1[str(typ)] = (num,d,surv)
    if len(got1) != 28:
        errors.append(f"Stage I: expected 28 records, found {len(got1)}")
    for typ, exp in manifest["stage1"].items():
        got = got1.get(typ)
        want = (exp["numerator"], den, exp["survivors"])
        if got != want:
            errors.append(f"Stage I type {typ}: got {got}, expected {want}")
        survivor_file = root / f"work/tau3_type_{typ}_survivors.txt"
        line_count = sum(1 for line in survivor_file.read_text().splitlines() if line.strip())
        if line_count != exp["survivors"]:
            errors.append(f"Stage I type {typ}: survivor file has {line_count}, expected {exp['survivors']}")

    s2_lines = (root / "logs/stage2_all.txt").read_text().splitlines()
    got2: dict[str, tuple[int,int,int,int,int,int]] = {}
    for line in s2_lines:
        m = S2_RE.search(line)
        if m:
            typ,cases,evals,num,d,rn,rd = map(int,m.groups())
            got2[str(typ)] = (cases,evals,num,d,rn,rd)
    if set(got2) != set(manifest["stage2"]):
        errors.append(f"Stage II types: got {sorted(got2)}, expected {sorted(manifest['stage2'])}")
    for typ, exp in manifest["stage2"].items():
        frac = Fraction(exp["numerator"],den)
        want=(exp["cases"],exp["evaluations"],exp["numerator"],den,frac.numerator,frac.denominator)
        if got2.get(typ) != want:
            errors.append(f"Stage II type {typ}: got {got2.get(typ)}, expected {want}")

    global_max=max(Fraction(v[2],v[3]) for v in got2.values()) if got2 else Fraction(10,1)
    target=Fraction(manifest["global_reduced"]["numerator"],manifest["global_reduced"]["denominator"])
    gap=1-global_max
    target_gap=Fraction(manifest["gap_reduced"]["numerator"],manifest["gap_reduced"]["denominator"])
    if global_max != target:
        errors.append(f"global maximum {global_max} != {target}")
    if gap != target_gap:
        errors.append(f"gap {gap} != {target_gap}")
    if not global_max < 1:
        errors.append("global maximum is not below 1")

    orbit_text=(root/"logs/orbit_audit.txt").read_text()
    if "labelled_vertices 42840" not in orbit_text:
        errors.append("orbit audit did not report 42840 labelled vertices")
    if "tree_orbits 28" not in orbit_text:
        errors.append("orbit audit did not report 28 tree orbits")
    if "representative_file_match True" not in orbit_text:
        errors.append("orbit representative file did not match regenerated representatives")

    report = [
        "Seven-Prime exact-certificate verification",
        "=========================================",
        f"Stage I records: {len(got1)}/28",
        f"Stage II records: {len(got2)}/{len(manifest['stage2'])}",
        f"Global maximum: {global_max} = {float(global_max):.16f}",
        f"Exact gap: {gap} = {float(gap):.16f}",
    ]
    if errors:
        report.append("STATUS: FAIL")
        report.extend(f"- {e}" for e in errors)
    else:
        report.append("STATUS: PASS")
        report.append("All exact numerators, survivor counts, evaluation counts, and orbit data match the manifest.")
        report.append("This PASS establishes reproducibility of the finite enumeration; it does not by itself validate the analytic reductions in Lemmas 2.1--8.1.")
    text="\n".join(report)+"\n"
    (root/"logs/verification_report.txt").write_text(text)
    print(text,end="")
    if errors:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
