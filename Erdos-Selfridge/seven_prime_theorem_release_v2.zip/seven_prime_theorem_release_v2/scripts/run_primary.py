#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


def run(cmd: list[str], *, cwd: Path, stdout: Path | None = None) -> None:
    if stdout is None:
        subprocess.run(cmd, cwd=cwd, check=True)
        return
    with stdout.open("w") as f:
        subprocess.run(cmd, cwd=cwd, check=True, stdout=f)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the exact Seven-Prime certificate")
    parser.add_argument(
        "--jobs", type=int, default=int(os.environ.get("JOBS", "1")),
        help="parallel Stage-I workers (default: 1 for maximum portability)",
    )
    parser.add_argument("--cxx", default=os.environ.get("CXX", "g++"))
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    build, work, logs = root / "build", root / "work", root / "logs"
    for d in (build, work, logs):
        d.mkdir(exist_ok=True)
    for p in work.glob("tau3_type_*_survivors.txt"):
        p.unlink()
    for p in logs.glob("stage[12]_*.txt"):
        p.unlink()

    print("[1/5] compiling exact enumerators", flush=True)
    run([args.cxx, "-O3", "-std=c++17", "-DNDEBUG", str(root / "src/stage1_exact.cpp"), "-o", str(build / "stage1_exact")], cwd=root)
    run([args.cxx, "-O3", "-std=c++17", "-DNDEBUG", str(root / "src/stage2_exact.cpp"), "-o", str(build / "stage2_exact")], cwd=root)

    print("[2/5] regenerating the 3-adic profile orbits", flush=True)
    run([sys.executable, str(root / "src/tau3_orbit_audit.py")], cwd=root, stdout=logs / "orbit_audit.txt")

    print(f"[3/5] Stage I: 28 x 21^5 exact states ({max(1,args.jobs)} workers)", flush=True)
    def stage1(t: int) -> int:
        run([
            str(build / "stage1_exact"), str(t),
            "--tau", str(root / "data/tau3_orbit_types.txt"),
            "--out-dir", str(work),
        ], cwd=root, stdout=logs / f"stage1_{t}.txt")
        return t

    if args.jobs <= 1:
        for t in range(28):
            stage1(t)
    else:
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            futures = [pool.submit(stage1, t) for t in range(28)]
            for f in as_completed(futures):
                f.result()
    with (logs / "stage1_all.txt").open("w") as out:
        for t in range(28):
            out.write((logs / f"stage1_{t}.txt").read_text())

    critical_types: list[int] = []
    critical_states = 0
    for t in range(28):
        survivor_file = work / f"tau3_type_{t}_survivors.txt"
        count = 0
        if survivor_file.exists():
            count = sum(1 for line in survivor_file.read_text().splitlines() if line.strip())
        if count:
            critical_types.append(t)
            critical_states += count

    type_text = ", ".join(map(str, critical_types)) or "none"
    print(
        f"[4/5] Stage II: {critical_states:,} x 19^3 exact refinements "
        f"for dynamically detected types [{type_text}]",
        flush=True,
    )
    def stage2(t: int) -> int:
        run([
            str(build / "stage2_exact"), str(t),
            "--tau", str(root / "data/tau3_orbit_types.txt"),
            "--survivor-dir", str(work),
        ], cwd=root, stdout=logs / f"stage2_{t}.txt")
        return t

    if args.jobs <= 1 or len(critical_types) <= 1:
        for t in critical_types:
            stage2(t)
    else:
        with ThreadPoolExecutor(max_workers=min(args.jobs, len(critical_types))) as pool:
            futures = [pool.submit(stage2, t) for t in critical_types]
            for f in as_completed(futures):
                f.result()
    with (logs / "stage2_all.txt").open("w") as out:
        for t in critical_types:
            out.write((logs / f"stage2_{t}.txt").read_text())

    print("[5/5] checking manifest and exact Fraction evaluations", flush=True)
    run([sys.executable, str(root / "scripts/verify_outputs.py"), "--root", str(root)], cwd=root)
    run([sys.executable, str(root / "scripts/verify_worst_states_fraction.py")], cwd=root)


if __name__ == "__main__":
    main()
