from itertools import combinations
import numpy as np
from numba import njit
from math import comb, gcd

# Independent generation of depth-3 tau orbit representatives.
def canon_tau(w):
    # canonical bottom-up tree code: sort leaves within each mod-9 node,
    # then sort the three mod-9 child codes within each live mod-3 branch,
    # then sort the two branch codes.
    branches=[]
    for b in range(2):
        nodes=[]
        for j in range(3):
            base=9*b+3*j
            nodes.append(tuple(sorted(w[base:base+3])))
        branches.append(tuple(sorted(nodes)))
    return tuple(sorted(branches))

orb={}
for one in range(18):
    rem=[a for a in range(18) if a!=one]
    for zs in combinations(rem,4):
        w=[2]*18
        w[one]=1
        for z in zs: w[z]=0
        k=canon_tau(w)
        orb[k]=orb.get(k,0)+1
assert sum(orb.values()) == 42840
assert len(orb)==28
reps=[]
for k in sorted(orb):
    flat=[]
    for branch in k:
        for node in branch:
            flat.extend(node)
    reps.append(np.array(flat,dtype=np.int64))

DENS=np.array([3,5,9,11,15],dtype=np.int64)
D=int(np.prod(DENS))
DEN=27*D

# state s=0..20 encodes independently chosen level-1 and level-2 simplex vertices:
# parent in {-1,0,1}, node in {-1,0,...,5}.
FAC=np.empty((5,21,6),dtype=np.int64)
for p in range(5):
    for s in range(21):
        parent=s//7-1
        node=s%7-1
        for j in range(6):
            FAC[p,s,j]=DENS[p] - (1 if parent==j//3 else 0) - (1 if node==j else 0)

@njit
def score_stage1(w, s0,s1,s2,s3,s4):
    ss=(s0,s1,s2,s3,s4)
    agg=np.zeros(6,np.int64)
    mx=np.zeros(6,np.int64)
    for j in range(6):
        a=3*j
        agg[j]=w[a]+w[a+1]+w[a+2]
        m=w[a]
        if w[a+1]>m: m=w[a+1]
        if w[a+2]>m: m=w[a+2]
        mx[j]=m
    # q numerators d_p - chosen ancestor hits, at the 6 mod-9 nodes.
    q=np.empty((5,6),np.int64)
    for p in range(5):
        for j in range(6): q[p,j]=FAC[p,ss[p],j]
    sc=np.int64(0)
    # skeleton
    for j in range(6):
        prod=1
        for p in range(5): prod*=q[p,j]
        sc += agg[j]*(D-prod)
    # residual supports T=1..31. Compute outside product directly (not subset DP).
    for T in range(1,32):
        pc=0
        for p in range(5):
            if (T>>p)&1: pc+=1
        R=np.ones(6,np.int64)
        for j in range(6):
            prod=1
            for p in range(5):
                if ((T>>p)&1)==0: prod*=q[p,j]
            R[j]=prod
        if pc>=2:
            g0=np.int64(0); b0=np.int64(0); b1=np.int64(0); g2=np.int64(0)
            for j in range(6):
                v=agg[j]*R[j]
                g0+=v
                if j<3: b0+=v
                else: b1+=v
                if v>g2: g2=v
            sc += g0 + (b0 if b0>b1 else b1) + g2
        # level-3 residual: all nonempty T at Stage I.
        g3=np.int64(0)
        for j in range(6):
            v=mx[j]*R[j]
            if v>g3: g3=v
        sc += g3
        # corrected all-leaf tail. q is constant inside each mod-9 node.
        gh=R[0]
        for j in range(1,6):
            if R[j]>gh: gh=R[j]
        sc += gh
    return sc

@njit
def scan_stage1(w, cap=5000):
    best=np.int64(-1)
    bstate=np.zeros(5,np.int64)
    survivors=np.empty((cap,6),np.int64)
    n=0
    for s0 in range(21):
      for s1 in range(21):
       for s2 in range(21):
        for s3 in range(21):
         for s4 in range(21):
            z=score_stage1(w,s0,s1,s2,s3,s4)
            if z>best:
                best=z; bstate[0]=s0;bstate[1]=s1;bstate[2]=s2;bstate[3]=s3;bstate[4]=s4
            if z>=DEN:
                if n>=cap:
                    return best,bstate,survivors,n,-1
                survivors[n,0]=s0;survivors[n,1]=s1;survivors[n,2]=s2;survivors[n,3]=s3;survivors[n,4]=s4;survivors[n,5]=z
                n+=1
    return best,bstate,survivors,n,0

@njit
def score_stage2(w, base_states, c0,c1,c2):
    # full 18-leaf representation; primes 0,1,2 get a level-3 promoted full budget.
    cs=(c0,c1,c2,-2,-2)
    q=np.empty((5,18),np.int64)
    for p in range(5):
        s=base_states[p]
        parent=s//7-1
        node=s%7-1
        for a in range(18):
            j=a//3
            k=(1 if parent==j//3 else 0)+(1 if node==j else 0)
            if p<3 and cs[p]==a: k+=1
            q[p,a]=DENS[p]-k
    sc=np.int64(0)
    for a in range(18):
        prod=1
        for p in range(5): prod*=q[p,a]
        sc += w[a]*(D-prod)
    for T in range(1,32):
        pc=0
        for p in range(5):
            if (T>>p)&1: pc+=1
        R=np.ones(18,np.int64)
        for a in range(18):
            prod=1
            for p in range(5):
                if ((T>>p)&1)==0: prod*=q[p,a]
            R[a]=prod
        if pc>=2:
            g0=np.int64(0); br0=np.int64(0);br1=np.int64(0)
            node=np.zeros(6,np.int64);g3=np.int64(0)
            for a in range(18):
                v=w[a]*R[a]
                g0+=v
                if a<9: br0+=v
                else: br1+=v
                node[a//3]+=v
                if v>g3:g3=v
            g2=node[0]
            for j in range(1,6):
                if node[j]>g2:g2=node[j]
            sc += g0 + (br0 if br0>br1 else br1) + g2 + g3
        else:
            # singleton g=3 remains residual only for unpromoted primes 13,17 (indices 3,4)
            bit=0
            for p in range(5):
                if (T>>p)&1: bit=p
            if bit>=3:
                g3=np.int64(0)
                for a in range(18):
                    v=w[a]*R[a]
                    if v>g3:g3=v
                sc += g3
        # corrected all-leaf tail
        gh=R[0]
        for a in range(1,18):
            if R[a]>gh:gh=R[a]
        sc += gh
    return sc

@njit
def scan_stage2(w, survivors, n):
    best=np.int64(-1); bst=np.zeros(5,np.int64); bc=np.zeros(3,np.int64)
    evals=0
    for ii in range(n):
        s=survivors[ii,:5]
        for c0 in range(-1,18):
         for c1 in range(-1,18):
          for c2 in range(-1,18):
            z=score_stage2(w,s,c0,c1,c2); evals+=1
            if z>best:
                best=z
                for k in range(5):bst[k]=s[k]
                bc[0]=c0;bc[1]=c1;bc[2]=c2
    return best,bst,bc,evals

if __name__=='__main__':
    print('labelled_vertices',sum(orb.values()))
    print('tree_orbits',len(orb))
    print('orbit_sizes',sorted(orb.values()))
    # warm up
    score_stage1(reps[0],0,0,0,0,0)
    stage1=[]
    surv_by_type={}
    for i,w in enumerate(reps):
        best,bs,surv,n,err=scan_stage1(w)
        if err: raise RuntimeError('survivor capacity')
        stage1.append((int(best),int(n),tuple(map(int,bs))))
        if n:
            surv_by_type[i]=surv[:n].copy()
        print('S1',i,int(best),int(n),tuple(map(int,bs)))
    print('critical_types',sorted(surv_by_type))
    for i,surv in surv_by_type.items():
        best,bs,bc,ev=scan_stage2(reps[i],surv,len(surv))
        g=gcd(int(best),DEN)
        print('S2',i,int(best),f'{int(best)//g}/{DEN//g}',len(surv),int(ev),tuple(map(int,bs)),tuple(map(int,bc)))
