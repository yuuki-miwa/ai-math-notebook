# Third formula-only reconstruction

This directory contains a reconstruction of the finite Seven-Prime certificate written from the manuscript formulas (6.1) and (6.2), without consulting the primary Stage-I/Stage-II evaluation source. It was contributed during adversarial AI review and was subsequently made path-portable and rerun as part of release v2.

The reconstruction deliberately differs from the primary code:

- all 18 leaves are carried explicitly at every stage;
- there is no mod-9 aggregation in the score evaluator;
- there is no Gray-code subset-product table;
- exact `Fraction` arithmetic is used in a separate formula check;
- the profile vertices and rooted-tree orbits are regenerated independently.

## One-command run

From the release root:

```bash
python3 independent/third_formula_reimplementation/run_third_independent.py
```

The default is a sequential Stage-I scan and a promotion regression using 60 sampled shallow states per profile type. Parallel Stage I is optional:

```bash
python3 independent/third_formula_reimplementation/run_third_independent.py --jobs 4
```

The driver:

1. compiles `indep_scan.cpp` and `promotion_test.cpp`;
2. regenerates 42,840 profile vertices and 28 rooted-tree orbits;
3. reproduces all 28 Stage-I maxima and survivor counts;
4. compares the complete five-coordinate survivor-state sequences with the primary output—the primary files have an additional numerator column, so this is a state-sequence comparison rather than byte identity of the raw files;
5. derives the Stage-II type list from the nonempty independent survivor files;
6. reproduces all three Stage-II maxima;
7. evaluates representative extrema with exact `Fraction` arithmetic;
8. checks the type-13 extra-promotion diagnostic;
9. stress-tests the promotion inequality on deterministic pseudorandom shallow vertices.

## Files

| file | purpose |
|---|---|
| `indep_scan.cpp` | full formula-only Stage-I and Stage-II integer scans |
| `orbits.py` | independent K3 vertex and rooted-tree orbit regeneration |
| `fraction_check.py` | exact rational formula checks and extra-promotion diagnostic |
| `promotion_test.cpp` | empirical regression test for the promotion inequality |
| `run_third_independent.py` | build, comparison, and reporting driver |

The promotion program is a regression test, not the proof of the promotion lemma. The proof is the algebraic comparison in the manuscript.
