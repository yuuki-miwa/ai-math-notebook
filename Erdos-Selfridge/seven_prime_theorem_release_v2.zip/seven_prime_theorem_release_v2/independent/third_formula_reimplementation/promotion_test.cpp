// Empirical stress test of Lemma 7.4 (promotion), which is the load-bearing
// step licensing the Stage-I filter: it must be true that for EVERY shallow
// vertex x and EVERY level-three refinement y,   F_3(tau,x,y) <= F_2(tau,x).
// If that ever failed on a state with F_2 < 1, the 2505-state Stage-II scan
// would not be exhaustive.
//
// We sample random shallow states per profile type and check the inequality
// against all 19^3 refinements.

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <random>
#include <string>
#include <vector>

using i64 = std::int64_t;
static const int d[5] = {3, 5, 9, 11, 15};
static const i64 D = 3LL * 5 * 9 * 11 * 15;
static const i64 DEN = 27 * D;
struct St { int b, n; };

static std::array<St, 21> S;

static i64 eval(const int w[18], const int ss[5], const int c[5], const bool promoted[5]) {
    i64 Q[5][18];
    for (int i = 0; i < 5; ++i) {
        const St st = S[ss[i]];
        for (int a = 0; a < 18; ++a) {
            i64 v = d[i];
            if (st.b == a / 9) v -= 1;
            if (st.n == a / 3) v -= 1;
            if (promoted[i] && c[i] == a) v -= 1;
            Q[i][a] = v;
        }
    }
    i64 total = 0;
    for (int a = 0; a < 18; ++a) {
        i64 prod = 1;
        for (int i = 0; i < 5; ++i) prod *= Q[i][a];
        total += (i64)w[a] * (D - prod);
    }
    for (int T = 1; T < 32; ++T) {
        int popc = __builtin_popcount((unsigned)T);
        i64 P[18];
        for (int a = 0; a < 18; ++a) {
            i64 prod = 1;
            for (int i = 0; i < 5; ++i) if (!(T >> i & 1)) prod *= Q[i][a];
            P[a] = prod;
        }
        if (popc >= 2) {
            i64 L0 = 0, br[2] = {0, 0}, nd[6] = {0, 0, 0, 0, 0, 0};
            for (int a = 0; a < 18; ++a) {
                i64 v = (i64)w[a] * P[a];
                L0 += v; br[a / 9] += v; nd[a / 3] += v;
            }
            total += L0 + std::max(br[0], br[1]) + *std::max_element(nd, nd + 6);
        }
        bool skip = false;
        if (popc == 1) { int b = __builtin_ctz((unsigned)T); skip = promoted[b]; }
        if (!skip) {
            i64 L3 = 0;
            for (int a = 0; a < 18; ++a) L3 = std::max(L3, (i64)w[a] * P[a]);
            total += L3;
        }
        i64 H = 0;
        for (int a = 0; a < 18; ++a) H = std::max(H, P[a]);
        total += H;
    }
    return total;
}

int main(int argc, char** argv) {
    int k = 0;
    for (int b = -1; b <= 1; ++b) for (int n = -1; n < 6; ++n) S[k++] = {b, n};

    std::vector<std::array<int, 18>> tau(28);
    { std::ifstream in(argv[1]); int id;
      while (in >> id) { std::array<int,18> t{}; for (int& x : t) in >> x; tau[id] = t; } }

    const int samples = (argc > 2) ? std::atoi(argv[2]) : 100;
    const bool none5[5] = {false,false,false,false,false};
    const bool promo3[5] = {true,true,true,false,false};
    const int noc[5] = {-1,-1,-1,-1,-1};

    std::mt19937 rng(20260904);
    std::uniform_int_distribution<int> U(0, 20);

    long long checked = 0, violations = 0;
    i64 worst_excess = 0;          // max over samples of (maxF3 - F2), should be <= 0
    i64 global_best_f3_below = -1; // largest F3 seen on a state with F2 < 1

    for (int t = 0; t < 28; ++t) {
        for (int s = 0; s < samples; ++s) {
            int ss[5]; for (int i = 0; i < 5; ++i) ss[i] = U(rng);
            const i64 f2 = eval(tau[t].data(), ss, noc, none5);
            i64 bestf3 = -1;
            int c[5] = {-1,-1,-1,-1,-1};
            for (c[0] = -1; c[0] < 18; ++c[0])
            for (c[1] = -1; c[1] < 18; ++c[1])
            for (c[2] = -1; c[2] < 18; ++c[2]) {
                const i64 v = eval(tau[t].data(), ss, c, promo3);
                if (v > bestf3) bestf3 = v;
                ++checked;
            }
            if (bestf3 > f2) { ++violations;
                std::printf("VIOLATION type %d state %d %d %d %d %d : F2=%lld F3=%lld\n",
                            t, ss[0],ss[1],ss[2],ss[3],ss[4], (long long)f2, (long long)bestf3); }
            worst_excess = std::max(worst_excess, bestf3 - f2);
            if (f2 < DEN) global_best_f3_below = std::max(global_best_f3_below, bestf3);
        }
    }
    std::printf("sampled states: %d x 28 = %d ; refinements checked: %lld\n",
                samples, samples * 28, checked);
    std::printf("promotion-lemma violations (F3 > F2): %lld\n", violations);
    std::printf("max observed (maxF3 - F2) = %lld  (must be <= 0)\n", (long long)worst_excess);
    std::printf("largest F3 seen on a state with F2 < 1: %lld / %lld\n",
                (long long)global_best_f3_below, (long long)DEN);
    return violations ? 1 : 0;
}
