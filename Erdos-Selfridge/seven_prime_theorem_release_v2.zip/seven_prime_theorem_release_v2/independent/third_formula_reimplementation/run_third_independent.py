#!/usr/bin/env python3
"""Build, run and compare the third formula-only reconstruction."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

S1_RE = re.compile(r"^type (\d+) best (\d+)/(\d+) survivors (\d+) state")
S2_RE = re.compile(r"^type (\d+) cases (\d+) evals (\d+) best (\d+)/(\d+) state")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--jobs", type=int, default=int(os.environ.get("JOBS", "1")))
    p.add_argument("--cxx", default=os.environ.get("CXX", "g++"))
    p.add_argument("--promotion-samples", type=int, default=60)
    return p.parse_args()


def run(cmd: list[str], cwd: Path, output: Path | None = None) -> None:
    if output is None:
        subprocess.run(cmd, cwd=cwd, check=True)
    else:
        with output.open("w") as f:
            subprocess.run(cmd, cwd=cwd, check=True, stdout=f)


def state_rows(path: Path, columns: int = 5) -> list[tuple[int, ...]]:
    rows: list[tuple[int, ...]] = []
    if not path.exists():
        return rows
    for line in path.read_text().splitlines():
        if line.strip():
            rows.append(tuple(int(x) for x in line.split()[:columns]))
    return rows


def main() -> None:
    args = parse_args()
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    build = root / "build" / "third_formula_reimplementation"
    logs = root / "logs" / "third_independent"
    work = build / "work"
    retained_survivors = logs / "survivors"
    for d in (build, logs, work, retained_survivors):
        d.mkdir(parents=True, exist_ok=True)
    for p in work.glob("indep_surv_*.txt"):
        p.unlink()
    for p in logs.glob("*.txt"):
        p.unlink()
    for p in retained_survivors.glob("indep_surv_*.txt"):
        p.unlink()

    manifest = json.loads((root / "expected/certificate_manifest.json").read_text())
    tau = root / "data/tau3_orbit_types.txt"
    scanner = build / "indep_scan"
    promotion = build / "promotion_test"

    print("[1/6] compiling formula-only scanners", flush=True)
    flags = ["-O3", "-std=c++17", "-DNDEBUG", "-Wall", "-Wextra", "-Wpedantic"]
    run([args.cxx, *flags, str(here / "indep_scan.cpp"), "-o", str(scanner)], root)
    run([args.cxx, *flags, str(here / "promotion_test.cpp"), "-o", str(promotion)], root)

    print("[2/6] regenerating the 42,840 profile vertices and 28 orbits", flush=True)
    run([sys.executable, str(here / "orbits.py"), "--tau", str(tau)], root, logs / "orbits.txt")

    print(f"[3/6] Stage I formula-only scan ({max(1,args.jobs)} worker(s))", flush=True)
    def stage1(typ: int) -> None:
        run([str(scanner), str(tau), "stage1", str(typ)], work, logs / f"stage1_{typ}.txt")

    if args.jobs <= 1:
        for typ in range(28):
            stage1(typ)
    else:
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            futures = [pool.submit(stage1, typ) for typ in range(28)]
            for future in as_completed(futures):
                future.result()

    errors: list[str] = []
    critical: list[int] = []
    combined: list[str] = []
    for typ in range(28):
        line = (logs / f"stage1_{typ}.txt").read_text().strip()
        combined.append(line)
        match = S1_RE.match(line)
        if not match:
            errors.append(f"could not parse Stage-I type {typ}: {line!r}")
            continue
        got_typ, num, den, survivors = map(int, match.groups())
        expected = manifest["stage1"][str(typ)]
        if got_typ != typ or num != expected["numerator"] or den != manifest["denominator"] or survivors != expected["survivors"]:
            errors.append(
                f"Stage-I type {typ}: got {(got_typ,num,den,survivors)}, "
                f"expected {(typ,expected['numerator'],manifest['denominator'],expected['survivors'])}"
            )
        independent_file = work / f"indep_surv_{typ}.txt"
        primary_file = root / "work" / f"tau3_type_{typ}_survivors.txt"
        independent_rows = state_rows(independent_file)
        primary_rows = state_rows(primary_file)
        if independent_rows != primary_rows:
            errors.append(f"Stage-I type {typ}: five-coordinate survivor-state sequence differs from primary")
        if independent_rows:
            critical.append(typ)
            shutil.copy2(independent_file, retained_survivors / independent_file.name)
    (logs / "stage1_all.txt").write_text("\n".join(combined) + "\n")

    print(f"[4/6] Stage II types derived from independent survivor files: {critical}", flush=True)
    combined2: list[str] = []
    for typ in critical:
        run([str(scanner), str(tau), "stage2", str(typ)], work, logs / f"stage2_{typ}.txt")
        line = (logs / f"stage2_{typ}.txt").read_text().strip()
        combined2.append(line)
        match = S2_RE.match(line)
        if not match:
            errors.append(f"could not parse Stage-II type {typ}: {line!r}")
            continue
        got_typ, cases, evaluations, num, den = map(int, match.groups())
        expected = manifest["stage2"].get(str(typ))
        if expected is None:
            errors.append(f"unexpected Stage-II type {typ}")
        elif (got_typ, cases, evaluations, num, den) != (
            typ, expected["cases"], expected["evaluations"], expected["numerator"], manifest["denominator"]
        ):
            errors.append(f"Stage-II type {typ}: output differs from manifest")
    if set(map(str, critical)) != set(manifest["stage2"]):
        errors.append(f"critical types {critical} differ from manifest {sorted(map(int, manifest['stage2']))}")
    (logs / "stage2_all.txt").write_text("\n".join(combined2) + "\n")

    print("[5/6] exact Fraction checks and witness headroom diagnostic", flush=True)
    run([sys.executable, str(here / "fraction_check.py"), "--tau", str(tau)], root, logs / "fraction_check.txt")

    if args.promotion_samples > 0:
        print(
            f"[6/6] promotion regression: 28 x {args.promotion_samples} states x 19^3 refinements",
            flush=True,
        )
        run([str(promotion), str(tau), str(args.promotion_samples)], root, logs / "promotion_regression.txt")
    else:
        print("[6/6] promotion regression skipped", flush=True)

    orbit_text = (logs / "orbits.txt").read_text()
    fraction_text = (logs / "fraction_check.txt").read_text()
    if "STATUS: PASS" not in orbit_text:
        errors.append("orbit reconstruction did not pass")
    if "STATUS: PASS" not in fraction_text:
        errors.append("Fraction reconstruction did not pass")
    if args.promotion_samples > 0:
        promo_text = (logs / "promotion_regression.txt").read_text()
        if "promotion-lemma violations (F3 > F2): 0" not in promo_text:
            errors.append("promotion regression reported a violation or unparsable output")

    report = [
        "Third formula-only reconstruction",
        "=================================",
        f"Stage-I records checked: 28",
        f"Critical types derived: {critical}",
        "Survivor comparison: complete five-coordinate state sequences",
        f"Stage-II records checked: {len(critical)}",
        f"Promotion samples per type: {args.promotion_samples}",
    ]
    if errors:
        report.append("STATUS: FAIL")
        report.extend(f"- {e}" for e in errors)
    else:
        report.append("STATUS: PASS")
        report.append("All formula-only outputs agree with the primary retained states and the exact manifest.")
    text = "\n".join(report) + "\n"
    (logs / "verification_report.txt").write_text(text)
    print(text, end="")
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
