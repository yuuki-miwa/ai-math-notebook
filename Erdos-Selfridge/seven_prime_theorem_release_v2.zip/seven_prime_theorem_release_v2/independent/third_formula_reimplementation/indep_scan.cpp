// Independent re-implementation of the Stage-I / Stage-II functionals
// (6.1) and (6.2) of "A seven-prime obstruction for distinct odd covering
// systems".  Deliberately written without the subset-product Gray-code trick
// and with all 18 leaves carried explicitly at every stage.
//
// Everything is kept as an integer numerator over DEN = 27 * 3*5*9*11*15
//                                                     = 601425.
//
//   tau_a      = w_a / 27,            w_a in {0,1,2}
//   beta_i     = 1 / d_i,             d = (3,5,9,11,15)
//   q_{i,a}    = Q_{i,a} / d_i
//   B_T R_{T,a} = (prod_{i notin T} Q_{i,a}) / D,   D = 22275
//
//   U_skel = sum_a tau_a (1 - prod_i q_{i,a})
//          = [ sum_a w_a (D - prod_i Q_{i,a}) ] / (27 D)
//
//   B_T L_0(T) = [ sum_a w_a P_{T,a} ] / (27 D),   P_{T,a} = prod_{i notin T} Q_{i,a}
//   B_T L_1(T) = [ max over the 2 branches of sum_{a in branch} w_a P_{T,a} ] / (27D)
//   B_T L_2(T) = [ max over the 6 mod-9 nodes  of sum_{a in node}  w_a P_{T,a} ] / (27D)
//   B_T L_3(T) = [ max over the 18 leaves      of      w_a P_{T,a} ] / (27D)
//   B_T H(T)/27= [ max over the 18 leaves      of          P_{T,a} ] / (27D)

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using i64 = std::int64_t;

static const int d[5] = {3, 5, 9, 11, 15};
static const i64 D = 3LL * 5 * 9 * 11 * 15;    // 22275
static const i64 DEN = 27 * D;                 // 601425

// axis state s in 0..20 decodes to (level-1 choice, level-2 choice)
struct St { int b; int n; };   // b in {-1,0,1}, n in {-1,0..5}

static std::array<St, 21> make_states() {
    std::array<St, 21> s{};
    int k = 0;
    for (int b = -1; b <= 1; ++b)
        for (int n = -1; n < 6; ++n) s[k++] = {b, n};
    return s;
}

// Evaluate the functional for a fixed profile w[18], fixed shallow states
// ss[5], and level-3 promotion choices c[5] (c[i] = -1 means "not promoted"
// or "zero vertex").  promoted[i] says whether prime i has a level-3 block.
static i64 eval(const int w[18], const std::array<St, 21>& S,
                const int ss[5], const int c[5], const bool promoted[5]) {
    i64 Q[5][18];
    for (int i = 0; i < 5; ++i) {
        const St st = S[ss[i]];
        for (int a = 0; a < 18; ++a) {
            const int branch = a / 9;
            const int node = a / 3;
            i64 v = d[i];
            if (st.b == branch) v -= 1;          // level-1 exposure on this path
            if (st.n == node) v -= 1;            // level-2 exposure on this path
            if (promoted[i] && c[i] == a) v -= 1; // level-3 exposure on this leaf
            Q[i][a] = v;
        }
    }

    i64 total = 0;

    // exact skeleton
    for (int a = 0; a < 18; ++a) {
        i64 prod = 1;
        for (int i = 0; i < 5; ++i) prod *= Q[i][a];
        total += (i64)w[a] * (D - prod);
    }

    // residual families, one nonempty support T at a time
    for (int T = 1; T < 32; ++T) {
        int popc = 0;
        for (int i = 0; i < 5; ++i) if (T >> i & 1) ++popc;

        i64 P[18];
        for (int a = 0; a < 18; ++a) {
            i64 prod = 1;
            for (int i = 0; i < 5; ++i)
                if (!(T >> i & 1)) prod *= Q[i][a];
            P[a] = prod;
        }

        if (popc >= 2) {
            // g = 0 : whole live space
            i64 L0 = 0;
            for (int a = 0; a < 18; ++a) L0 += (i64)w[a] * P[a];
            total += L0;
            // g = 1 : best mod-3 branch
            i64 br[2] = {0, 0};
            for (int a = 0; a < 18; ++a) br[a / 9] += (i64)w[a] * P[a];
            total += std::max(br[0], br[1]);
            // g = 2 : best mod-9 node
            i64 nd[6] = {0, 0, 0, 0, 0, 0};
            for (int a = 0; a < 18; ++a) nd[a / 3] += (i64)w[a] * P[a];
            total += *std::max_element(nd, nd + 6);
        }
        // g = 3 : best leaf, omitted when this singleton has been promoted
        bool skip_g3 = false;
        if (popc == 1) {
            int bit = 0;
            while (!(T >> bit & 1)) ++bit;
            skip_g3 = promoted[bit];
        }
        if (!skip_g3) {
            i64 L3 = 0;
            for (int a = 0; a < 18; ++a) L3 = std::max(L3, (i64)w[a] * P[a]);
            total += L3;
        }
        // g >= 4 : deep tail, all-leaf maximum
        i64 H = 0;
        for (int a = 0; a < 18; ++a) H = std::max(H, P[a]);
        total += H;
    }
    return total;
}

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: %s TAUFILE MODE [TYPE]\n", argv[0]); return 2; }
    const std::string tauf = argv[1];
    const std::string mode = argv[2];

    std::vector<std::array<int, 18>> tau(28);
    {
        std::ifstream in(tauf);
        int id;
        while (in >> id) {
            std::array<int, 18> t{};
            for (int& x : t) in >> x;
            tau[id] = t;
        }
    }

    const auto S = make_states();
    const bool no_promo[5] = {false, false, false, false, false};
    const bool promo3[5]  = {true, true, true, false, false};
    const int nochoice[5] = {-1, -1, -1, -1, -1};

    if (mode == "stage1") {
        const int lo = (argc > 3) ? std::atoi(argv[3]) : 0;
        const int hi = (argc > 3) ? lo + 1 : 28;
        for (int t = lo; t < hi; ++t) {
            i64 best = -1; long long surv = 0;
            int bs[5] = {0, 0, 0, 0, 0};
            std::vector<std::array<int,5>> survivors;
            int ss[5];
            for (ss[0] = 0; ss[0] < 21; ++ss[0])
            for (ss[1] = 0; ss[1] < 21; ++ss[1])
            for (ss[2] = 0; ss[2] < 21; ++ss[2])
            for (ss[3] = 0; ss[3] < 21; ++ss[3])
            for (ss[4] = 0; ss[4] < 21; ++ss[4]) {
                const i64 v = eval(tau[t].data(), S, ss, nochoice, no_promo);
                if (v > best) { best = v; for (int i=0;i<5;++i) bs[i]=ss[i]; }
                if (v >= DEN) { ++surv; survivors.push_back({ss[0],ss[1],ss[2],ss[3],ss[4]}); }
            }
            std::printf("type %d best %lld/%lld survivors %lld state %d %d %d %d %d\n",
                        t, (long long)best, (long long)DEN, surv,
                        bs[0], bs[1], bs[2], bs[3], bs[4]);
            std::fflush(stdout);
            if (!survivors.empty()) {
                std::ofstream o("indep_surv_" + std::to_string(t) + ".txt");
                for (auto& s : survivors)
                    o << s[0] << ' ' << s[1] << ' ' << s[2] << ' ' << s[3] << ' ' << s[4] << '\n';
            }
        }
        return 0;
    }

    if (mode == "stage2") {
        const int t = std::atoi(argv[3]);
        std::ifstream in("indep_surv_" + std::to_string(t) + ".txt");
        int ss[5];
        i64 best = -1; long long cases = 0, evals = 0;
        int bs[5] = {0,0,0,0,0}, bc[3] = {0,0,0};
        while (in >> ss[0] >> ss[1] >> ss[2] >> ss[3] >> ss[4]) {
            ++cases;
            int c[5] = {-1,-1,-1,-1,-1};
            for (c[0] = -1; c[0] < 18; ++c[0])
            for (c[1] = -1; c[1] < 18; ++c[1])
            for (c[2] = -1; c[2] < 18; ++c[2]) {
                const i64 v = eval(tau[t].data(), S, ss, c, promo3);
                ++evals;
                if (v > best) { best = v; for(int i=0;i<5;++i) bs[i]=ss[i];
                                bc[0]=c[0]; bc[1]=c[1]; bc[2]=c[2]; }
            }
        }
        std::printf("type %d cases %lld evals %lld best %lld/%lld state %d %d %d %d %d choices %d %d %d\n",
                    t, cases, evals, (long long)best, (long long)DEN,
                    bs[0],bs[1],bs[2],bs[3],bs[4], bc[0],bc[1],bc[2]);
        return 0;
    }
    return 2;
}
