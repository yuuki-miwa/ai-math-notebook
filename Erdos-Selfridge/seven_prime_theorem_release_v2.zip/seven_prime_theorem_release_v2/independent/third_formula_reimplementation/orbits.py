#!/usr/bin/env python3
"""Formula-only regeneration of the K_3 vertices and rooted-tree orbits."""
from __future__ import annotations

import argparse
from collections import defaultdict
from itertools import combinations, permutations
from pathlib import Path


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    p = argparse.ArgumentParser()
    p.add_argument("--tau", type=Path, default=root / "data/tau3_orbit_types.txt")
    return p.parse_args()


def canon(w: tuple[int, ...]) -> tuple[int, ...]:
    best: tuple[int, ...] | None = None
    for branch_swap in (False, True):
        for node0 in permutations(range(3)):
            for node1 in permutations(range(3)):
                node_perm = (node0, node1)
                placed = [0] * 18
                for a, value in enumerate(w):
                    branch, node, _leaf = a // 9, (a % 9) // 3, a % 3
                    new_branch = 1 - branch if branch_swap else branch
                    new_node = node_perm[branch][node]
                    # Independent leaf permutations mean that only the sorted
                    # multiset inside each node matters for canonicalisation.
                    placed[9 * new_branch + 3 * new_node + (a % 3)] = value
                candidate: list[int] = []
                for j in range(6):
                    candidate.extend(sorted(placed[3 * j:3 * j + 3], reverse=True))
                c = tuple(candidate)
                if best is None or c > best:
                    best = c
    assert best is not None
    return best


def main() -> None:
    args = parse_args()
    vertices: list[tuple[int, ...]] = []
    for one in range(18):
        remaining = [i for i in range(18) if i != one]
        for zeros in combinations(remaining, 4):
            w = [2] * 18
            w[one] = 1
            for z in zeros:
                w[z] = 0
            vertices.append(tuple(w))
    vertices = sorted(set(vertices))
    assert len(vertices) == 42_840
    assert all(sum(w) == 27 for w in vertices)

    orbits: dict[tuple[int, ...], list[tuple[int, ...]]] = defaultdict(list)
    for w in vertices:
        orbits[canon(w)].append(w)

    released: dict[int, tuple[int, ...]] = {}
    for line in args.tau.read_text().splitlines():
        z = [int(x) for x in line.split()]
        released[z[0]] = tuple(z[1:])
    released_canon = {canon(w): typ for typ, w in released.items()}

    sizes = sorted(len(v) for v in orbits.values())
    group_order = 2 * 6 * 6 * (6 ** 6)
    ok = (
        len(orbits) == 28
        and sum(sizes) == 42_840
        and len(released) == 28
        and len(released_canon) == 28
        and set(orbits) == set(released_canon)
        and group_order == 3_359_232
    )

    print(f"labelled_vertices {len(vertices)}")
    print(f"tree_orbits {len(orbits)}")
    print(f"orbit_size_sum {sum(sizes)}")
    print("orbit_sizes " + " ".join(map(str, sizes)))
    print(f"group_order {group_order}")
    print(f"released_representatives {len(released)}")
    print(f"representative_orbit_match {ok}")
    print("STATUS: " + ("PASS" if ok else "FAIL"))
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
