#!/usr/bin/env python3
"""Exact-Fraction evaluation of (6.1)/(6.2), without denominator compression."""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from pathlib import Path

P = [5, 7, 11, 13, 17]
BETA = [F(1, p - 2) for p in P]
STATES = [(b, n) for b in (-1, 0, 1) for n in (-1, 0, 1, 2, 3, 4, 5)]


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    p = argparse.ArgumentParser()
    p.add_argument("--tau", type=Path, default=root / "data/tau3_orbit_types.txt")
    return p.parse_args()


def load_tau(path: Path) -> dict[int, list[int]]:
    out: dict[int, list[int]] = {}
    for line in path.read_text().splitlines():
        z = [int(x) for x in line.split()]
        out[z[0]] = z[1:]
    return out


def q_matrix(states: list[int], choices: list[int], promoted: list[bool]) -> list[list[F]]:
    q: list[list[F]] = [[F(0)] * 18 for _ in range(5)]
    for i in range(5):
        branch, node = STATES[states[i]]
        for a in range(18):
            v = F(1)
            if branch == a // 9:
                v -= BETA[i]
            if node == a // 3:
                v -= BETA[i]
            if promoted[i] and choices[i] == a:
                v -= BETA[i]
            q[i][a] = v
    return q


def functional(weights: list[int], states: list[int], choices: list[int], promoted: list[bool]) -> F:
    q = q_matrix(states, choices, promoted)
    tau = [F(x, 27) for x in weights]
    total = F(0)

    for a in range(18):
        comp = F(1)
        for i in range(5):
            comp *= q[i][a]
        total += tau[a] * (1 - comp)

    for mask in range(1, 32):
        support = [i for i in range(5) if (mask >> i) & 1]
        beta_t = F(1)
        for i in support:
            beta_t *= BETA[i]
        outside: list[F] = []
        for a in range(18):
            value = F(1)
            for i in range(5):
                if i not in support:
                    value *= q[i][a]
            outside.append(value)

        if len(support) >= 2:
            total += beta_t * sum(tau[a] * outside[a] for a in range(18))
            total += beta_t * max(
                sum(tau[a] * outside[a] for a in range(18) if a // 9 == branch)
                for branch in range(2)
            )
            total += beta_t * max(
                sum(tau[a] * outside[a] for a in range(18) if a // 3 == node)
                for node in range(6)
            )

        skip_g3 = len(support) == 1 and promoted[support[0]]
        if not skip_g3:
            total += beta_t * max(tau[a] * outside[a] for a in range(18))

        total += beta_t * max(outside) / 27
    return total


def main() -> None:
    args = parse_args()
    tau = load_tau(args.tau)
    no_promotion = [False] * 5
    promote_three = [True, True, True, False, False]
    promote_five = [True] * 5
    no_choice = [-1] * 5

    checks: list[tuple[str, F, F]] = [
        ("stage1_type0", functional(tau[0], [18, 12, 13, 8, 8], no_choice, no_promotion), F(598546, 601425)),
        ("stage1_type6", functional(tau[6], [18, 8, 12, 13, 8], no_choice, no_promotion), F(601190, 601425)),
        ("stage1_type7", functional(tau[7], [18, 8, 9, 12, 13], no_choice, no_promotion), F(601693, 601425)),
        ("stage1_type11", functional(tau[11], [18, 8, 12, 8, 13], no_choice, no_promotion), F(605556, 601425)),
        ("stage1_type13", functional(tau[13], [18, 8, 12, 8, 13], no_choice, no_promotion), F(605556, 601425)),
        ("stage2_type7", functional(tau[7], [18, 8, 9, 12, 13], [9, 0, 3, -1, -1], promote_three), F(597601, 601425)),
        ("stage2_type11", functional(tau[11], [18, 8, 12, 13, 12], [9, 0, 3, -1, -1], promote_three), F(200282, 200475)),
        ("stage2_type13", functional(tau[13], [18, 8, 12, 13, 12], [9, 0, 3, -1, -1], promote_three), F(200282, 200475)),
    ]

    ok = True
    for name, got, expected in checks:
        passed = got == expected
        ok &= passed
        print(f"{name}: got={got} expected={expected} pass={passed}")

    best: F | None = None
    arg: tuple[int, int] | None = None
    for c13 in range(-1, 18):
        for c17 in range(-1, 18):
            value = functional(
                tau[13], [18, 8, 12, 13, 12], [9, 0, 3, c13, c17], promote_five
            )
            if best is None or value > best:
                best, arg = value, (c13, c17)
    assert best is not None and arg is not None
    headroom_expected = F(199724, 200475)
    headroom_ok = best == headroom_expected and arg == (3, 3)
    ok &= headroom_ok
    print(f"type13_extra_13_17: max={best} expected={headroom_expected} arg={arg} pass={headroom_ok}")
    print(f"global_gap={1-F(200282,200475)}")
    print(f"extra_promotion_witness_gap={1-best}")
    print("STATUS: " + ("PASS" if ok else "FAIL"))
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
