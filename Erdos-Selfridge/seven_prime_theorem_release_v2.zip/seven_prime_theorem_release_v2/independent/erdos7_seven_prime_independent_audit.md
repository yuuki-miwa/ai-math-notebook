# Independent audit of the Seven-Prime Theorem certificate

Date: 2026-09-04

## Verdict

**PASS, with normal research-level qualifications.**

I found no remaining mathematical or implementation error in the corrected seven-prime certificate. The earlier positive-leaf tail issue is genuinely repaired by the all-leaf tail bound. I independently reconstructed the finite optimization from the mathematical definitions, generated the 3-adic orbit types without using the supplied representative file, and reproduced the exact Stage-I and Stage-II extrema with a separate Python/Numba implementation.

The resulting theorem supported by the audit is:

> If a covering system has distinct odd moduli and `N` is their least common multiple, then `omega(N) >= 7`.

This statement has no cutoff on `N` and no restriction on prime-power exponents.

I would still recommend external specialist review before publication, but after this audit I no longer see an internal reason to label the result merely as a numerical conjecture. It is an exact computer-assisted proof candidate whose mathematical reduction and finite certificate both survive an independent reconstruction.

---

## A. Mathematical reduction audit

### A1. Divisor completion — valid

If a distinct covering with LCM `N` exists, adding one residue class for each unused divisor `d|N`, `d>1`, preserves coverage and distinctness of moduli. Therefore it is legitimate to disprove the larger divisor-complete relaxation.

Padding prime exponents is also monotone: the old moduli still divide the enlarged LCM and divisor completion only adds possibilities.

### A2. Pure-tower removal and CRT survivor — valid

For each prime `p^e || N`, remove all pure classes modulo `p,...,p^e`. Their complement in the `p` coordinate is `S_p`. Because pure classes depend on one prime coordinate only, the total survivor is exactly the CRT product `prod_p S_p`.

The union bound gives

`|S_p| >= ((p-2)p^e+1)/(p-1)`.

A fixed residue modulo `p^f` contains at most `p^(e-f)` points, hence its normalized mass on `S_p` is at most

`c_{p,e}(f)=p^(e-f)/u_{p,e}`.

Summing in `f` gives

`b_p(e)=(p^e-1)/((p-2)p^e+1) < 1/(p-2)=beta_p`.

All inequality directions are correct. Replacing finite `b_p(e)` by `beta_p` enlarges the relaxation.

### A3. The 3-adic survivor polytope — valid

Hough--Nielsen supplies `3|N` for an odd distinct covering. After the pure class modulo 3 kills one mod-3 branch, 18 mod-27 leaves remain potentially live.

A single mod-27 leaf has normalized mass `<2/27`, so the actual profile lies in

`K3={tau_a >=0, tau_a <=2/27, sum tau_a=1}`.

Using the closure with `<=2/27` is conservative. Its vertices have scaled weights `(2 x 13, 1 x 1, 0 x 4)`, giving `18*C(17,4)=42840` labelled vertices.

### A4. Axis skeleton abstraction — valid

For a fixed non-3 prime `p` and 3-adic level `g`, every exponent `f` supplies exactly one axis class `3^g p^f`. Grouping these by their 3-adic node and taking the union of their `p`-slices gives new exposed masses `x^(g)_{p,v}`. Even though slices at different 3-nodes may overlap in the `p` coordinate, summing node-union masses is bounded by the sum of the individual slice capacities, hence

`sum_v x^(g)_{p,v} <= beta_p`.

Disjointizing each level against its ancestors makes the uncovered `p`-fraction on leaf `a`

`q_{p,a}=1-sum_g x^(g)_{p,ancestor_g(a)}`.

Conditional on the 3-leaf, axis events for distinct non-3 primes depend on independent CRT coordinates. Therefore the skeleton complement is exactly `prod_p q_{p,a}`. This is the key reason only aggregate axis masses, rather than slice shapes, are needed.

### A5. Residual clipping — valid

For non-3 support `T`, summing capacities over all exponent tuples factorizes and is at most

`B_T=prod_{p in T} beta_p`.

On coordinates outside `T`, a residual class imposes no condition, so intersecting with the skeleton complement contributes exactly the corresponding `q` factors. Ignoring skeleton overlap on coordinates inside `T` is conservative.

For 3-adic exponents `g=0,1,2,3`, maximizing the weighted survivor mass over the appropriate whole space / live branch / mod-9 node / mod-27 leaf correctly upper-bounds arbitrary residue placement for every exponent tuple.

For `g>=4`,

`sum_{g>=4} c_3(g) < sum_{g>=4} 2/3^g = 1/27`.

The corrected tail

`(B_T/27) max_a R_{T,a}`

is valid and deliberately allows all 18 leaves. This removes the discontinuous `tau_a>0` condition in the earlier draft.

### A6. Separate convexity and vertex reduction — valid after correction

For one axis simplex block, the skeleton term is affine and each residual term is a maximum of affine functions. The corrected tail is also a maximum of affine functions. Thus the full bound is convex in each axis block separately.

For `tau`, the skeleton and `g=0` terms are linear, the `g=1,2,3` terms are maxima of linear forms, and the corrected tail is independent of `tau`. Hence the bound is convex in `tau`.

A convex function on a compact polytope has a maximum at a vertex. Replacing blocks one at a time therefore justifies the product-of-simplex endpoint enumeration.

### A7. Promotion lemma — valid

Moving a residual family into the exact skeleton cannot increase the bound: the old residual union bound dominates the exact newly added union, and every later clipped complement shrinks. Algebraically this remains true for the relaxed axis variables, because the skeleton increment from a promoted singleton family is bounded by the Stage-I singleton residual term.

Therefore Stage-I states already below 1 do not need deeper refinement.

### A8. Worst six-prime support reduction — valid

The abstract feasible region is monotone in each budget `beta_p`. Since `beta_p=1/(p-2)` decreases with `p`, the worst five non-3 budgets are those of `5,7,11,13,17`. Adding missing prime coordinates is also a relaxation. Hence excluding `{3,5,7,11,13,17}` excludes every support with six or fewer primes.

---

## B. Independent finite-certificate audit

### B1. Independent orbit generation

I generated every depth-3 `tau` vertex directly from the choice of one weight-1 leaf and four weight-0 leaves, then canonicalized the rooted 3-adic tree bottom-up. I did not read the supplied representative file.

Result:

- labelled vertices: **42840**;
- rooted-tree orbits: **28**;
- orbit-size multiset:

`[72,108,108,108,162,162,162,324,324,324,486,486,648,972,972,972,1458,1458,1944,1944,1944,2916,2916,2916,2916,4374,5832,5832]`.

This exactly matches the supplied audit data.

### B2. Independent Stage-I evaluator

I implemented the corrected functional independently in Python/Numba. Rather than reading the C++ state tables, it reconstructs each level-1/level-2 choice from `(parent,node)` and evaluates the mathematical score directly.

The independent canonical ordering of the 28 tau orbits differs from the supplied type numbering. Therefore I compared the multiset of pairs

`(exact Stage-I maximum numerator, number of states >= 601425)`.

The 28-pair multisets agree **exactly**.

The only three critical orbit types in the independent ordering have:

- `(605556, 1314)`;
- `(601693, 30)`;
- `(605556, 1161)`.

These are precisely the supplied corrected critical data, up to orbit relabelling.

### B3. Independent Stage-II evaluator

For each critical orbit I recomputed the survivors and independently enumerated all `19^3` selective level-3 promotions for primes `5,7,11` using a full 18-leaf representation.

Exact results:

- 30-state orbit: `597601/601425`;
- 1161-state orbit: `600846/601425`;
- 1314-state orbit: `600846/601425`.

Thus the independent global maximum is

`600846/601425 = 200282/200475 < 1`.

The exact gap is

`1 - 200282/200475 = 193/200475`.

### B4. Independent rational recomputation of the worst state

As an additional scaling check, I took the independently found worst Stage-II states and evaluated the displayed mathematical formula using Python `Fraction`, with no common-denominator integer encoding.

The result was exactly

`200282/200475`,

and multiplication by the certificate denominator `601425` gives numerator `600846` exactly.

This rules out a hidden scaling mismatch between the integer scanner and the stated functional.

---

## C. Conclusion

After the corrected all-leaf tail repair, I find the proof chain internally consistent and the exact finite optimization independently reproducible.

Subject to the published Hough--Nielsen input, the audited argument supports

`omega(N) >= 7`

for the LCM of any distinct odd covering system.

No finite LCM range and no bounded exponent assumption is used.

### Remaining non-fatal desiderata

1. External expert review of the abstraction, especially the axis-disjointization and residual-clipping lemmas.
2. A polished theorem-proof writeup separating analytic lemmas from the certificate tables.
3. Optionally, a proof-assistant or interval-independent formal checker for the finite certificate.
4. A separate literature/priority audit before making a novelty claim.

None of these is currently a known mathematical gap in the corrected proof.
