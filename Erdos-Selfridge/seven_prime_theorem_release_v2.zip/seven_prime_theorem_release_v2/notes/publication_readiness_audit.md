# Seven-Prime theorem candidate — publication readiness audit v2

**監査日:** 2026年9月4日  
**判定:** **外部専門家レビューへ進める。対外表現は theorem candidate のまま。**

## 1. 現在の主張

distinct odd covering system が存在し、その法の最小公倍数を \(N\) とすると

\[
\omega(N)\ge7.
\]

LCM cutoffもprime-power exponentの上限もない。文献監査の修正により、正しい歴史的位置づけは Berger–Felzenbaum–Fraenkel (1987) の一般下界6から7への改善である。

## 2. 計算層の現在の強さ

- 42,840 labelled profile vertices、28 rooted-tree orbits
- Stage I: 114,354,828 exact integer evaluations
- critical states: 30, 1,161, 1,314、計2,505
- Stage II: 17,181,795 exact integer evaluations
- global maximum \(200282/200475\)
- exact gap \(193/200475\)

主C++実装に加えて、二つの異なる再構成が一致した。今回追加した第三のformula-only実装は、主実装の評価コードを読まず、18 leavesを最後まで保持し、mod-9集約もGray-code subset productsも使わない。全28 Stage-I maxima、survivorの5状態列、全Stage-II maxima、orbit decomposition、Fraction再評価が一致した。

Promotion Lemmaについては、解析的証明とは別に、1,680 shallow states × \(19^3\)=11,523,120 comparisonsの回帰テストを追加し、違反ゼロ・最大 \(F_3-F_2=0\) を得た。

## 3. Claude監査から採用した重要修正

### 文献

BFF I (1986) とBFF II (1987)を追加した。BFF Iは5 primesを強制し、BFF IIは5-prime extremal caseを排除して6 primesを強制する。論文の新規性説明を「5→7」ではなく「6→7」に全面修正した。

### K3の実現可能性

pure classes modulo 3,9,27のnested/disjoint構造から、live leaf countは \(L\in\{14,15,17,18\}\) であり、

\[
\tau_a<\frac{2}{2L-1}.
\]

broad K3 vertexがclosure-realizableであるには、4つのzero leavesが「mod-9 node丸ごと3 leaves + 追加1 leaf」でなければならない。critical typesでは7と13が実現可能、11は不可能。global maximumはtype 13でも達成されるため、極値は不可能profileだけのartifactではない。

### marginの解釈

表示されたtype-13 worst witnessで13,17もlevel-3 promoteすると、追加2 blocks上の最大は \(199724/200475\)、gapは \(751/200475\) になる。これは全域certificateではなくwitness diagnosticだが、薄い最終gapがpromotionを5,7,11で止めた設計にも由来することを示す。

### 実装

- Stage-II type listを `(7,11,13)` のhardcodeから、nonempty survivor filesによる動的導出へ変更。
- default Stage-I workerを1にして移植性を優先。
- manifest PASSを「有限列挙の再現」であり「解析的正しさそのもの」ではないと明記。
- survivor比較をraw fileのbyte identityではなく、完全な5状態列の一致と正確に記述。

## 4. 外部レビューで残る中心リスク

1. axis-familyのancestor disjointization
2. residual classesのoutside-support clipping
3. all-18-leaf deep tail
4. separate convexityからproduct verticesへの帰着
5. promotion lemma
6. support monotonicityによるextremal template帰着

計算層を疑う具体的理由は現在ほぼない。残る本体は解析的interfaceとpriority確認である。

## 5. 最終判断

\[
\boxed{\text{Strong GO for specialist circulation; not yet GO for an unconditional public theorem claim.}}
\]

最初に送る相手にはBFF87からの改善であること、第三実装まで一致していること、type13極値がprofile構造上実現可能であることを明示する。
