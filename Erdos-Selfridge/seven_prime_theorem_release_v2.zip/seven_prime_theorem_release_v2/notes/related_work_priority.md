# Related work and priority note for the seven-prime obstruction

**Internal note — revised 4 September 2026**

## 1. Correct unrestricted baseline

The classical unrestricted lower bound is not five primes but six.

- Berger–Felzenbaum–Fraenkel (1986) proved the necessary condition
  \[
  \prod_i\frac{p_i-1}{p_i-2}-\sum_i\frac1{p_i-2}>2,
  \]
  for the distinct prime divisors of the LCM. They observed that this forces at least five primes.
- Berger–Felzenbaum–Fraenkel (1987) strengthened the condition and explicitly ruled out the extremal five-prime case \(3,5,7,11,13\), proving that at least six distinct primes are necessary.

Thus the present candidate should be positioned as

\[
\boxed{6\longrightarrow7}
\]

in the general arbitrary-prime-power setting. The appearance of the same limiting quantities \(1/(p-2)\) in the present pure-tower budgets makes these references especially important.

## 2. Other established comparison points

- Hough–Nielsen prove that every distinct covering system contains a modulus divisible by 2 or 3; hence 3 divides the LCM in the odd case.
- BBMST obtain the further odd-case alternative: some modulus is divisible by 9, or one modulus is divisible by 3 and another by 5. This does not simply force 5 because of the separate 9 branch.
- Guo–Sun show that in the square-free odd setting a hypothetical LCM has at least 22 distinct prime factors.
- BBMST later rule out the square-free odd case completely.
- Mian–Siddique (arXiv:2607.25628) give a Lean-kernel-checked exclusion `lcm > 10000` while explicitly describing the general odd distinct covering problem as open.
- Bispels et al. (arXiv:2507.16135; Discrete Mathematics 349 (2026), Article 115013) study a repeated-modulus variant, not the unrestricted seven-prime bound claimed here.

## 3. Nearby recent web claim

A recent unrefereed web draft advertises a six-prime lower bound. Since BFF II already proved the unrestricted six-prime lower bound in 1987, that web claim should not be treated as the historical benchmark without a careful comparison of hypotheses. It is not needed in the manuscript’s core related-work discussion.

## 4. Priority finding

The bounded search carried out for this release did not locate a refereed paper or arXiv preprint proving

\[
\omega(N)\ge7
\]

for arbitrary prime-power exponents in a distinct odd covering system. This is evidence of novelty, not a priority guarantee. The statement should be sent directly to covering-systems specialists, with BFF86 and BFF87 named up front.

## 5. Safe novelty language

Before specialist replies:

> Berger–Felzenbaum–Fraenkel proved the classical unrestricted lower bound of six prime divisors. We did not locate an arbitrary-exponent seven-prime obstruction in a bounded literature search.

Avoid:

> This is the first proof / definitive best-known bound.

## 6. Core references

- M. A. Berger, A. Felzenbaum, A. S. Fraenkel, *Necessary condition for the existence of an incongruent covering system with odd moduli*, Acta Arith. 45 (1986), 375–379.
- M. A. Berger, A. Felzenbaum, A. S. Fraenkel, *Necessary condition for the existence of an incongruent covering system with odd moduli II*, Acta Arith. 48 (1987), 73–79.
- R. D. Hough, P. P. Nielsen, *Covering systems with restricted divisibility*, Duke Math. J. 168 (2019), 3261–3295.
- S. Guo, Z.-W. Sun, *On odd covering systems with distinct moduli*, Adv. in Appl. Math. 35 (2005), 182–187.
- P. Balister, B. Bollobás, R. Morris, J. Sahasrabudhe, M. Tiba, *The Erdős–Selfridge problem with square-free moduli*, Algebra Number Theory 15 (2021), 609–626.
