# Technical review brief: a seven-prime obstruction for distinct odd covering systems

**Author:** Yuuki Miwa  
**Status:** exact computer-assisted proof candidate

## Claim and historical position

Let \(\mathcal C\) be a covering system with pairwise distinct odd moduli greater than one, and let \(N\) be their least common multiple. The manuscript claims

\[
\omega(N)\ge7.
\]

There is no bound on \(N\) and no bound on the prime-power exponents. Berger–Felzenbaum–Fraenkel proved the classical unrestricted lower bound \(\omega(N)\ge6\) in 1987, so the claimed contribution is the step from six to seven.

## Proof architecture

1. Complete the modulus set to all nontrivial divisors of \(N\).
2. Remove the one class modulo each pure power \(p,p^2,\ldots,p^{e_p}\). On the one-prime survivor, the total normalized capacity of all positive \(p\)-power slices is strictly less than \(1/(p-2)\).
3. Use Hough–Nielsen to force \(3\mid N\), and resolve the two surviving mod-3 branches to 18 leaves modulo 27.
4. Expose the two-prime axis families \(3^gp^f\) in a hierarchical skeleton. Conditional on a 3-adic leaf, the complement is an exact product across the non-3 CRT coordinates.
5. Bound each remaining mixed support \(T\) after clipping only by skeleton coordinates outside \(T\).
6. Use a corrected all-leaf bound for the deeper 3-adic tail, and prove separate convexity in the profile and every axis-allocation block.
7. Reduce all supports of at most six primes to the extremal budget template \(\{3,5,7,11,13,17\}\).
8. Verify the resulting finite functional exactly.

## Exact finite certificate

- 42,840 labelled mod-27 profile vertices, reduced to 28 rooted-tree orbits.
- Stage I: \(28\cdot21^5=114,354,828\) integer evaluations.
- Only 2,505 shallow states remain critical.
- Stage II: \(2,505\cdot19^3=17,181,795\) integer evaluations.
- Common denominator: 601425.
- Exact maximum: \(600846/601425=200282/200475<1\).
- Exact gap: \(193/200475\).

The primary C++ calculation and two independently structured reconstructions agree. The newest formula-only reconstruction carries all 18 leaves explicitly, reproduces the complete five-coordinate survivor-state sequences, and includes a deterministic 11,523,120-comparison regression test of the promotion implementation.

## Profile-relaxation clarification

The broad profile polytope permits some vertices not attainable from nested/disjoint pure 3-power classes. Among the critical types, type 11 is not closure-realizable, while types 7 and 13 are. Since type 13 also attains the global maximum, the final maximum is not supported solely by an impossible profile.

## Highest-value review questions

1. Is the pure-tower capacity reduction valid uniformly in all exponents?
2. Is the level-wise axis budget valid after ancestor disjointization, including reuse of the budget at distinct 3-adic levels?
3. Does outside-support clipping account conservatively for every remaining divisor class exactly once?
4. Is the deep-tail term correctly bounded by \((B_T/27)\max_aR_{T,a}\) over all 18 leaves?
5. Are the functionals separately convex in every block, permitting product-vertex reduction?
6. Does the algebraic promotion lemma justify refining only shallow vertices with value at least one?
7. Is componentwise budget monotonicity sufficient to reduce every six-prime support to \(\{3,5,7,11,13,17\}\)?
8. Is an arbitrary-exponent lower bound \(\omega(N)\ge7\) already known beyond BFF’s six-prime theorem?

## Suggested review order

Read Sections 2–8 and `paper/certificate_specification_v2.md` before inspecting source code. Then run:

```bash
bash scripts/run_primary.sh
python3 independent/third_formula_reimplementation/run_third_independent.py
```
