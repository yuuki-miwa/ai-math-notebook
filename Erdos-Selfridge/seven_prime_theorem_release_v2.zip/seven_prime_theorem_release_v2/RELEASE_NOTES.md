# Seven-Prime theorem candidate — release notes v2

**Release:** v2 specialist-review package  
**Date:** 4 September 2026

## Included result

The package supports the exact computer-assisted theorem candidate that a distinct odd covering system, if one exists, has an LCM with at least seven distinct prime divisors. The correct established unrestricted comparison is BFF’s 1987 lower bound of six prime divisors.

## Exact certificate

- 42,840 labelled mod-27 profile vertices;
- 28 rooted-tree orbits;
- 114,354,828 Stage-I integer evaluations;
- 2,505 critical shallow states;
- 17,181,795 Stage-II integer evaluations;
- exact global maximum `200282/200475`;
- exact gap `193/200475`.

## Changes from v1

- updated manuscript to `paper/seven_prime_theorem_draft_v3.md`;
- added BFF86 and BFF87 and corrected the historical positioning from an unspecified new obstruction to a 6→7 improvement;
- added `paper/certificate_specification_v2.md`;
- integrated a third formula-only reconstruction under `independent/third_formula_reimplementation/`;
- added complete survivor-state-sequence comparison, independent orbit regeneration, exact Fraction checks, and promotion regression;
- added `scripts/k3_actual_profile_audit.py` and the actual-profile refinement of the broad K3 relaxation;
- recorded that types 7 and 13 are closure-realizable while type 11 is not;
- recorded a witness-specific extra-promotion value `199724/200475`;
- made Stage-II type detection dynamic rather than hardcoded;
- made one worker the portable default;
- clarified that manifest agreement establishes reproducibility of the finite enumeration, not correctness of the analytic lemmas;
- verified the existence and bibliography of arXiv:2607.25628 and arXiv:2507.16135 / Discrete Mathematics 349 (2026), Article 115013.

## Status

This remains a review package. The finite computation has three agreeing code paths, but the analytic reduction still needs specialist external scrutiny before the theorem is presented without the word “candidate.”
