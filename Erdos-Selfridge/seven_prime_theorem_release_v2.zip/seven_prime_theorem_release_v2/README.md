# Seven-Prime Theorem exact-certificate release v2

This directory accompanies the working manuscript

> **A seven-prime obstruction for distinct odd covering systems**.

The candidate theorem is:

> If a covering system has distinct odd moduli greater than one and `N` is the least common multiple of its moduli, then `omega(N) >= 7`.

Berger–Felzenbaum–Fraenkel proved the classical unrestricted lower bound `omega(N) >= 6` in 1987. The present candidate therefore claims an improvement from six to seven. The result has no least-common-multiple cutoff and no bounded-exponent assumption.

The analytic reduction leaves a finite exact optimization whose global value is

```text
200282/200475 < 1
```

with exact gap

```text
193/200475.
```

This is a **research verification package**, not a substitute for external mathematical review.

## Directory map

```text
paper/seven_prime_theorem_draft_v3.md        current working paper
paper/certificate_specification_v2.md        formula-to-code specification
notes/expert_review_brief.md                 compact specialist review request
notes/publication_readiness_audit.md         current internal readiness decision
notes/related_work_priority.md               historical positioning and priority note
docs/literature_audit.md                     primary-source literature check
docs/response_to_claude_audit.md            disposition of the independent audit
src/stage1_exact.cpp                         primary Stage-I integer enumeration
src/stage2_exact.cpp                         primary Stage-II integer enumeration
src/tau3_orbit_audit.py                      primary orbit audit
data/tau3_orbit_types.txt                    canonical profile representatives
expected/certificate_manifest.json           retained expected values
scripts/run_primary.sh                       compile, enumerate, and verify
scripts/verify_outputs.py                     manifest comparison
scripts/verify_worst_states_fraction.py       exact Fraction formula check
scripts/k3_actual_profile_audit.py            actual-profile/relaxation audit
scripts/strict_compile.sh                     warnings-as-errors compiler audit
independent/                                  two independently structured reconstructions
logs/                                         retained successful runs
work/                                         generated primary survivor lists
SHA256SUMS                                    release checksums
```

## Requirements

- a C++17 compiler (`g++` by default);
- Python 3.10 or later;
- Bash for the small shell entry points.

The primary verification requires no third-party Python packages. The older Python/Numba reconstruction requires NumPy and Numba. The third formula-only reconstruction requires only Python and a C++17 compiler.

## Full primary verification

From the release root:

```bash
./scripts/run_primary.sh
```

The default is one Stage-I worker for portability. Parallelism is optional:

```bash
CXX=clang++ JOBS=4 ./scripts/run_primary.sh
```

The Stage-II type list is **not hardcoded**. It is derived from the nonempty Stage-I survivor files; `verify_outputs.py` then checks that the resulting types, counts, and maxima equal the manifest.

A successful run reports:

```text
Seven-Prime exact-certificate verification
=========================================
Stage I records: 28/28
Stage II records: 3/3
Global maximum: 200282/200475 = 0.9990372864446938
Exact gap: 193/200475 = 0.0009627135553061
STATUS: PASS
```

The `PASS` means that the finite enumeration reproduced the retained manifest. It does **not** by itself establish the analytic reductions in Lemmas 2.1–8.1.

## What the exhaustive search checks

Stage I checks

```text
28 * 21^5 = 114,354,828
```

profile/axis vertices. Only profile types 7, 11 and 13 have shallow values at least one, with respectively 30, 1,161 and 1,314 critical states.

Stage II checks

```text
(30 + 1,161 + 1,314) * 19^3 = 17,181,795
```

promotions of the level-three axis blocks for primes 5, 7 and 11. Every comparison uses an integer numerator with common denominator `601425`.

## Independent reconstructions

### Python/Numba reconstruction

The top-level `independent` directory retains an implementation using a different data representation and independently generated profile orbits. It requires NumPy and Numba.

### Third formula-only reconstruction

The directory `independent/third_formula_reimplementation` contains a C++/Python implementation written from formulas (6.1) and (6.2), without using the primary evaluation source. It carries all 18 leaves explicitly and forms outside-support products directly.

Run it with:

```bash
python3 independent/third_formula_reimplementation/run_third_independent.py
```

It checks all 28 Stage-I maxima, the complete five-coordinate survivor-state sequences, the three Stage-II maxima, the orbit decomposition, exact rational extrema, and a promotion regression comprising 11,523,120 comparisons at the default settings.
Retained outputs and independently generated survivor lists are stored under `logs/third_independent/`.

## Additional structural checks

```bash
python3 scripts/k3_actual_profile_audit.py
```

This records that the broad profile polytope is conservative: among the three critical types, types 7 and 13 are closure-realizable from nested/disjoint pure 3-power classes, whereas type 11 is not. Because type 13 also attains the global maximum, the final maximum is not solely an artifact of an impossible broad-polytope vertex.

The exact rational checker also records a witness-specific headroom diagnostic: additionally promoting the 13- and 17-level-three axes at the displayed type-13 worst state lowers the maximum over those two new blocks to `199724/200475`. This is not part of the exhaustive proof certificate.

## Trust boundary

The finite enumeration is exact once the certificate functional is accepted. The mathematical points most deserving external review are:

- pure-tower capacity reduction;
- incremental disjointization of axis families;
- outside-support clipping of residual mixed classes;
- the all-leaf deep-tail estimate;
- separate convexity and the product-vertex principle;
- the promotion lemma;
- monotonic reduction to `{3,5,7,11,13,17}`.

These are stated in `paper/seven_prime_theorem_draft_v3.md`, specified computationally in `paper/certificate_specification_v2.md`, and itemized in `docs/external_review_checklist.md`.
