#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

using i64 = std::int64_t;
namespace fs = std::filesystem;

struct PState { int parent; int node; };

struct Options {
    int type = -1;
    fs::path tau_file = "data/tau3_orbit_types.txt";
    fs::path survivor_dir = "work";
};

[[noreturn]] static void usage(const char* argv0) {
    std::cerr << "usage: " << argv0
              << " TYPE [--tau FILE] [--survivor-dir DIR]\n";
    std::exit(2);
}

static Options parse_args(int argc, char** argv) {
    if (argc < 2) usage(argv[0]);
    Options o;
    try { o.type = std::stoi(argv[1]); }
    catch (...) { usage(argv[0]); }
    for (int i=2;i<argc;++i) {
        const std::string a=argv[i];
        if (a=="--tau" && i+1<argc) o.tau_file=argv[++i];
        else if (a=="--survivor-dir" && i+1<argc) o.survivor_dir=argv[++i];
        else usage(argv[0]);
    }
    return o;
}

static std::array<int,18> read_tau_type(const fs::path& path,int wanted) {
    std::ifstream in(path);
    if (!in) throw std::runtime_error("cannot open tau file: "+path.string());
    int id;
    while (in>>id) {
        std::array<int,18> tmp{};
        for (int& x:tmp) if (!(in>>x)) throw std::runtime_error("malformed tau file");
        if (id==wanted) return tmp;
    }
    throw std::runtime_error("tau type not found: "+std::to_string(wanted));
}

struct Evaluator {
    static constexpr int R=5,L=18,MASKS=32,ALL=31;
    static constexpr std::array<int,R> d{3,5,9,11,15};
    static constexpr i64 D=3LL*5*9*11*15;
    static constexpr i64 DEN=27*D;
    std::array<PState,21> states{};
    int base[R][L]{};
    std::array<int,L> tau{};

    Evaluator() {
        int k=0;
        for (int parent=-1;parent<=1;++parent)
            for (int node=-1;node<6;++node)
                states[k++]={parent,node};
    }

    void set_tau(const std::array<int,L>& w) { tau=w; }

    void init(const std::array<int,R>& s) {
        for (int i=0;i<R;++i)
            for (int a=0;a<L;++a) {
                const int node=a/3;
                const int hits=(states[s[i]].parent==node/3)
                              +(states[s[i]].node==node);
                base[i][a]=d[i]-hits;
            }
    }

    i64 score(int c0,int c1,int c2) const {
        const int choice[R]{c0,c1,c2,-2,-2};
        const bool promoted[R]{true,true,true,false,false};
        int q[R][L]{};
        for (int i=0;i<R;++i)
            for (int a=0;a<L;++a)
                q[i][a]=base[i][a]-((promoted[i]&&choice[i]==a)?1:0);

        i64 subset_products[L][MASKS]{};
        for (int a=0;a<L;++a) {
            subset_products[a][0]=1;
            for (int m=1;m<MASKS;++m) {
                const int bit=__builtin_ctz(static_cast<unsigned>(m));
                subset_products[a][m]=subset_products[a][m&(m-1)]*q[bit][a];
            }
        }

        i64 total=0;
        for (int a=0;a<L;++a)
            total+=static_cast<i64>(tau[a])*(D-subset_products[a][ALL]);

        for (int T=1;T<MASKS;++T) {
            const int outside=ALL^T;
            const int support_size=__builtin_popcount(static_cast<unsigned>(T));
            i64 residual[L]{};
            for (int a=0;a<L;++a) residual[a]=subset_products[a][outside];

            if (support_size>=2) {
                i64 g0=0,branches[2]{0,0},nodes[6]{0,0,0,0,0,0},g3=0;
                for (int a=0;a<L;++a) {
                    const i64 v=static_cast<i64>(tau[a])*residual[a];
                    g0+=v;
                    branches[a/9]+=v;
                    nodes[a/3]+=v;
                    g3=std::max(g3,v);
                }
                i64 g2=*std::max_element(nodes,nodes+6);
                total += g0 + std::max(branches[0],branches[1]) + g2 + g3;
            } else {
                const int bit=__builtin_ctz(static_cast<unsigned>(T));
                if (!promoted[bit]) {
                    i64 g3=0;
                    for (int a=0;a<L;++a)
                        g3=std::max(g3,static_cast<i64>(tau[a])*residual[a]);
                    total+=g3;
                }
            }

            i64 tail=0;
            for (int a=0;a<L;++a) tail=std::max(tail,residual[a]);
            total+=tail;
        }
        return total;
    }
};

int main(int argc,char**argv) {
    try {
        const Options opt=parse_args(argc,argv);
        const auto tau=read_tau_type(opt.tau_file,opt.type);
        const fs::path survivor_path=opt.survivor_dir /
            ("tau3_type_"+std::to_string(opt.type)+"_survivors.txt");
        std::ifstream in(survivor_path);
        if (!in) throw std::runtime_error("cannot open survivor file: "+survivor_path.string());

        Evaluator eval;
        eval.set_tau(tau);
        std::array<int,5> s{},best_state{};
        std::array<int,3> best_choice{};
        i64 old_score=0,best=-1;
        std::uint64_t cases=0,evaluations=0;
        const auto t0=std::chrono::steady_clock::now();

        while (in>>s[0]>>s[1]>>s[2]>>s[3]>>s[4]>>old_score) {
            ++cases;
            eval.init(s);
            for (int c0=-1;c0<18;++c0)
            for (int c1=-1;c1<18;++c1)
            for (int c2=-1;c2<18;++c2) {
                const i64 z=eval.score(c0,c1,c2);
                ++evaluations;
                if (z>best) {
                    best=z;
                    best_state=s;
                    best_choice={c0,c1,c2};
                }
            }
        }

        const auto t1=std::chrono::steady_clock::now();
        const i64 g=std::gcd(best,Evaluator::DEN);
        std::cout << "type " << opt.type
                  << " cases " << cases
                  << " evals " << evaluations
                  << " best " << best << '/' << Evaluator::DEN
                  << " reduced " << best/g << '/' << Evaluator::DEN/g
                  << " value " << std::setprecision(18)
                  << static_cast<long double>(best)/Evaluator::DEN
                  << " state";
        for (int x:best_state) std::cout << ' ' << x;
        std::cout << " choices";
        for (int x:best_choice) std::cout << ' ' << x;
        std::cout << " time " << std::chrono::duration<double>(t1-t0).count() << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "stage2_exact: " << e.what() << '\n';
        return 1;
    }
}
