#include <array>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using i64 = std::int64_t;
namespace fs = std::filesystem;

struct PState { int parent; int node; };

struct Options {
    int type = -1;
    fs::path tau_file = "data/tau3_orbit_types.txt";
    fs::path out_dir = "work";
};

[[noreturn]] static void usage(const char* argv0) {
    std::cerr << "usage: " << argv0
              << " TYPE [--tau FILE] [--out-dir DIR]\n";
    std::exit(2);
}

static Options parse_args(int argc, char** argv) {
    if (argc < 2) usage(argv[0]);
    Options o;
    try { o.type = std::stoi(argv[1]); }
    catch (...) { usage(argv[0]); }
    for (int i = 2; i < argc; ++i) {
        const std::string a = argv[i];
        if (a == "--tau" && i + 1 < argc) o.tau_file = argv[++i];
        else if (a == "--out-dir" && i + 1 < argc) o.out_dir = argv[++i];
        else usage(argv[0]);
    }
    return o;
}

static std::array<int, 18> read_tau_type(const fs::path& path, int wanted) {
    std::ifstream in(path);
    if (!in) throw std::runtime_error("cannot open tau file: " + path.string());
    int id;
    while (in >> id) {
        std::array<int,18> tmp{};
        for (int& x : tmp) {
            if (!(in >> x)) throw std::runtime_error("malformed tau file");
        }
        if (id == wanted) return tmp;
    }
    throw std::runtime_error("tau type not found: " + std::to_string(wanted));
}

int main(int argc, char** argv) {
    try {
        const Options opt = parse_args(argc, argv);
        const auto tv = read_tau_type(opt.tau_file, opt.type);
        fs::create_directories(opt.out_dir);

        constexpr int R = 5;
        constexpr int L = 6;
        constexpr int MASKS = 32;
        constexpr int ALL = 31;
        constexpr std::array<int,R> d{3,5,9,11,15};
        constexpr i64 D = 3LL*5*9*11*15;
        constexpr i64 DEN = 27*D;
        static_assert(DEN == 601425);

        std::array<int,L> agg{};
        std::array<int,L> mx{};
        for (int j = 0; j < L; ++j) {
            for (int c = 0; c < 3; ++c) {
                const int z = tv[3*j+c];
                agg[j] += z;
                if (z > mx[j]) mx[j] = z;
            }
        }

        std::vector<PState> states;
        states.reserve(21);
        for (int parent = -1; parent <= 1; ++parent)
            for (int node = -1; node < 6; ++node)
                states.push_back({parent,node});

        int fac[R][21][L]{};
        for (int i = 0; i < R; ++i)
            for (int s = 0; s < 21; ++s)
                for (int a = 0; a < L; ++a) {
                    const int hits = (states[s].parent == a/3)
                                   + (states[s].node == a);
                    fac[i][s][a] = d[i] - hits;
                }

        const fs::path survivor_path =
            opt.out_dir / ("tau3_type_" + std::to_string(opt.type) + "_survivors.txt");
        std::ofstream out(survivor_path);
        if (!out) throw std::runtime_error("cannot write: " + survivor_path.string());

        i64 subset_products[L][MASKS]{};
        std::uint64_t count = 0, survivors = 0;
        i64 best = -1;
        std::array<int,R> best_state{};
        const auto t0 = std::chrono::steady_clock::now();

        for (int s0=0;s0<21;++s0)
        for (int s1=0;s1<21;++s1)
        for (int s2=0;s2<21;++s2)
        for (int s3=0;s3<21;++s3)
        for (int s4=0;s4<21;++s4) {
            const int ss[R]{s0,s1,s2,s3,s4};
            ++count;
            for (int a=0;a<L;++a) {
                subset_products[a][0]=1;
                for (int m=1;m<MASKS;++m) {
                    const int bit = __builtin_ctz(static_cast<unsigned>(m));
                    subset_products[a][m] =
                        subset_products[a][m&(m-1)] * fac[bit][ss[bit]][a];
                }
            }

            i64 score=0;
            for (int a=0;a<L;++a)
                score += static_cast<i64>(agg[a]) * (D-subset_products[a][ALL]);

            for (int T=1;T<MASKS;++T) {
                const int outside=ALL^T;
                const int support_size=__builtin_popcount(static_cast<unsigned>(T));
                i64 residual[L]{};
                for (int a=0;a<L;++a) residual[a]=subset_products[a][outside];

                if (support_size>=2) {
                    i64 g0=0, branch0=0, branch1=0, g2=0;
                    for (int a=0;a<L;++a) {
                        const i64 v=static_cast<i64>(agg[a])*residual[a];
                        g0 += v;
                        (a<3 ? branch0 : branch1) += v;
                        if (v>g2) g2=v;
                    }
                    score += g0 + std::max(branch0,branch1) + g2;
                }

                i64 g3=0;
                for (int a=0;a<L;++a)
                    g3=std::max(g3,static_cast<i64>(mx[a])*residual[a]);
                score += g3;

                i64 tail=0;
                for (int a=0;a<L;++a) tail=std::max(tail,residual[a]);
                score += tail;
            }

            if (score>best) {
                best=score;
                best_state={s0,s1,s2,s3,s4};
            }
            if (score>=DEN) {
                ++survivors;
                out << s0 << ' ' << s1 << ' ' << s2 << ' '
                    << s3 << ' ' << s4 << ' ' << score << '\n';
            }
        }

        const auto t1=std::chrono::steady_clock::now();
        std::cout << opt.type << " best " << best << '/' << DEN
                  << " value " << std::setprecision(18)
                  << static_cast<long double>(best)/DEN
                  << " survivors " << survivors << " state";
        for (int x:best_state) std::cout << ' ' << x;
        std::cout << " count " << count
                  << " time " << std::chrono::duration<double>(t1-t0).count()
                  << " agg";
        for (int x:agg) std::cout << ' ' << x;
        std::cout << " mx";
        for (int x:mx) std::cout << ' ' << x;
        std::cout << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "stage1_exact: " << e.what() << '\n';
        return 1;
    }
}
