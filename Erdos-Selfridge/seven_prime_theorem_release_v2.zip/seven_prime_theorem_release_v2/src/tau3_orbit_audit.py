from itertools import combinations
from math import comb
from pathlib import Path

def canonical(w):
    groups = [tuple(sorted(w[3*j:3*j+3], reverse=True)) for j in range(6)]
    A = tuple(sorted(groups[:3], reverse=True))
    B = tuple(sorted(groups[3:], reverse=True))
    return min((A, B), (B, A))

orbits = {}
count = 0
for half in range(18):
    rem = [a for a in range(18) if a != half]
    for zeros in combinations(rem, 4):
        w = [2]*18
        w[half] = 1
        for z in zeros:
            w[z] = 0
        count += 1
        key = canonical(w)
        orbits[key] = orbits.get(key, 0) + 1

assert count == 18*comb(17,4) == 42840
keys = sorted(orbits)
assert len(keys) == 28

# Check the retained canonical representative file exactly.
expected = []
for idx, key in enumerate(keys):
    w = [x for branch in key for group in branch for x in group]
    expected.append((idx, tuple(w)))

seen = []
root = Path(__file__).resolve().parents[1]
with open(root / 'data/tau3_orbit_types.txt') as f:
    for line in f:
        z = list(map(int, line.split()))
        seen.append((z[0], tuple(z[1:])))
assert seen == expected

print('labelled_vertices', count)
print('tree_orbits', len(orbits))
print('representative_file_match', True)
print('orbit_sizes', sorted(orbits.values()))
