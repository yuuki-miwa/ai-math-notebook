# External review checklist for the Seven-Prime theorem candidate

## 1. Claim to review

Berger–Felzenbaum–Fraenkel proved the classical unrestricted lower bound of six distinct prime divisors. The candidate below claims the next step, from six to seven.


Let `C` be a covering system with pairwise distinct odd moduli greater than one, and let `N` be their least common multiple.  The manuscript claims

\[
\omega(N)\ge7.
\]

The prime-power exponents are unrestricted, and the computation does not impose an upper bound on `N`.

## 2. Analytic reduction

A reviewer should independently confirm the following chain.

### 2.1 Divisor completion

Adding one arbitrary class for every unused divisor of `N` is a monotone enlargement and preserves distinctness of moduli.

### 2.2 Pure-tower removal

For `p^e || N`, after removing the classes modulo `p,p^2,...,p^e`, verify

\[
|S_p|\ge\frac{(p-2)p^e+1}{p-1}
\]

and

\[
\sum_{f=1}^e\frac{p^{e-f}}{|S_p|}
\le\frac{p^e-1}{(p-2)p^e+1}
<\frac1{p-2}.
\]

Confirm that the survivor is the exact CRT product of the one-prime survivors.

### 2.3 The 3-adic profile

Using the Hough--Nielsen input, confirm that `3|N`; one mod-3 branch is deleted by the pure class.  Verify the bound `tau_a <= 2/27`, the profile polytope, its vertex description, and the 42,840 labelled count. Also verify the refinement `L in {14,15,17,18}`, `tau_a < 2/(2L-1)`, and the criterion that a broad-polytope vertex is closure-realizable only when its four zero leaves are one full mod-9 node plus one extra leaf.

### 2.4 Axis-family disjointization

For every exposed level and non-3 prime, reconstruct the unions of the `p`-coordinate slices belonging to the classes `3^g p^f`.  Confirm that ancestor disjointization gives pathwise disjoint increments and that the sum of node increments at one level is at most `beta_p=1/(p-2)`. Confirm that the budget may be reused at distinct levels because `3^g p^f` are distinct divisors as `g` varies.

### 2.5 Exact skeleton complement

Conditional on a 3-adic leaf, confirm that different non-3 axis families live on independent CRT coordinates, that the factors remain nonnegative (`1-3 beta_5=0` is the limiting case), and that the skeleton complement is exactly

\[
\prod_p q_{p,a}.
\]

### 2.6 Residual divisor accounting

Check that every non-pure divisor appears exactly once as

\[
3^g\prod_{p\in T}p^{f_p},
\]

with the stated restrictions on `(g,T)`, and that summing capacities over exponent tuples gives `B_T=prod_{p in T} beta_p`.

### 2.7 Outside-support clipping

For a residual support `T`, verify that clipping only with `p`-coordinates outside `T` is valid and conservative, and derive the level `g=0,1,2,3` maxima from the actual 3-adic survivor profile.

### 2.8 Deep tail

Confirm

\[
\sum_{g=4}^{e_3}c_{3,e_3}(g)<1/27
\]

and, crucially, that the conservative term is

\[
\frac{B_T}{27}\max_{a\in\mathcal L}R_{T,a}
\]

over all 18 leaves.  The older positive-mass-only maximum must not be reintroduced.

### 2.9 Separate convexity

Check convexity in the profile `tau` and separately in every axis-simplex block.  Verify that the tail is independent of `tau` and is a maximum of affine functions in an axis block.

### 2.10 Promotion

Confirm that moving a level-three singleton family from the residual union bound into the exact skeleton cannot increase the total upper bound, including its effect on the clipping of all later residual families.

### 2.11 Support monotonicity

For an actual support with at most five non-3 primes, sort its budgets, add zero-budget dummy coordinates if necessary, and enlarge componentwise to the budgets of `5,7,11,13,17`.  Confirm that this dominates every support of size at most six once `3` is forced.

## 3. Computational certificate

Run:

```bash
./scripts/run_primary.sh
```

Confirm all of the following.

- 42,840 labelled profile vertices and 28 rooted-tree orbits.
- 28 Stage-I records.
- The only critical profile types are 7, 11 and 13.
- Survivor counts are 30, 1,161 and 1,314.
- Stage-II evaluation counts are 205,770; 7,963,299; and 9,012,726.
- Stage-II maxima are `597601/601425`, `600846/601425`, and `600846/601425`.
- The reduced global maximum is `200282/200475`.
- The exact gap is `193/200475`.
- The exact-`Fraction` extremal-state checker passes.
- The third formula-only reconstruction matches all complete five-coordinate survivor-state sequences and all exact extrema.
- The K3 actual-profile audit reports critical types 7 and 13 realizable and type 11 unrealizable.

## 4. Suggested adversarial tests

1. Replace the representative file with one generated independently from all 42,840 profiles.
2. Randomly permute leaves by rooted-tree automorphisms and confirm invariant maxima.
3. Reimplement the residual score without subset-product dynamic programming.
4. Use arbitrary-precision integers throughout and compare exact outputs.
5. Exhaustively compare the compressed six-node Stage-I score with the full 18-leaf formula on random states.
6. Check promotion pointwise on every critical shallow state and every promoted vertex.
7. Run the third formula-only reconstruction and compare complete survivor-state sequences, not only counts.
8. Run the deterministic promotion regression; treat it as an implementation test, not the proof.
9. Verify the same result under a different compiler and optimization level.
10. Ask a covering-systems specialist to derive the functional from scratch before reading the source code.

## 5. Claim language pending review

Until the analytic reduction has been reviewed externally, the safest public description is:

> “An exact computer-assisted proof candidate showing that the least common multiple of a distinct odd covering system would have at least seven distinct prime divisors.”

After independent specialist acceptance of the analytic lemmas, the natural theorem statement is unconditional; the exhaustive finite part already uses exact arithmetic.
