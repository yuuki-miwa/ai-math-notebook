# Seven-Prime theorem consolidation report v2

**Date:** 4 September 2026

## Verdict

The seven-prime obstruction remains a strong external-review candidate. The finite certificate has survived a third formula-only reimplementation and a corrected literature audit. The correct historical contribution is an improvement from the BFF unrestricted lower bound six to seven.

## New checks in v2

- Reproduced all 28 Stage-I maxima and survivor counts with a third implementation written from formulas (6.1)/(6.2).
- Compared the complete five-coordinate survivor-state sequences for types 7, 11 and 13.
- Reproduced all three Stage-II maxima.
- Regenerated 42,840 profiles, 28 orbits, orbit-size sum 42,840, and rooted-tree group order 3,359,232.
- Rechecked exact fractions and the type-13 extra-promotion diagnostic.
- Ran 11,523,120 promotion-regression comparisons with zero violations.
- Classified closure-realizable broad-K3 vertices; critical types 7 and 13 are realizable, type 11 is not.
- Replaced the hardcoded Stage-II type list by dynamic detection from Stage-I survivor files.
- Changed default execution to one worker and clarified manifest semantics.

## Exact values unchanged

\[
M_6=\frac{200282}{200475},
\qquad
1-M_6=\frac{193}{200475}.
\]

The theorem certificate itself did not need numerical modification.

## Literature correction

BFF I gives at least five prime divisors. BFF II explicitly gives at least six. The manuscript now cites both and presents the candidate as a six-to-seven improvement. The previously highlighted recent six-prime web draft is no longer treated as the main comparison point.

## Remaining trust boundary

The code verifies the finite maximization after accepting the displayed functionals. External specialist review is still needed for the analytic reduction, especially axis disjointization, outside-support clipping, deep-tail accounting, separate convexity, promotion, and budget monotonicity.
