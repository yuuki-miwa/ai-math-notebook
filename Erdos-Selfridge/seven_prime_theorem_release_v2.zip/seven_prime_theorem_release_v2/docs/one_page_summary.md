# One-page summary: a seven-prime obstruction for odd distinct coverings

## Statement and baseline

Let `C` be a covering system with pairwise distinct odd moduli greater than one, and let `N` be their least common multiple. The candidate theorem is

\[
\boxed{\omega(N)\ge7}.
\]

The prime-power exponents are arbitrary and there is no finite cutoff on `N`. Berger–Felzenbaum–Fraenkel proved the classical unrestricted lower bound \(\omega(N)\ge6\); the claimed advance is therefore 6→7.

## Reduction

1. **Divisor completion.** Add one class for every unused divisor of `N`.
2. **Pure towers.** Remove the classes modulo `p,p^2,...,p^e`; all remaining positive `p`-power slices have total normalized capacity below `1/(p-2)`. The survivor is an exact CRT product.
3. **Prime 3 pivot.** Hough–Nielsen forces `3|N`. Resolve two live mod-3 branches to 18 leaves modulo 27. The broad profile polytope has 42,840 labelled vertices and 28 rooted-tree orbits.
4. **Hierarchical skeleton.** Expose `3^g p^f` axes at levels 1 and 2 for `p in {5,7,11,13,17}`. The level budget may be reused because different `g` give distinct divisors.
5. **Residual clipping.** A remaining support `T` is clipped only by skeleton coordinates outside `T`.
6. **Convexity.** The corrected deep tail maximizes over all 18 leaves. Separate convexity reduces to product vertices.
7. **Adaptive promotion.** Refine only shallow states with upper bound at least one, promoting level-3 axes at 5, 7 and 11.

## Exact certificate

Stage I performs \(28\cdot21^5=114,354,828\) integer evaluations. Three profile types survive, with 30, 1,161 and 1,314 states.

Stage II performs \(2,505\cdot19^3=17,181,795\) integer evaluations. Its exact maximum is

\[
\frac{600846}{601425}=\frac{200282}{200475}<1,
\]

with gap \(193/200475\).

## Reproduction

- primary portable C++17 enumerators;
- independent Python/Numba reconstruction;
- third formula-only C++/Python reconstruction carrying all 18 leaves explicitly;
- exact `Fraction` recomputation;
- complete five-coordinate survivor-state comparison;
- 11,523,120-comparison promotion regression;
- independent 42,840-to-28 orbit regeneration.

## Profile-relaxation audit

The broad K3 polytope allows impossible vertices. Among critical types, 7 and 13 are closure-realizable from nested/disjoint pure 3-power classes, while 11 is not. Type 13 also attains the final maximum, so the extremum is not solely an artifact of the broadened profile set.

## External review request

The finite arithmetic now has three agreeing code paths. The highest-value review is the analytic interface: pure-tower reduction, axis disjointization, outside-support clipping, all-leaf tail, separate convexity, promotion, and monotonic reduction to `{3,5,7,11,13,17}`.
