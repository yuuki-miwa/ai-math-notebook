# Response to the independent Claude audit

**Date:** 4 September 2026  
**Scope:** `files_seven_prime_claude.zip` and the accompanying review

## 1. Overall assessment

The audit materially strengthens the review package. Its formula-only implementation reproduces the finite certificate through a third computational route, and its literature correction changes the proper historical framing of the result. Every substantive point below has either been incorporated or explicitly qualified.

## 2. Finite reconstruction

Accepted and independently rerun.

The third implementation was written from the displayed Stage-I and Stage-II formulas rather than from the primary evaluator. It differs from the primary code by carrying all 18 leaves explicitly, avoiding the six-node aggregation, and forming every outside-support product directly. The following agree with the primary release and the manifest:

- 42,840 labelled profile vertices;
- 28 rooted-tree orbits, whose sizes sum to 42,840;
- rooted-tree group order 3,359,232;
- all 28 Stage-I maxima and survivor counts;
- the complete ordered five-coordinate survivor-state sequences for types 7, 11 and 13;
- all three Stage-II maxima;
- the exact reduced maximum `200282/200475` and gap `193/200475`.

The phrase “bit-for-bit identical survivor files” has been avoided in the revised release. The primary survivor files contain an additional numerator column, so the exact verified statement is that the ordered first five state coordinates agree on every row.

## 3. Promotion regression

Accepted as an implementation regression, not as the proof of the promotion lemma.

The retained run checks 1,680 deterministic shallow states against all `19^3` refinements, for 11,523,120 comparisons. It reports no instance of `F3 > F2` and maximum observed `max(F3)-F2 = 0`. The manuscript still proves promotion algebraically; the empirical test guards against a mismatch between that algebra and the evaluators.

## 4. Historical correction: BFF I and BFF II

Accepted, with one important strengthening after consulting the original BFF II paper.

BFF I (1986) proves the unrestricted necessary condition

\[
\prod_i\frac{p_i-1}{p_i-2}-\sum_i\frac1{p_i-2}>2,
\]

and observes that it forces at least five distinct prime divisors. BFF II (1987) goes further: it introduces a strengthened condition, rules out the extremal five-prime case `3,5,7,11,13`, and explicitly concludes that the number of prime divisors is at least six.

Accordingly, the present candidate is now framed throughout as an unrestricted improvement

\[
6\longrightarrow 7,
\]

not as a five-to-seven improvement. Both BFF papers and their DOIs have been added to the manuscript and review notes.

## 5. The BBMST odd-case alternative

Accepted as useful context but not inserted as an extra hypothesis in the proof.

The known alternative says that a distinct covering contains an even modulus, a modulus divisible by 9, or moduli witnessing divisibility by 3 and 5. In the odd case this gives the stated `9`-or-`3-and-5` structure. The present certificate already uses Hough--Nielsen to force 3 and then dominates all remaining supports by budget monotonicity. Exponent padding also permits depth-three treatment of the 3-coordinate. Thus invoking the stronger alternative would not presently shorten the exact certificate enough to justify another branch in the proof, but it is now cited in the introduction and literature audit.

## 6. Actual `K_3` profiles inside the broad relaxation

Accepted, with “closure-realizable” used deliberately.

After the pure class modulo 3 removes one branch, the pure class modulo 9 removes either no additional live leaves or one complete three-leaf node. The class modulo 27 then removes either no further leaf or one further leaf. Therefore the number `L` of live depth-three leaves lies in

\[
\{14,15,17,18\}.
\]

The deeper pure classes remove at most `(3^(e-3)-1)/2` additional points, giving

\[
\tau_a<\frac{2}{2L-1}.
\]

A vertex of the larger profile polytope has four zero leaves. It can occur in the closure of actual pure-tower profiles only when these consist of one complete mod-9 node plus one extra leaf. The audit script confirms:

- critical type 7: closure-realizable;
- critical type 11: not closure-realizable;
- critical type 13: closure-realizable.

Since type 13 also attains the global Stage-II maximum, the final value is not supported only by an impossible broad-polytope profile. This observation is now Remark 4.3 and is accompanied by `scripts/k3_actual_profile_audit.py`.

## 7. Extra promotion at 13 and 17

Accepted as a witness-specific headroom diagnostic.

At the displayed type-13 worst witness, after fixing the Stage-I state and the chosen promotions at 5, 7 and 11, optimizing the additional level-three blocks at 13 and 17 lowers the value from

\[
\frac{200282}{200475}
\quad\text{to}\quad
\frac{199724}{200475}.
\]

This does not replace the exhaustive proof, because the extra two blocks have not been scanned over every critical state. It does show that the small published margin partly reflects the economical stopping rule rather than a demonstrated intrinsic limit of the functional. The manuscript now says exactly that.

## 8. Engineering and trust-boundary changes

The following changes were made:

- Stage-II types are derived from nonempty Stage-I survivor files rather than hardcoded as `(7,11,13)`;
- one worker is the portable default, with optional parallelism;
- the release no longer requires a `wait -n` shell wrapper;
- the README states that manifest agreement proves reproducibility of the finite enumeration, not correctness of the analytic reductions;
- the level-wise reuse of `beta_p`, nonnegativity of the `q` factors, and the dependence of the `2/27` profile cap on exponent padding are stated explicitly;
- the existence and bibliography of arXiv:2607.25628 and arXiv:2507.16135 / *Discrete Mathematics* 349 (2026), Article 115013 were verified.

## 9. Current status

The finite proposition now has three agreeing computational routes and exact arithmetic throughout. The remaining serious trust boundary is mathematical rather than computational:

- pure-tower capacity reduction;
- axis-family ancestor disjointization;
- outside-support clipping;
- all-leaf deep-tail accounting;
- separate convexity and product-vertex reduction;
- promotion;
- budget monotonicity and reduction to `3,5,7,11,13,17`.

The result should therefore remain labelled a computer-assisted theorem candidate until a covering-systems specialist independently validates that analytic chain.
