# Literature and priority audit — Seven-Prime theorem candidate

**Search date:** 4 September 2026  
**Revised after BFF primary-source check**

## Established unrestricted lower bound

Berger, Felzenbaum and Fraenkel are the essential predecessors.

1. **BFF I (1986).** For distinct odd prime divisors \(p_1<\cdots<p_n\) of the LCM, they proved the necessary condition
   \[
   \prod_i\frac{p_i-1}{p_i-2}-\sum_i\frac1{p_i-2}>2.
   \]
   They explicitly observed that it forces \(n\ge5\).
2. **BFF II (1987).** They strengthened the necessary condition and explicitly concluded \(n\ge6\), ruling out the worst five-prime set \(\{3,5,7,11,13\}\).

Therefore the present candidate is correctly described as an unrestricted improvement from six to seven distinct prime divisors. Any manuscript omitting BFF II materially misstates the prior art.

## Further context

- **Hough–Nielsen (2019).** Every distinct covering system has a modulus divisible by 2 or 3; in the odd case, 3 divides the LCM.
- **BBMST (2022).** In an odd distinct covering, either some modulus is divisible by 9, or one modulus is divisible by 3 and another by 5. This is useful structure but does not eliminate the separate 9 branch.
- **Guo–Sun (2005).** In the square-free odd setting, a hypothetical LCM has at least 22 distinct prime factors.
- **BBMST (2021).** The square-free odd case is impossible.
- **Mian–Siddique (2026).** arXiv:2607.25628 exists and gives a Lean-kernel-checked fixed-LCM exclusion through 10,000; it explicitly treats the general problem as open.
- **Bispels et al. (2025/2026).** arXiv:2507.16135 exists and has journal reference *Discrete Mathematics* 349 (2026), Article 115013. It studies a repeated-modulus variant, not the seven-prime claim here.

## Priority finding

The bounded literature search did not locate a refereed paper or arXiv preprint proving

\[
\omega(N)\ge7
\]

for an arbitrary-exponent distinct odd covering. This is evidence, not a priority guarantee. A direct inquiry to covering-systems specialists remains necessary.

## Nearby web draft

A recent unrefereed web draft advertises a six-prime lower bound. Since BFF II already established the unrestricted six-prime lower bound in 1987, that draft is not an appropriate historical benchmark unless its hypotheses or claimed contribution differ. It is omitted from the manuscript’s core comparison.

## Primary references added

- M. A. Berger, A. Felzenbaum, A. S. Fraenkel, *Necessary condition for the existence of an incongruent covering system with odd moduli*, Acta Arith. 45 (1986), 375–379, DOI 10.4064/aa-45-4-375-379.
- M. A. Berger, A. Felzenbaum, A. S. Fraenkel, *Necessary condition for the existence of an incongruent covering system with odd moduli II*, Acta Arith. 48 (1987), 73–79, DOI 10.4064/aa-48-1-73-79.
